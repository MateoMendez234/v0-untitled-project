"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, AlertCircle, Check } from "lucide-react"

export default function AdminSettingsPage() {
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSaveSettings = async () => {
    setLoading(true)
    setError(null)
    setSuccess(false)

    try {
      // Simular guardado de configuración
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setSuccess(true)
    } catch (err) {
      console.error("Error al guardar configuración:", err)
      setError("Error al guardar la configuración. Por favor, inténtalo de nuevo.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Configuración del Sistema</h1>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList>
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="payments">Pagos</TabsTrigger>
          <TabsTrigger value="emails">Correos</TabsTrigger>
          <TabsTrigger value="security">Seguridad</TabsTrigger>
        </TabsList>

        {/* Configuración general */}
        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle>Configuración General</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="site_name">Nombre del sitio</Label>
                <Input id="site_name" defaultValue="Frilanet" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="site_description">Descripción del sitio</Label>
                <Input id="site_description" defaultValue="Plataforma de freelancers" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="contact_email">Email de contacto</Label>
                <Input id="contact_email" type="email" defaultValue="contacto@frilanet.com" />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="maintenance_mode" className="text-base">
                    Modo mantenimiento
                  </Label>
                  <p className="text-sm text-gray-500">
                    Activa el modo mantenimiento para mostrar una página de mantenimiento
                  </p>
                </div>
                <Switch id="maintenance_mode" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Configuración de pagos */}
        <TabsContent value="payments">
          <Card>
            <CardHeader>
              <CardTitle>Configuración de Pagos</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="stripe_public_key">Stripe Public Key</Label>
                <Input id="stripe_public_key" defaultValue="pk_test_..." />
              </div>

              <div className="space-y-2">
                <Label htmlFor="stripe_secret_key">Stripe Secret Key</Label>
                <Input id="stripe_secret_key" type="password" defaultValue="sk_test_..." />
              </div>

              <div className="space-y-2">
                <Label htmlFor="commission_rate">Comisión de la plataforma (%)</Label>
                <Input id="commission_rate" type="number" defaultValue="10" min="0" max="100" />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="test_mode" className="text-base">
                    Modo de prueba
                  </Label>
                  <p className="text-sm text-gray-500">Activa el modo de prueba para usar Stripe en modo sandbox</p>
                </div>
                <Switch id="test_mode" defaultChecked />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Configuración de correos */}
        <TabsContent value="emails">
          <Card>
            <CardHeader>
              <CardTitle>Configuración de Correos</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="smtp_host">Servidor SMTP</Label>
                <Input id="smtp_host" defaultValue="smtp.example.com" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="smtp_port">Puerto SMTP</Label>
                <Input id="smtp_port" defaultValue="587" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="smtp_user">Usuario SMTP</Label>
                <Input id="smtp_user" defaultValue="user@example.com" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="smtp_password">Contraseña SMTP</Label>
                <Input id="smtp_password" type="password" defaultValue="password" />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="email_notifications" className="text-base">
                    Notificaciones por correo
                  </Label>
                  <p className="text-sm text-gray-500">Activar envío de notificaciones por correo electrónico</p>
                </div>
                <Switch id="email_notifications" defaultChecked />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Configuración de seguridad */}
        <TabsContent value="security">
          <Card>
            <CardHeader>
              <CardTitle>Configuración de Seguridad</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="two_factor_auth" className="text-base">
                    Autenticación de dos factores
                  </Label>
                  <p className="text-sm text-gray-500">Requerir autenticación de dos factores para administradores</p>
                </div>
                <Switch id="two_factor_auth" />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="force_ssl" className="text-base">
                    Forzar SSL
                  </Label>
                  <p className="text-sm text-gray-500">Redirigir todo el tráfico a HTTPS</p>
                </div>
                <Switch id="force_ssl" defaultChecked />
              </div>

              <div className="space-y-2">
                <Label htmlFor="session_timeout">Tiempo de sesión (minutos)</Label>
                <Input id="session_timeout" type="number" defaultValue="60" min="5" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="max_login_attempts">Intentos máximos de inicio de sesión</Label>
                <Input id="max_login_attempts" type="number" defaultValue="5" min="1" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {error && (
        <Alert variant="destructive" className="mt-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="ml-2">{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="mt-6 bg-green-50 text-green-800 border-green-200">
          <Check className="h-4 w-4" />
          <AlertDescription className="ml-2">Configuración guardada correctamente.</AlertDescription>
        </Alert>
      )}

      <div className="mt-6 flex justify-end">
        <Button onClick={handleSaveSettings} className="bg-blue-600 hover:bg-blue-700" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Guardando...
            </>
          ) : (
            "Guardar configuración"
          )}
        </Button>
      </div>
    </div>
  )
}
