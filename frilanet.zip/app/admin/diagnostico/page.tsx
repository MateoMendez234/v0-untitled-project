"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { CheckCircle, XCircle, Users, Briefcase, MessageSquare, Star, ShoppingCart, FileText } from "lucide-react"
import Link from "next/link"

interface DiagnosticResult {
  connection: boolean
  collections: {
    users: number
    profiles: number
    services: number
    portfolioItems: number
    conversations: number
    messages: number
    reviews: number
    orders: number
  }
  error?: string
}

export default function DiagnosticoPage() {
  const [result, setResult] = useState<DiagnosticResult | null>(null)
  const [loading, setLoading] = useState(false)

  const runDiagnostic = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/admin/diagnostico")
      const data = await response.json()
      setResult(data)
    } catch (error) {
      setResult({
        connection: false,
        collections: {
          users: 0,
          profiles: 0,
          services: 0,
          portfolioItems: 0,
          conversations: 0,
          messages: 0,
          reviews: 0,
          orders: 0,
        },
        error: "Error al ejecutar el diagnóstico",
      })
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    runDiagnostic()
  }, [])

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Diagnóstico del Sistema</h1>

      <div className="mb-6 flex gap-4">
        <Button onClick={runDiagnostic} disabled={loading}>
          {loading ? "Ejecutando diagnóstico..." : "Actualizar diagnóstico"}
        </Button>

        <Link href="/admin/verificar-migracion" passHref>
          <Button variant="outline">
            <FileText className="mr-2 h-4 w-4" />
            Verificar Migración Detallada
          </Button>
        </Link>
      </div>

      {result ? (
        <div className="space-y-6">
          <Alert variant={result.connection ? "default" : "destructive"}>
            <div className="flex items-center gap-2">
              {result.connection ? <CheckCircle className="h-5 w-5" /> : <XCircle className="h-5 w-5" />}
              <AlertTitle>Estado de la conexión a MongoDB</AlertTitle>
            </div>
            <AlertDescription>
              {result.connection
                ? "La conexión a MongoDB está funcionando correctamente."
                : "No se pudo conectar a MongoDB. Verifica tus credenciales y la configuración."}
            </AlertDescription>
          </Alert>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <StatsCard
              title="Usuarios"
              value={result.collections.users}
              icon={<Users className="h-5 w-5" />}
              description="Usuarios registrados"
            />
            <StatsCard
              title="Perfiles"
              value={result.collections.profiles}
              icon={<Users className="h-5 w-5" />}
              description="Perfiles de usuario"
            />
            <StatsCard
              title="Servicios"
              value={result.collections.services}
              icon={<Briefcase className="h-5 w-5" />}
              description="Servicios ofrecidos"
            />
            <StatsCard
              title="Portfolio"
              value={result.collections.portfolioItems}
              icon={<Briefcase className="h-5 w-5" />}
              description="Items de portfolio"
            />
            <StatsCard
              title="Conversaciones"
              value={result.collections.conversations}
              icon={<MessageSquare className="h-5 w-5" />}
              description="Conversaciones entre usuarios"
            />
            <StatsCard
              title="Mensajes"
              value={result.collections.messages}
              icon={<MessageSquare className="h-5 w-5" />}
              description="Mensajes enviados"
            />
            <StatsCard
              title="Reseñas"
              value={result.collections.reviews}
              icon={<Star className="h-5 w-5" />}
              description="Reseñas de servicios"
            />
            <StatsCard
              title="Órdenes"
              value={result.collections.orders}
              icon={<ShoppingCart className="h-5 w-5" />}
              description="Órdenes realizadas"
            />
          </div>

          <div className="mt-6">
            <h2 className="text-xl font-semibold mb-2">Diagnóstico general</h2>
            {result.connection && Object.values(result.collections).some((count) => count > 0) ? (
              <Alert>
                <CheckCircle className="h-5 w-5" />
                <AlertTitle>La migración parece haberse completado correctamente</AlertTitle>
                <AlertDescription>
                  Se ha detectado datos en las colecciones de MongoDB. El backend está funcionando correctamente.
                </AlertDescription>
              </Alert>
            ) : (
              <Alert variant="warning">
                <AlertTitle>La migración parece no haberse completado</AlertTitle>
                <AlertDescription>
                  No se han detectado datos en algunas colecciones o hay problemas de conexión. Verifica que hayas
                  ejecutado el script de migración.
                </AlertDescription>
              </Alert>
            )}
          </div>

          {result.error && (
            <Alert variant="destructive">
              <XCircle className="h-5 w-5" />
              <AlertTitle>Error en el diagnóstico</AlertTitle>
              <AlertDescription>{result.error}</AlertDescription>
            </Alert>
          )}

          <Card>
            <CardHeader>
              <CardTitle>Próximos pasos</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="list-disc pl-5 space-y-2">
                <li>Si no hay datos en MongoDB, ejecuta la migración desde la página de migración</li>
                <li>
                  Verifica la migración detallada para asegurarte de que todos los datos se han migrado correctamente
                </li>
                <li>Prueba las funcionalidades principales de la aplicación para asegurar que todo funciona</li>
              </ul>
            </CardContent>
            <CardFooter>
              <Link href="/admin/verificar-migracion" passHref>
                <Button>
                  <FileText className="mr-2 h-4 w-4" />
                  Ir a Verificación Detallada
                </Button>
              </Link>
            </CardFooter>
          </Card>
        </div>
      ) : (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700"></div>
        </div>
      )}
    </div>
  )
}

function StatsCard({
  title,
  value,
  icon,
  description,
}: {
  title: string
  value: number
  icon: React.ReactNode
  description: string
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground">{description}</p>
      </CardContent>
    </Card>
  )
}
