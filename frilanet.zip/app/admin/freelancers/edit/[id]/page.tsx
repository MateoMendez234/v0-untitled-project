"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import type { ProfileWithDetails } from "@/lib/profiles"
import { SiteHeader } from "@/components/layout/site-header"
import { useRouter } from "next/navigation"

export default function EditFreelancerPage({ params }: { params: { id: string } }) {
  const [freelancer, setFreelancer] = useState<ProfileWithDetails | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    async function fetchFreelancer() {
      setLoading(true)
      const supabase = createClientSupabaseClient()

      // Obtener perfil
      const { data: profile, error } = await supabase.from("profiles").select("*").eq("id", params.id).single()

      if (error || !profile) {
        console.error("Error fetching freelancer:", error)
        setLoading(false)
        setError("No se pudo cargar el perfil del freelancer")
        return
      }

      // Obtener habilidades
      const { data: skills } = await supabase.from("skills").select("skill").eq("profile_id", params.id)

      // Obtener idiomas
      const { data: languages } = await supabase.from("languages").select("language").eq("profile_id", params.id)

      setFreelancer({
        ...profile,
        skills: skills?.map((s) => s.skill) || [],
        languages: languages?.map((l) => l.language) || [],
      })
      setLoading(false)
    }

    fetchFreelancer()
  }, [params.id])

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setSaving(true)
    setError(null)

    try {
      const formData = new FormData(event.currentTarget)
      const supabase = createClientSupabaseClient()

      // Actualizar perfil
      const { error } = await supabase
        .from("profiles")
        .update({
          name: formData.get("name") as string,
          username: formData.get("username") as string,
          title: formData.get("title") as string,
          location: formData.get("location") as string,
          about: formData.get("about") as string,
          email: formData.get("email") as string,
        })
        .eq("id", params.id)

      if (error) {
        console.error("Error updating freelancer:", error)
        setError("Error al actualizar el perfil")
        setSaving(false)
        return
      }

      // Actualizar habilidades
      const skills = (formData.get("skills") as string).split(",").map((skill) => skill.trim())

      // Eliminar habilidades existentes
      await supabase.from("skills").delete().eq("profile_id", params.id)

      // Insertar nuevas habilidades
      if (skills.length > 0) {
        await supabase.from("skills").insert(
          skills.map((skill) => ({
            profile_id: params.id,
            skill,
          })),
        )
      }

      // Actualizar idiomas
      const languages = (formData.get("languages") as string).split(",").map((language) => language.trim())

      // Eliminar idiomas existentes
      await supabase.from("languages").delete().eq("profile_id", params.id)

      // Insertar nuevos idiomas
      if (languages.length > 0) {
        await supabase.from("languages").insert(
          languages.map((language) => ({
            profile_id: params.id,
            language,
          })),
        )
      }

      // Redirigir a la página de gestión de freelancers
      router.push("/admin/freelancers")
      router.refresh()
    } catch (error) {
      console.error("Error submitting form:", error)
      setError("Error inesperado al procesar el formulario")
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="flex flex-col min-h-screen">
        <SiteHeader />
        <main className="flex-1 container px-4 md:px-6 py-8">
          <div className="text-center py-8">Cargando información del freelancer...</div>
        </main>
      </div>
    )
  }

  if (!freelancer) {
    return (
      <div className="flex flex-col min-h-screen">
        <SiteHeader />
        <main className="flex-1 container px-4 md:px-6 py-8">
          <div className="text-center py-8">No se encontró el freelancer</div>
        </main>
      </div>
    )
  }

  return (
    <div className="flex flex-col min-h-screen">
      <SiteHeader />

      <main className="flex-1 container px-4 md:px-6 py-8">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl font-bold">Editar Freelancer</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Nombre completo</Label>
                      <Input id="name" name="name" defaultValue={freelancer.name || ""} required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="username">Nombre de usuario</Label>
                      <Input id="username" name="username" defaultValue={freelancer.username || ""} required />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Correo electrónico</Label>
                    <Input id="email" name="email" type="email" defaultValue={freelancer.email || ""} required />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="title">Título profesional</Label>
                    <Input
                      id="title"
                      name="title"
                      placeholder="Ej: Diseñador Gráfico & Ilustrador"
                      defaultValue={freelancer.title || ""}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="location">Ubicación</Label>
                    <Input
                      id="location"
                      name="location"
                      placeholder="Ej: Madrid, España"
                      defaultValue={freelancer.location || ""}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="about">Acerca de</Label>
                    <Textarea
                      id="about"
                      name="about"
                      placeholder="Describe tu experiencia, especialidades y lo que te hace único..."
                      rows={5}
                      defaultValue={freelancer.about || ""}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="skills">Habilidades (separadas por comas)</Label>
                    <Input
                      id="skills"
                      name="skills"
                      placeholder="Ej: Diseño Gráfico, Ilustración, Adobe Photoshop"
                      defaultValue={freelancer.skills.join(", ")}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="languages">Idiomas (separados por comas)</Label>
                    <Input
                      id="languages"
                      name="languages"
                      placeholder="Ej: Español, Inglés, Francés"
                      defaultValue={freelancer.languages.join(", ")}
                      required
                    />
                  </div>
                </div>

                {error && <div className="p-3 rounded-md bg-red-50 text-red-700">{error}</div>}

                <div className="flex justify-between">
                  <Button type="button" variant="outline" onClick={() => router.back()}>
                    Cancelar
                  </Button>
                  <Button type="submit" disabled={saving}>
                    {saving ? "Guardando..." : "Guardar Cambios"}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
