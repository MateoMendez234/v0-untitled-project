"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import type { ProfileWithDetails } from "@/lib/profiles"
import { SiteHeader } from "@/components/layout/site-header"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Trash2, Edit, Eye } from "lucide-react"
import Link from "next/link"

export default function AdminFreelancersPage() {
  const [freelancers, setFreelancers] = useState<ProfileWithDetails[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    async function fetchFreelancers() {
      setLoading(true)
      const supabase = createClientSupabaseClient()

      // Obtener perfiles de freelancers
      const { data: profiles, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("is_freelancer", true)
        .order("created_at", { ascending: false })

      if (error) {
        console.error("Error fetching freelancers:", error)
        setLoading(false)
        return
      }

      // Para cada perfil, obtener habilidades e idiomas
      const profilesWithDetails = await Promise.all(
        profiles.map(async (profile) => {
          // Obtener habilidades
          const { data: skills } = await supabase.from("skills").select("skill").eq("profile_id", profile.id)

          // Obtener idiomas
          const { data: languages } = await supabase.from("languages").select("language").eq("profile_id", profile.id)

          return {
            ...profile,
            skills: skills?.map((s) => s.skill) || [],
            languages: languages?.map((l) => l.language) || [],
          }
        }),
      )

      setFreelancers(profilesWithDetails)
      setLoading(false)
    }

    fetchFreelancers()
  }, [])

  // Filtrar freelancers según el término de búsqueda
  const filteredFreelancers = freelancers.filter(
    (freelancer) =>
      freelancer.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      freelancer.username?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      freelancer.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      freelancer.location?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      freelancer.skills.some((skill) => skill.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  async function handleDeleteFreelancer(id: string) {
    if (!confirm("¿Estás seguro de que deseas eliminar este freelancer? Esta acción no se puede deshacer.")) {
      return
    }

    const supabase = createClientSupabaseClient()

    // Eliminar habilidades
    await supabase.from("skills").delete().eq("profile_id", id)

    // Eliminar idiomas
    await supabase.from("languages").delete().eq("profile_id", id)

    // Eliminar servicios (y sus dependencias)
    const { data: services } = await supabase.from("services").select("id").eq("profile_id", id)

    if (services && services.length > 0) {
      for (const service of services) {
        // Eliminar paquetes y características
        const { data: packages } = await supabase.from("service_packages").select("id").eq("service_id", service.id)

        if (packages && packages.length > 0) {
          for (const pkg of packages) {
            await supabase.from("package_features").delete().eq("package_id", pkg.id)
          }
        }

        await supabase.from("service_packages").delete().eq("service_id", service.id)

        // Eliminar FAQs
        await supabase.from("service_faqs").delete().eq("service_id", service.id)

        // Eliminar reseñas
        await supabase.from("reviews").delete().eq("service_id", service.id)
      }

      // Eliminar servicios
      await supabase.from("services").delete().eq("profile_id", id)
    }

    // Eliminar elementos de portafolio
    await supabase.from("portfolio_items").delete().eq("profile_id", id)

    // Finalmente, eliminar el perfil
    const { error } = await supabase.from("profiles").delete().eq("id", id)

    if (error) {
      console.error("Error deleting freelancer:", error)
      alert("Error al eliminar el freelancer")
      return
    }

    // Actualizar la lista de freelancers
    setFreelancers(freelancers.filter((freelancer) => freelancer.id !== id))
  }

  return (
    <div className="flex flex-col min-h-screen">
      <SiteHeader />

      <main className="flex-1 container px-4 md:px-6 py-8">
        <Card>
          <CardHeader className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <CardTitle className="text-2xl font-bold">Gestión de Freelancers</CardTitle>
            <div className="flex items-center gap-4">
              <Input
                placeholder="Buscar freelancers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="max-w-xs"
              />
              <Link href="/register-freelancer">
                <Button>Añadir Freelancer</Button>
              </Link>
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8">Cargando freelancers...</div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Freelancer</TableHead>
                      <TableHead>Título</TableHead>
                      <TableHead>Ubicación</TableHead>
                      <TableHead>Habilidades</TableHead>
                      <TableHead>Acciones</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredFreelancers.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center py-8">
                          No se encontraron freelancers
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredFreelancers.map((freelancer) => (
                        <TableRow key={freelancer.id}>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <Avatar>
                                <AvatarImage src={freelancer.avatar_url || ""} alt={freelancer.name || ""} />
                                <AvatarFallback>
                                  {freelancer.name
                                    ? freelancer.name
                                        .split(" ")
                                        .map((n) => n[0])
                                        .join("")
                                        .toUpperCase()
                                    : "?"}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="font-medium">{freelancer.name}</div>
                                <div className="text-sm text-gray-500">@{freelancer.username}</div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>{freelancer.title || "Sin título"}</TableCell>
                          <TableCell>{freelancer.location || "Sin ubicación"}</TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1">
                              {freelancer.skills.slice(0, 3).map((skill, index) => (
                                <Badge key={index} variant="outline">
                                  {skill}
                                </Badge>
                              ))}
                              {freelancer.skills.length > 3 && (
                                <Badge variant="outline">+{freelancer.skills.length - 3}</Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Link href={`/freelancers/${freelancer.username}`}>
                                <Button size="sm" variant="ghost">
                                  <Eye className="h-4 w-4" />
                                </Button>
                              </Link>
                              <Link href={`/admin/freelancers/edit/${freelancer.id}`}>
                                <Button size="sm" variant="ghost">
                                  <Edit className="h-4 w-4" />
                                </Button>
                              </Link>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="text-red-500 hover:text-red-700"
                                onClick={() => handleDeleteFreelancer(freelancer.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
