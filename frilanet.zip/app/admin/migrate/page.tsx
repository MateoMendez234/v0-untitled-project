"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader2, CheckCircle, XCircle } from "lucide-react"

export default function MigratePage() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<{
    success: boolean
    message: string
    details?: string
    error?: string
  } | null>(null)

  const startMigration = async () => {
    if (!confirm("¿Estás seguro de que deseas iniciar la migración? Este proceso puede tardar varios minutos.")) {
      return
    }

    setLoading(true)
    setResult(null)

    try {
      const response = await fetch("/api/admin/migrate", {
        method: "POST",
      })

      const data = await response.json()

      if (response.ok) {
        setResult({
          success: true,
          message: data.message || "Migración completada con éxito",
          details: data.details,
        })
      } else {
        setResult({
          success: false,
          message: "Error durante la migración",
          error: data.error || "Ocurrió un error desconocido",
          details: data.details,
        })
      }
    } catch (error) {
      setResult({
        success: false,
        message: "Error durante la migración",
        error: "No se pudo conectar con el servidor",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Migración de Datos</h1>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Migrar datos de Supabase a MongoDB</CardTitle>
          <CardDescription>
            Este proceso migrará todos los datos existentes de Supabase a MongoDB. Asegúrate de tener configuradas
            correctamente las variables de entorno para ambas bases de datos.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <Alert>
              <AlertTitle>Importante</AlertTitle>
              <AlertDescription>
                La migración puede tardar varios minutos dependiendo de la cantidad de datos. No cierres esta página
                durante el proceso.
              </AlertDescription>
            </Alert>

            {result && (
              <Alert variant={result.success ? "default" : "destructive"}>
                <div className="flex items-center gap-2">
                  {result.success ? <CheckCircle className="h-5 w-5" /> : <XCircle className="h-5 w-5" />}
                  <AlertTitle>{result.message}</AlertTitle>
                </div>
                {result.error && <AlertDescription className="mt-2">{result.error}</AlertDescription>}
                {result.details && (
                  <div className="mt-4">
                    <details>
                      <summary className="cursor-pointer font-medium">Ver detalles</summary>
                      <pre className="mt-2 whitespace-pre-wrap text-xs bg-muted p-4 rounded-md overflow-auto max-h-96">
                        {result.details}
                      </pre>
                    </details>
                  </div>
                )}
              </Alert>
            )}
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={startMigration} disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Migrando datos...
              </>
            ) : (
              "Iniciar Migración"
            )}
          </Button>
        </CardFooter>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Después de la migración</CardTitle>
          <CardDescription>Pasos a seguir una vez completada la migración</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="list-disc pl-5 space-y-2">
            <li>Verifica que todos los datos se hayan migrado correctamente en la página de diagnóstico</li>
            <li>Prueba las funcionalidades principales de la aplicación para asegurar que todo funciona</li>
            <li>Considera crear índices en MongoDB para mejorar el rendimiento de las consultas frecuentes</li>
            <li>Configura backups automáticos para tu base de datos MongoDB</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}
