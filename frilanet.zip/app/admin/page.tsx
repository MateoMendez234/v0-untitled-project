import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import { Users, Briefcase, CreditCard } from "lucide-react"

export default async function AdminDashboardPage() {
  const supabase = createServerSupabaseClient()

  // Obtener estadísticas generales
  const { count: usersCount } = await supabase.from("profiles").select("*", { count: "exact", head: true })

  const { count: freelancersCount } = await supabase
    .from("profiles")
    .select("*", { count: "exact", head: true })
    .eq("is_freelancer", true)

  const { count: servicesCount } = await supabase.from("services").select("*", { count: "exact", head: true })

  const { data: payments } = await supabase.from("orders").select("amount").eq("status", "completed")

  const totalRevenue = payments?.reduce((sum, order) => sum + order.amount, 0) || 0

  // Obtener usuarios recientes
  const { data: recentUsers } = await supabase
    .from("profiles")
    .select("id, name, email, created_at, is_freelancer")
    .order("created_at", { ascending: false })
    .limit(5)

  // Obtener servicios recientes
  const { data: recentServices } = await supabase
    .from("services")
    .select("id, title, price, created_at, profile_id, profiles(name)")
    .order("created_at", { ascending: false })
    .limit(5)

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Panel de Administración</h1>

      {/* Tarjetas de estadísticas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="bg-blue-100 p-3 rounded-full">
              <Users className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Usuarios totales</p>
              <h3 className="text-2xl font-bold">{usersCount || 0}</h3>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="bg-blue-100 p-3 rounded-full">
              <Users className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Freelancers</p>
              <h3 className="text-2xl font-bold">{freelancersCount || 0}</h3>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="bg-blue-100 p-3 rounded-full">
              <Briefcase className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Servicios</p>
              <h3 className="text-2xl font-bold">{servicesCount || 0}</h3>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="bg-blue-100 p-3 rounded-full">
              <CreditCard className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Ingresos totales</p>
              <h3 className="text-2xl font-bold">€{totalRevenue.toFixed(2)}</h3>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Usuarios recientes */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Usuarios recientes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentUsers && recentUsers.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        <th className="px-4 py-2">Nombre</th>
                        <th className="px-4 py-2">Email</th>
                        <th className="px-4 py-2">Tipo</th>
                        <th className="px-4 py-2">Fecha</th>
                      </tr>
                    </thead>
                    <tbody>
                      {recentUsers.map((user) => (
                        <tr key={user.id} className="border-t">
                          <td className="px-4 py-2">{user.name}</td>
                          <td className="px-4 py-2">{user.email}</td>
                          <td className="px-4 py-2">{user.is_freelancer ? "Freelancer" : "Cliente"}</td>
                          <td className="px-4 py-2">{new Date(user.created_at).toLocaleDateString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="text-center py-4 text-gray-500">No hay usuarios recientes</p>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Servicios recientes */}
        <Card>
          <CardHeader>
            <CardTitle>Servicios recientes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentServices && recentServices.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        <th className="px-4 py-2">Título</th>
                        <th className="px-4 py-2">Freelancer</th>
                        <th className="px-4 py-2">Precio</th>
                        <th className="px-4 py-2">Fecha</th>
                      </tr>
                    </thead>
                    <tbody>
                      {recentServices.map((service) => (
                        <tr key={service.id} className="border-t">
                          <td className="px-4 py-2">{service.title}</td>
                          <td className="px-4 py-2">{service.profiles?.name || "Desconocido"}</td>
                          <td className="px-4 py-2">€{service.price.toFixed(2)}</td>
                          <td className="px-4 py-2">{new Date(service.created_at).toLocaleDateString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="text-center py-4 text-gray-500">No hay servicios recientes</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
