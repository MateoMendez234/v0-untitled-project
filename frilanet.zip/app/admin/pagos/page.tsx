import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import { Eye } from "lucide-react"

export default async function AdminPaymentsPage() {
  const supabase = createServerSupabaseClient()

  // Obtener todos los pagos con información del servicio y cliente
  const { data: payments, error } = await supabase
    .from("orders")
    .select(`
      *,
      services(title, price),
      profiles!orders_client_id_fkey(name, email)
    `)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error al obtener pagos:", error)
  }

  // Calcular estadísticas
  const totalRevenue =
    payments?.reduce((sum, order) => {
      return order.status === "completed" || order.status === "paid" ? sum + order.amount : sum
    }, 0) || 0

  const pendingRevenue =
    payments?.reduce((sum, order) => {
      return order.status === "pending" ? sum + order.amount : sum
    }, 0) || 0

  const completedOrders = payments?.filter((order) => order.status === "completed").length || 0
  const pendingOrders = payments?.filter((order) => order.status === "pending").length || 0
  const paidOrders = payments?.filter((order) => order.status === "paid").length || 0

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Gestión de Pagos</h1>
      </div>

      {/* Tarjetas de estadísticas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <h3 className="text-sm font-medium text-gray-500">Ingresos totales</h3>
            <p className="text-2xl font-bold">€{totalRevenue.toFixed(2)}</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h3 className="text-sm font-medium text-gray-500">Ingresos pendientes</h3>
            <p className="text-2xl font-bold">€{pendingRevenue.toFixed(2)}</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h3 className="text-sm font-medium text-gray-500">Pedidos completados</h3>
            <p className="text-2xl font-bold">{completedOrders}</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <h3 className="text-sm font-medium text-gray-500">Pedidos en proceso</h3>
            <p className="text-2xl font-bold">{paidOrders + pendingOrders}</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Historial de pagos</CardTitle>
        </CardHeader>
        <CardContent>
          {payments && payments.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    <th className="px-4 py-2">ID</th>
                    <th className="px-4 py-2">Cliente</th>
                    <th className="px-4 py-2">Servicio</th>
                    <th className="px-4 py-2">Importe</th>
                    <th className="px-4 py-2">Estado</th>
                    <th className="px-4 py-2">Fecha</th>
                    <th className="px-4 py-2">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {payments.map((payment) => (
                    <tr key={payment.id} className="border-t">
                      <td className="px-4 py-2">{payment.id.substring(0, 8)}</td>
                      <td className="px-4 py-2">{payment.profiles?.name || "Desconocido"}</td>
                      <td className="px-4 py-2">{payment.services?.title || "Desconocido"}</td>
                      <td className="px-4 py-2">€{payment.amount.toFixed(2)}</td>
                      <td className="px-4 py-2">
                        <span
                          className={`text-xs px-2 py-1 rounded-full ${
                            payment.status === "completed"
                              ? "bg-green-100 text-green-800"
                              : payment.status === "paid"
                                ? "bg-blue-100 text-blue-800"
                                : payment.status === "pending"
                                  ? "bg-yellow-100 text-yellow-800"
                                  : "bg-red-100 text-red-800"
                          }`}
                        >
                          {payment.status === "completed"
                            ? "Completado"
                            : payment.status === "paid"
                              ? "En progreso"
                              : payment.status === "pending"
                                ? "Pendiente"
                                : "Cancelado"}
                        </span>
                      </td>
                      <td className="px-4 py-2">{new Date(payment.created_at).toLocaleDateString()}</td>
                      <td className="px-4 py-2">
                        <Button variant="outline" size="sm" asChild>
                          <Link href={`/admin/pagos/${payment.id}`}>
                            <Eye className="h-4 w-4" />
                          </Link>
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-center py-4 text-gray-500">No hay pagos disponibles</p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
