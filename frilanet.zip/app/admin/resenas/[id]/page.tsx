import Link from "next/link"
import { notFound } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import { ArrowLeft, Star } from "lucide-react"

export default async function AdminReviewDetailsPage({ params }: { params: { id: string } }) {
  const supabase = createServerSupabaseClient()

  // Obtener detalles de la reseña
  const { data: review, error } = await supabase
    .from("reviews")
    .select(`
      *,
      services(id, title, profile_id),
      profiles!reviews_client_id_fkey(id, name, email, username)
    `)
    .eq("id", params.id)
    .single()

  if (error || !review) {
    console.error("Error al obtener reseña:", error)
    notFound()
  }

  // Obtener información del freelancer
  const { data: freelancer } = await supabase
    .from("profiles")
    .select("id, name, email, username")
    .eq("id", review.services?.profile_id)
    .single()

  // Función para renderizar estrellas
  const renderStars = (rating: number) => {
    return Array(5)
      .fill(0)
      .map((_, i) => (
        <Star key={i} className={`h-5 w-5 ${i < rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`} />
      ))
  }

  return (
    <div>
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="sm" asChild>
          <Link href="/admin/resenas">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Volver
          </Link>
        </Button>
        <h1 className="text-2xl font-bold">Detalles de la Reseña</h1>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Reseña</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div>
              <h3 className="text-sm font-medium text-gray-500 mb-1">Calificación</h3>
              <div className="flex items-center">
                <div className="flex mr-2">{renderStars(review.rating)}</div>
                <span className="font-bold">{review.rating}/5</span>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-medium text-gray-500 mb-1">Comentario</h3>
              <p className="text-gray-800">{review.comment}</p>
            </div>

            <div>
              <h3 className="text-sm font-medium text-gray-500 mb-1">Fecha</h3>
              <p>{new Date(review.created_at).toLocaleDateString()}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Servicio</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-1">Título</h3>
                <p className="font-medium">{review.services?.title}</p>
              </div>

              <Button variant="outline" asChild>
                <Link href={`/admin/servicios/${review.services?.id}`}>Ver detalles del servicio</Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Usuarios</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-1">Cliente</h3>
                <p className="font-medium">{review.profiles?.name}</p>
                <p className="text-sm text-gray-600">{review.profiles?.email}</p>
                <Button variant="outline" size="sm" className="mt-2" asChild>
                  <Link href={`/admin/usuarios/${review.profiles?.id}`}>Ver perfil</Link>
                </Button>
              </div>

              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-1">Freelancer</h3>
                <p className="font-medium">{freelancer?.name}</p>
                <p className="text-sm text-gray-600">{freelancer?.email}</p>
                <Button variant="outline" size="sm" className="mt-2" asChild>
                  <Link href={`/admin/usuarios/${freelancer?.id}`}>Ver perfil</Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
