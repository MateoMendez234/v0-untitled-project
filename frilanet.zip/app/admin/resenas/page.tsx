import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import { Eye, Trash2 } from "lucide-react"
import { Star } from "lucide-react"

export default async function AdminReviewsPage() {
  const supabase = createServerSupabaseClient()

  // Obtener todas las reseñas con información del servicio y cliente
  const { data: reviews, error } = await supabase
    .from("reviews")
    .select(`
      *,
      services(title),
      profiles!reviews_client_id_fkey(name)
    `)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error al obtener reseñas:", error)
  }

  // Función para renderizar estrellas
  const renderStars = (rating: number) => {
    return Array(5)
      .fill(0)
      .map((_, i) => (
        <Star key={i} className={`h-4 w-4 ${i < rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`} />
      ))
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Gestión de Reseñas</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Reseñas</CardTitle>
        </CardHeader>
        <CardContent>
          {reviews && reviews.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    <th className="px-4 py-2">Servicio</th>
                    <th className="px-4 py-2">Cliente</th>
                    <th className="px-4 py-2">Calificación</th>
                    <th className="px-4 py-2">Comentario</th>
                    <th className="px-4 py-2">Fecha</th>
                    <th className="px-4 py-2">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {reviews.map((review) => (
                    <tr key={review.id} className="border-t">
                      <td className="px-4 py-2">{review.services?.title || "Desconocido"}</td>
                      <td className="px-4 py-2">{review.profiles?.name || "Desconocido"}</td>
                      <td className="px-4 py-2">
                        <div className="flex">{renderStars(review.rating)}</div>
                      </td>
                      <td className="px-4 py-2">
                        <p className="truncate max-w-xs">{review.comment}</p>
                      </td>
                      <td className="px-4 py-2">{new Date(review.created_at).toLocaleDateString()}</td>
                      <td className="px-4 py-2">
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm" asChild>
                            <Link href={`/admin/resenas/${review.id}`}>
                              <Eye className="h-4 w-4" />
                            </Link>
                          </Button>
                          <Button variant="outline" size="sm" className="text-red-500 hover:text-red-700">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-center py-4 text-gray-500">No hay reseñas disponibles</p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
