import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import { Eye, Edit, Trash2 } from "lucide-react"

export default async function AdminServicesPage() {
  const supabase = createServerSupabaseClient()

  // Obtener todos los servicios con información del freelancer
  const { data: services, error } = await supabase
    .from("services")
    .select("*, profiles(name, username)")
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error al obtener servicios:", error)
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Gestión de Servicios</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Servicios</CardTitle>
        </CardHeader>
        <CardContent>
          {services && services.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    <th className="px-4 py-2">Servicio</th>
                    <th className="px-4 py-2">Freelancer</th>
                    <th className="px-4 py-2">Categoría</th>
                    <th className="px-4 py-2">Precio</th>
                    <th className="px-4 py-2">Estado</th>
                    <th className="px-4 py-2">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {services.map((service) => (
                    <tr key={service.id} className="border-t">
                      <td className="px-4 py-2">
                        <div className="flex items-center">
                          <div className="relative w-10 h-10 rounded overflow-hidden mr-3">
                            <Image
                              src={service.image_url || "/placeholder.svg?height=40&width=40"}
                              alt={service.title}
                              className="object-cover"
                              fill
                            />
                          </div>
                          <span className="font-medium">{service.title}</span>
                        </div>
                      </td>
                      <td className="px-4 py-2">{service.profiles?.name || "Desconocido"}</td>
                      <td className="px-4 py-2">{service.category || "Sin categoría"}</td>
                      <td className="px-4 py-2">€{service.price.toFixed(2)}</td>
                      <td className="px-4 py-2">
                        <span
                          className={`text-xs px-2 py-1 rounded-full ${
                            service.is_active ? "bg-green-100 text-green-800" : "bg-gray-100 text-gray-800"
                          }`}
                        >
                          {service.is_active ? "Activo" : "Inactivo"}
                        </span>
                      </td>
                      <td className="px-4 py-2">
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm" asChild>
                            <Link href={`/admin/servicios/${service.id}`}>
                              <Eye className="h-4 w-4" />
                            </Link>
                          </Button>
                          <Button variant="outline" size="sm" asChild>
                            <Link href={`/admin/servicios/editar/${service.id}`}>
                              <Edit className="h-4 w-4" />
                            </Link>
                          </Button>
                          <Button variant="outline" size="sm" className="text-red-500 hover:text-red-700">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-center py-4 text-gray-500">No hay servicios disponibles</p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
