"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { CheckCircle, XCircle, Loader2 } from "lucide-react"
import { useSession } from "next-auth/react"

export default function TestPage() {
  const { data: session } = useSession()
  const [activeTab, setActiveTab] = useState("auth")

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Prueba del Sistema</h1>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Estado de la sesión</CardTitle>
          <CardDescription>Información sobre la sesión actual</CardDescription>
        </CardHeader>
        <CardContent>
          {session ? (
            <div className="space-y-2">
              <Alert>
                <CheckCircle className="h-4 w-4" />
                <AlertTitle>Sesión activa</AlertTitle>
                <AlertDescription>Has iniciado sesión correctamente.</AlertDescription>
              </Alert>
              <div className="bg-muted p-4 rounded-md">
                <pre className="whitespace-pre-wrap text-xs">
                  {JSON.stringify(
                    {
                      user: {
                        id: session.user.id,
                        name: session.user.name,
                        email: session.user.email,
                        isFreelancer: session.user.isFreelancer,
                        isAdmin: session.user.isAdmin,
                      },
                    },
                    null,
                    2,
                  )}
                </pre>
              </div>
            </div>
          ) : (
            <Alert variant="destructive">
              <XCircle className="h-4 w-4" />
              <AlertTitle>Sin sesión</AlertTitle>
              <AlertDescription>No has iniciado sesión. Algunas pruebas no funcionarán.</AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="auth">Autenticación</TabsTrigger>
          <TabsTrigger value="profiles">Perfiles</TabsTrigger>
          <TabsTrigger value="services">Servicios</TabsTrigger>
          <TabsTrigger value="messages">Mensajes</TabsTrigger>
        </TabsList>

        <TabsContent value="auth">
          <AuthTest />
        </TabsContent>

        <TabsContent value="profiles">
          <ProfilesTest />
        </TabsContent>

        <TabsContent value="services">
          <ServicesTest />
        </TabsContent>

        <TabsContent value="messages">
          <MessagesTest />
        </TabsContent>
      </Tabs>
    </div>
  )
}

function AuthTest() {
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)

  const handleLogin = async () => {
    setLoading(true)
    setResult(null)

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, password }),
      })

      const data = await response.json()
      setResult({
        success: response.ok,
        data,
      })
    } catch (error) {
      setResult({
        success: false,
        error: "Error al realizar la solicitud",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleRegister = async () => {
    setLoading(true)
    setResult(null)

    try {
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email,
          password,
          name: "Usuario de Prueba",
          isFreelancer: false,
        }),
      })

      const data = await response.json()
      setResult({
        success: response.ok,
        data,
      })
    } catch (error) {
      setResult({
        success: false,
        error: "Error al realizar la solicitud",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Prueba de Autenticación</CardTitle>
        <CardDescription>Prueba las funciones de inicio de sesión y registro</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid gap-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="correo@ejemplo.com"
            />
          </div>
          <div className="grid gap-2">
            <Label htmlFor="password">Contraseña</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="********"
            />
          </div>

          {result && (
            <Alert variant={result.success ? "default" : "destructive"}>
              <div className="flex items-center gap-2">
                {result.success ? <CheckCircle className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
                <AlertTitle>{result.success ? "Operación exitosa" : "Error"}</AlertTitle>
              </div>
              <div className="mt-2">
                <pre className="whitespace-pre-wrap text-xs bg-muted p-2 rounded-md overflow-auto max-h-40">
                  {JSON.stringify(result.data || result.error, null, 2)}
                </pre>
              </div>
            </Alert>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button onClick={handleLogin} disabled={loading}>
          {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          Iniciar sesión
        </Button>
        <Button onClick={handleRegister} disabled={loading} variant="outline">
          {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          Registrarse
        </Button>
      </CardFooter>
    </Card>
  )
}

function ProfilesTest() {
  const { data: session } = useSession()
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [profileData, setProfileData] = useState({
    username: "",
    name: "",
    title: "",
    about: "",
    location: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setProfileData((prev) => ({ ...prev, [name]: value }))
  }

  const getProfile = async () => {
    if (!session?.user.id) {
      setResult({
        success: false,
        error: "Debes iniciar sesión para obtener tu perfil",
      })
      return
    }

    setLoading(true)
    setResult(null)

    try {
      const response = await fetch(`/api/profiles/${session.user.id}`)
      const data = await response.json()
      setResult({
        success: response.ok,
        data,
      })
    } catch (error) {
      setResult({
        success: false,
        error: "Error al realizar la solicitud",
      })
    } finally {
      setLoading(false)
    }
  }

  const updateProfile = async () => {
    if (!session?.user.id) {
      setResult({
        success: false,
        error: "Debes iniciar sesión para actualizar tu perfil",
      })
      return
    }

    setLoading(true)
    setResult(null)

    try {
      const response = await fetch(`/api/profiles/${session.user.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(profileData),
      })

      const data = await response.json()
      setResult({
        success: response.ok,
        data,
      })
    } catch (error) {
      setResult({
        success: false,
        error: "Error al realizar la solicitud",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Prueba de Perfiles</CardTitle>
        <CardDescription>Obtén y actualiza información de perfiles</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="username">Nombre de usuario</Label>
              <Input
                id="username"
                name="username"
                value={profileData.username}
                onChange={handleChange}
                placeholder="usuario123"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="name">Nombre completo</Label>
              <Input id="name" name="name" value={profileData.name} onChange={handleChange} placeholder="Juan Pérez" />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="title">Título profesional</Label>
              <Input
                id="title"
                name="title"
                value={profileData.title}
                onChange={handleChange}
                placeholder="Desarrollador Web"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="location">Ubicación</Label>
              <Input
                id="location"
                name="location"
                value={profileData.location}
                onChange={handleChange}
                placeholder="Madrid, España"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="about">Acerca de</Label>
              <Textarea
                id="about"
                name="about"
                value={profileData.about}
                onChange={handleChange}
                placeholder="Cuéntanos sobre ti..."
                rows={3}
              />
            </div>
          </div>

          {result && (
            <Alert variant={result.success ? "default" : "destructive"}>
              <div className="flex items-center gap-2">
                {result.success ? <CheckCircle className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
                <AlertTitle>{result.success ? "Operación exitosa" : "Error"}</AlertTitle>
              </div>
              <div className="mt-2">
                <pre className="whitespace-pre-wrap text-xs bg-muted p-2 rounded-md overflow-auto max-h-40">
                  {JSON.stringify(result.data || result.error, null, 2)}
                </pre>
              </div>
            </Alert>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button onClick={getProfile} disabled={loading}>
          {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          Obtener perfil
        </Button>
        <Button onClick={updateProfile} disabled={loading} variant="outline">
          {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          Actualizar perfil
        </Button>
      </CardFooter>
    </Card>
  )
}

function ServicesTest() {
  const { data: session } = useSession()
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [serviceData, setServiceData] = useState({
    title: "",
    description: "",
    price: 0,
    deliveryTime: 0,
    revisions: 0,
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setServiceData((prev) => ({
      ...prev,
      [name]: name === "price" || name === "deliveryTime" || name === "revisions" ? Number(value) : value,
    }))
  }

  const getServices = async () => {
    setLoading(true)
    setResult(null)

    try {
      const response = await fetch("/api/services")
      const data = await response.json()
      setResult({
        success: response.ok,
        data,
      })
    } catch (error) {
      setResult({
        success: false,
        error: "Error al realizar la solicitud",
      })
    } finally {
      setLoading(false)
    }
  }

  const createService = async () => {
    if (!session?.user.id) {
      setResult({
        success: false,
        error: "Debes iniciar sesión para crear un servicio",
      })
      return
    }

    if (!session?.user.isFreelancer) {
      setResult({
        success: false,
        error: "Solo los freelancers pueden crear servicios",
      })
      return
    }

    setLoading(true)
    setResult(null)

    try {
      const response = await fetch("/api/services", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(serviceData),
      })

      const data = await response.json()
      setResult({
        success: response.ok,
        data,
      })
    } catch (error) {
      setResult({
        success: false,
        error: "Error al realizar la solicitud",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Prueba de Servicios</CardTitle>
        <CardDescription>Obtén y crea servicios</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="title">Título del servicio</Label>
              <Input
                id="title"
                name="title"
                value={serviceData.title}
                onChange={handleChange}
                placeholder="Diseño de logotipo"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="description">Descripción</Label>
              <Textarea
                id="description"
                name="description"
                value={serviceData.description}
                onChange={handleChange}
                placeholder="Descripción del servicio..."
                rows={3}
              />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="price">Precio ($)</Label>
                <Input
                  id="price"
                  name="price"
                  type="number"
                  value={serviceData.price}
                  onChange={handleChange}
                  placeholder="50"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="deliveryTime">Tiempo de entrega (días)</Label>
                <Input
                  id="deliveryTime"
                  name="deliveryTime"
                  type="number"
                  value={serviceData.deliveryTime}
                  onChange={handleChange}
                  placeholder="3"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="revisions">Revisiones</Label>
                <Input
                  id="revisions"
                  name="revisions"
                  type="number"
                  value={serviceData.revisions}
                  onChange={handleChange}
                  placeholder="2"
                />
              </div>
            </div>
          </div>

          {result && (
            <Alert variant={result.success ? "default" : "destructive"}>
              <div className="flex items-center gap-2">
                {result.success ? <CheckCircle className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
                <AlertTitle>{result.success ? "Operación exitosa" : "Error"}</AlertTitle>
              </div>
              <div className="mt-2">
                <pre className="whitespace-pre-wrap text-xs bg-muted p-2 rounded-md overflow-auto max-h-40">
                  {JSON.stringify(result.data || result.error, null, 2)}
                </pre>
              </div>
            </Alert>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button onClick={getServices} disabled={loading}>
          {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          Obtener servicios
        </Button>
        <Button onClick={createService} disabled={loading} variant="outline">
          {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          Crear servicio
        </Button>
      </CardFooter>
    </Card>
  )
}

function MessagesTest() {
  const { data: session } = useSession()
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [conversationId, setConversationId] = useState("")
  const [freelancerId, setFreelancerId] = useState("")
  const [messageContent, setMessageContent] = useState("")

  const getConversations = async () => {
    if (!session?.user.id) {
      setResult({
        success: false,
        error: "Debes iniciar sesión para obtener conversaciones",
      })
      return
    }

    setLoading(true)
    setResult(null)

    try {
      const response = await fetch("/api/conversations")
      const data = await response.json()
      setResult({
        success: response.ok,
        data,
      })
    } catch (error) {
      setResult({
        success: false,
        error: "Error al realizar la solicitud",
      })
    } finally {
      setLoading(false)
    }
  }

  const createConversation = async () => {
    if (!session?.user.id) {
      setResult({
        success: false,
        error: "Debes iniciar sesión para crear una conversación",
      })
      return
    }

    if (!freelancerId) {
      setResult({
        success: false,
        error: "Debes proporcionar el ID del freelancer",
      })
      return
    }

    setLoading(true)
    setResult(null)

    try {
      const response = await fetch("/api/conversations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          freelancerId,
          subject: "Conversación de prueba",
        }),
      })

      const data = await response.json()
      if (response.ok && data.conversationId) {
        setConversationId(data.conversationId)
      }
      setResult({
        success: response.ok,
        data,
      })
    } catch (error) {
      setResult({
        success: false,
        error: "Error al realizar la solicitud",
      })
    } finally {
      setLoading(false)
    }
  }

  const sendMessage = async () => {
    if (!session?.user.id) {
      setResult({
        success: false,
        error: "Debes iniciar sesión para enviar un mensaje",
      })
      return
    }

    if (!conversationId) {
      setResult({
        success: false,
        error: "Debes proporcionar el ID de la conversación",
      })
      return
    }

    if (!messageContent) {
      setResult({
        success: false,
        error: "El mensaje no puede estar vacío",
      })
      return
    }

    setLoading(true)
    setResult(null)

    try {
      const response = await fetch(`/api/conversations/${conversationId}/messages`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          content: messageContent,
        }),
      })

      const data = await response.json()
      setResult({
        success: response.ok,
        data,
      })
    } catch (error) {
      setResult({
        success: false,
        error: "Error al realizar la solicitud",
      })
    } finally {
      setLoading(false)
    }
  }

  const getMessages = async () => {
    if (!session?.user.id) {
      setResult({
        success: false,
        error: "Debes iniciar sesión para obtener mensajes",
      })
      return
    }

    if (!conversationId) {
      setResult({
        success: false,
        error: "Debes proporcionar el ID de la conversación",
      })
      return
    }

    setLoading(true)
    setResult(null)

    try {
      const response = await fetch(`/api/conversations/${conversationId}/messages`)
      const data = await response.json()
      setResult({
        success: response.ok,
        data,
      })
    } catch (error) {
      setResult({
        success: false,
        error: "Error al realizar la solicitud",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Prueba de Mensajes</CardTitle>
        <CardDescription>Gestiona conversaciones y mensajes</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="freelancerId">ID del Freelancer</Label>
              <Input
                id="freelancerId"
                value={freelancerId}
                onChange={(e) => setFreelancerId(e.target.value)}
                placeholder="ID del freelancer para crear conversación"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="conversationId">ID de la Conversación</Label>
              <Input
                id="conversationId"
                value={conversationId}
                onChange={(e) => setConversationId(e.target.value)}
                placeholder="ID de la conversación existente"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="messageContent">Mensaje</Label>
              <Textarea
                id="messageContent"
                value={messageContent}
                onChange={(e) => setMessageContent(e.target.value)}
                placeholder="Escribe tu mensaje aquí..."
                rows={3}
              />
            </div>
          </div>

          {result && (
            <Alert variant={result.success ? "default" : "destructive"}>
              <div className="flex items-center gap-2">
                {result.success ? <CheckCircle className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
                <AlertTitle>{result.success ? "Operación exitosa" : "Error"}</AlertTitle>
              </div>
              <div className="mt-2">
                <pre className="whitespace-pre-wrap text-xs bg-muted p-2 rounded-md overflow-auto max-h-40">
                  {JSON.stringify(result.data || result.error, null, 2)}
                </pre>
              </div>
            </Alert>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex flex-wrap gap-2">
        <Button onClick={getConversations} disabled={loading} size="sm">
          {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          Obtener conversaciones
        </Button>
        <Button onClick={createConversation} disabled={loading} size="sm" variant="outline">
          {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          Crear conversación
        </Button>
        <Button onClick={getMessages} disabled={loading} size="sm">
          {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          Obtener mensajes
        </Button>
        <Button onClick={sendMessage} disabled={loading} size="sm" variant="outline">
          {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          Enviar mensaje
        </Button>
      </CardFooter>
    </Card>
  )
}
