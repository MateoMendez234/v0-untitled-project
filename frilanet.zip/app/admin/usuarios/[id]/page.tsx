import Link from "next/link"
import Image from "next/image"
import { notFound } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import { ArrowLeft, Edit } from "lucide-react"

export default async function AdminUserDetailsPage({ params }: { params: { id: string } }) {
  const supabase = createServerSupabaseClient()

  // Obtener detalles del usuario
  const { data: user, error } = await supabase.from("profiles").select("*").eq("id", params.id).single()

  if (error || !user) {
    console.error("Error al obtener usuario:", error)
    notFound()
  }

  // Obtener servicios del usuario si es freelancer
  let services = []
  if (user.is_freelancer) {
    const { data: userServices } = await supabase.from("services").select("*").eq("profile_id", user.id)

    services = userServices || []
  }

  // Obtener pedidos del usuario
  const { data: orders } = await supabase.from("orders").select("*, services(title)").eq("client_id", user.id)

  // Obtener habilidades del usuario
  const { data: skills } = await supabase.from("skills").select("skill").eq("profile_id", user.id)

  // Obtener idiomas del usuario
  const { data: languages } = await supabase.from("languages").select("language").eq("profile_id", user.id)

  return (
    <div>
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" size="sm" asChild>
          <Link href="/admin/usuarios">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Volver
          </Link>
        </Button>
        <h1 className="text-2xl font-bold">Detalles del Usuario</h1>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Información del perfil */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Perfil</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center mb-6">
              <div className="relative w-24 h-24 rounded-full overflow-hidden mb-4">
                <Image
                  src={user.avatar_url || "/placeholder.svg?height=96&width=96"}
                  alt={user.name || ""}
                  className="object-cover"
                  fill
                />
              </div>
              <h3 className="font-bold text-lg">{user.name}</h3>
              <p className="text-gray-600">{user.title || "Sin título"}</p>
              
              <div className="mt-2">
                {user.is_admin && (
                  <span className="bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded-full mr-2">
                    Admin
                  </span>
                )}
                {user.is_freelancer && (
                  <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full mr-2">
                    Freelancer
                  </span>
                )}
                <span className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded-full">
                  Cliente
                </span>
              </div>
            </div>
            
            <div className="space-y-4">
              <div>
                <p className="text-sm font-medium text-gray-500">Email</p>
                <p>{user.email}</p>
              </div>
              
              <div>
                <p className="text-sm font-medium text-gray-500">Username</p>
                <p>{user.username || "No definido"}</p>
              </div>
              
              <div>
                <p className="text-sm font-medium text-gray-500">Fecha de registro</p>
                <p>{new Date(user.created_at).toLocaleDateString()}</p>
              </div>
              
              <div>
                <p className="text-sm font-medium text-gray-500">Última actividad</p>
                <p>{user.last_active ? new Date(user.last_active).toLocaleDateString() : "N/A"}</p>
              </div>
              
              <Button className="w-full bg-blue-600 hover:bg-blue-700" asChild>
                <Link href={`/admin/usuarios/editar/${user.id}`}>
                  <Edit className="h-4 w-4 mr-2" />
                  Editar Usuario
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
        
        {/* Pestañas con información adicional */}
        <Card className="lg:col-span-2">
          <CardContent className="p-0">
            <Tabs defaultValue="info">
              <TabsList className="w-full rounded-none border-b">
                <TabsTrigger value="info" className="flex-1">Información</TabsTrigger>
                <TabsTrigger value="services" className="flex-1">Servicios</TabsTrigger>
                <TabsTrigger value="orders" className="flex-1">Pedidos</TabsTrigger>
              </TabsList>
              
              {/* Información adicional */}
              <TabsContent value="info" className="p-4">
                <div className="space-y-6">
                  {/* Biografía */}
                  <div>
                    <h3 className="font-medium mb-2">Biografía</h3>
                    <p className="text-gray-600">{user.bio || "No hay biografía disponible"}</p>
                  </div>
                  
                  {/* Habilidades */}
                  <div>
                    <h3 className="font-medium mb-2">Habilidades</h3>
                    {skills && skills.length > 0 ? (
                      <div className="flex flex-wrap gap-2">
                        {skills.map((skill, index) => (
                          <span
                            key={index}
                            className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full"
                          >
                            {skill.skill}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-600">No hay habilidades registradas</p>
                    )}
                  </div>
                  
                  {/* Idiomas */}
                  <div>
                    <h3 className="font-medium mb-2">Idiomas</h3>
                    {languages && languages.length > 0 ? (
                      <div className="flex flex-wrap gap-2">
                        {languages.map((language, index) => (
                          <span
                            key={index}
                            className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full"
                          >
                            {language.language}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-600">No hay idiomas registrados</p>
                    )}
                  </div>
                  
                  {/* Ubicación */}
                  <div>
                    <h3 className="font-medium mb-2">Ubicación</h3>
                    <p className="text-gray-600">{user.location || "No especificada"}</p>
                  </div>
                </div>
              </TabsContent>
              
              {/* Servicios */}
              <TabsContent value="services" className="p-4">
                {user.is_freelancer ? (
                  services.length > 0 ? (
                    <div className="space-y-4">
                      {services.map((service) => (
                        <div key={service.id} className="border rounded-md p-4">
                          <h3 className="font-medium">{service.title}</h3>
                          <p className="text-sm text-gray-600 mt-1">{service.description}</p>
                          <div className="flex justify-between items-center mt-2">
                            <span className="font-bold">€{service.price.toFixed(2)}</span>
                            <Button variant="outline" size="sm" asChild>
                              <Link href={`/admin/servicios/${service.id}`}>
                                Ver detalles
                              </Link>
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-center py-4 text-gray-500">Este freelancer no tiene servicios</p>
                  )
                ) : (
                  <p className="text-center py-4 text-gray-500">Este usuario no es freelancer</p>
                )}
              </TabsContent>
              
              {/* Pedidos */}
              <TabsContent value="orders" className="p-4">
                {orders && orders.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          <th className="px-4 py-2">ID</th>
                          <th className="px-4 py-2">Servicio</th>
                          <th className="px-4 py-2">Importe</th>
                          <th className="px-4 py-2">Estado</th>
                          <th className="px-4 py-2">Fecha</th>
                        </tr>
                      </thead>
                      <tbody>
                        {orders.map((order) => (
                          <tr key={order.id} className="border-t">
                            <td className="px-4 py-2">{order.id.substring(0, 8)}</td>
                            <td className="px-4 py-2">{order.services?.title || "Desconocido"}</td>
                            <td className="px-4 py-2">€{order.amount.toFixed(2)}</td>
                            <td className="px-4 py-2">
                              <span
                                className={`text-xs px-2 py-1 rounded-full ${
                                  order.status === "completed"
                                    ? "bg-green-100 text-green-800"
                                    : order.status === "paid"
                                      ? "bg-blue-100 text-blue-800"
                                      : order.status === "pending"
                                        ? "bg-yellow-100 text-yellow-800"
                                        : "bg-red-100 text-red-800"
                                }`}
                              >
                                {order.status === "completed"
                                  ? "Completado"
                                  : order.status === "paid"
                                    ? "En progreso"
                                    : order.status === "pending"
                                        ? "Pendiente"
                                        : "Cancelado"
                              </span>\
                            </td>
                            <td className="px-4 py-2">
                              {new Date(order.created_at).toLocaleDateString()}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="text-center py-4 text-gray-500">Este usuario no tiene pedidos</p>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
