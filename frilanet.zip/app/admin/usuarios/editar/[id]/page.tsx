import { notFound } from "next/navigation"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import { UserEditForm } from "@/components/admin/user-edit-form"

export default async function AdminEditUserPage({ params }: { params: { id: string } }) {
  const supabase = createServerSupabaseClient()

  // Obtener detalles del usuario
  const { data: user, error } = await supabase.from("profiles").select("*").eq("id", params.id).single()

  if (error || !user) {
    console.error("Error al obtener usuario:", error)
    notFound()
  }

  // Obtener habilidades del usuario
  const { data: skills } = await supabase.from("skills").select("skill").eq("profile_id", user.id)

  // Obtener idiomas del usuario
  const { data: languages } = await supabase.from("languages").select("language").eq("profile_id", user.id)

  const userData = {
    ...user,
    skills: skills?.map((s) => s.skill) || [],
    languages: languages?.map((l) => l.language) || [],
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Editar Usuario</h1>
      <UserEditForm user={userData} />
    </div>
  )
}
