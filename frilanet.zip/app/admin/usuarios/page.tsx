import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import { Eye, Edit, Trash2 } from "lucide-react"

export default async function AdminUsersPage() {
  const supabase = createServerSupabaseClient()

  // Obtener todos los usuarios
  const { data: users, error } = await supabase.from("profiles").select("*").order("created_at", { ascending: false })

  if (error) {
    console.error("Error al obtener usuarios:", error)
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Gestión de Usuarios</h1>
        <Button className="bg-blue-600 hover:bg-blue-700">
          <Link href="/admin/usuarios/nuevo">Crear Usuario</Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Usuarios</CardTitle>
        </CardHeader>
        <CardContent>
          {users && users.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    <th className="px-4 py-2">Nombre</th>
                    <th className="px-4 py-2">Email</th>
                    <th className="px-4 py-2">Tipo</th>
                    <th className="px-4 py-2">Fecha de registro</th>
                    <th className="px-4 py-2">Última actividad</th>
                    <th className="px-4 py-2">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((user) => (
                    <tr key={user.id} className="border-t">
                      <td className="px-4 py-2">{user.name}</td>
                      <td className="px-4 py-2">{user.email}</td>
                      <td className="px-4 py-2">
                        {user.is_admin ? (
                          <span className="bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded-full">Admin</span>
                        ) : user.is_freelancer ? (
                          <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">Freelancer</span>
                        ) : (
                          <span className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded-full">Cliente</span>
                        )}
                      </td>
                      <td className="px-4 py-2">{new Date(user.created_at).toLocaleDateString()}</td>
                      <td className="px-4 py-2">
                        {user.last_active ? new Date(user.last_active).toLocaleDateString() : "N/A"}
                      </td>
                      <td className="px-4 py-2">
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm" asChild>
                            <Link href={`/admin/usuarios/${user.id}`}>
                              <Eye className="h-4 w-4" />
                            </Link>
                          </Button>
                          <Button variant="outline" size="sm" asChild>
                            <Link href={`/admin/usuarios/editar/${user.id}`}>
                              <Edit className="h-4 w-4" />
                            </Link>
                          </Button>
                          <Button variant="outline" size="sm" className="text-red-500 hover:text-red-700">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-center py-4 text-gray-500">No hay usuarios disponibles</p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
