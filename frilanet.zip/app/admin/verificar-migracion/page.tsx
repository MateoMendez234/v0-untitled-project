"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Loader2, CheckCircle, XCircle, AlertTriangle, RefreshCw } from "lucide-react"

interface MigrationStatus {
  supabase: {
    users: number
    profiles: number
    services: number
    portfolio: number
    conversations: number
    messages: number
    reviews: number
    orders: number
  }
  mongodb: {
    users: number
    profiles: number
    services: number
    portfolio: number
    conversations: number
    messages: number
    reviews: number
    orders: number
  }
  porcentajes: {
    users: number
    profiles: number
    services: number
    portfolio: number
    conversations: number
    messages: number
    reviews: number
    orders: number
  }
  totalPorcentaje: number
}

export default function VerificarMigracionPage() {
  const [loading, setLoading] = useState(false)
  const [migrando, setMigrando] = useState(false)
  const [status, setStatus] = useState<MigrationStatus | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState("resumen")

  const verificarMigracion = async () => {
    setLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/admin/verificar-migracion")

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Error al verificar la migración")
      }

      const data = await response.json()
      setStatus(data)
    } catch (err: any) {
      setError(err.message || "Error al verificar la migración")
    } finally {
      setLoading(false)
    }
  }

  const iniciarMigracion = async () => {
    if (!confirm("¿Estás seguro de que deseas iniciar la migración? Este proceso puede tardar varios minutos.")) {
      return
    }

    setMigrando(true)
    setError(null)

    try {
      const response = await fetch("/api/admin/migrate", {
        method: "POST",
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.error || "Error al iniciar la migración")
      }

      // Esperar 5 segundos y luego verificar el estado
      setTimeout(() => {
        verificarMigracion()
        setMigrando(false)
      }, 5000)
    } catch (err: any) {
      setError(err.message || "Error al iniciar la migración")
      setMigrando(false)
    }
  }

  useEffect(() => {
    verificarMigracion()
  }, [])

  const getStatusColor = (percentage: number) => {
    if (percentage >= 90) return "bg-green-500"
    if (percentage >= 70) return "bg-yellow-500"
    return "bg-red-500"
  }

  const getStatusIcon = (percentage: number) => {
    if (percentage >= 90) return <CheckCircle className="h-5 w-5 text-green-500" />
    if (percentage >= 70) return <AlertTriangle className="h-5 w-5 text-yellow-500" />
    return <XCircle className="h-5 w-5 text-red-500" />
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-6">Verificación de Migración</h1>

      <div className="mb-6 flex items-center gap-4">
        <Button onClick={verificarMigracion} disabled={loading} variant="outline">
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Verificando...
            </>
          ) : (
            <>
              <RefreshCw className="mr-2 h-4 w-4" /> Actualizar estado
            </>
          )}
        </Button>

        <Button onClick={iniciarMigracion} disabled={migrando || loading}>
          {migrando ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Migrando datos...
            </>
          ) : (
            "Iniciar/Continuar Migración"
          )}
        </Button>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-6">
          <XCircle className="h-5 w-5" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {status && (
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="resumen">Resumen</TabsTrigger>
            <TabsTrigger value="detalle">Detalle</TabsTrigger>
          </TabsList>

          <TabsContent value="resumen">
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  {getStatusIcon(status.totalPorcentaje)}
                  Estado General de la Migración
                </CardTitle>
                <CardDescription>Porcentaje total de datos migrados: {status.totalPorcentaje}%</CardDescription>
              </CardHeader>
              <CardContent>
                <Progress value={status.totalPorcentaje} className={getStatusColor(status.totalPorcentaje)} />

                <div className="mt-6">
                  {status.totalPorcentaje >= 90 ? (
                    <Alert>
                      <CheckCircle className="h-5 w-5" />
                      <AlertTitle>Migración completada</AlertTitle>
                      <AlertDescription>
                        La migración se ha completado con éxito. Puedes comenzar a utilizar MongoDB como tu base de
                        datos principal.
                      </AlertDescription>
                    </Alert>
                  ) : status.totalPorcentaje >= 70 ? (
                    <Alert variant="warning">
                      <AlertTriangle className="h-5 w-5" />
                      <AlertTitle>Migración en progreso</AlertTitle>
                      <AlertDescription>
                        La migración está en progreso, pero aún faltan algunos datos por migrar. Considera ejecutar
                        nuevamente la migración.
                      </AlertDescription>
                    </Alert>
                  ) : (
                    <Alert variant="destructive">
                      <XCircle className="h-5 w-5" />
                      <AlertTitle>Migración incompleta</AlertTitle>
                      <AlertDescription>
                        La migración está incompleta. Es necesario ejecutar el proceso de migración.
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="detalle">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {getStatusIcon(status.porcentajes.users)}
                    Usuarios
                  </CardTitle>
                  <CardDescription>
                    Migrados: {status.mongodb.users} de {status.supabase.users} ({status.porcentajes.users}%)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Progress value={status.porcentajes.users} className={getStatusColor(status.porcentajes.users)} />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {getStatusIcon(status.porcentajes.profiles)}
                    Perfiles
                  </CardTitle>
                  <CardDescription>
                    Migrados: {status.mongodb.profiles} de {status.supabase.profiles} ({status.porcentajes.profiles}%)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Progress
                    value={status.porcentajes.profiles}
                    className={getStatusColor(status.porcentajes.profiles)}
                  />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {getStatusIcon(status.porcentajes.services)}
                    Servicios
                  </CardTitle>
                  <CardDescription>
                    Migrados: {status.mongodb.services} de {status.supabase.services} ({status.porcentajes.services}%)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Progress
                    value={status.porcentajes.services}
                    className={getStatusColor(status.porcentajes.services)}
                  />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {getStatusIcon(status.porcentajes.portfolio)}
                    Portfolio
                  </CardTitle>
                  <CardDescription>
                    Migrados: {status.mongodb.portfolio} de {status.supabase.portfolio} ({status.porcentajes.portfolio}
                    %)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Progress
                    value={status.porcentajes.portfolio}
                    className={getStatusColor(status.porcentajes.portfolio)}
                  />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {getStatusIcon(status.porcentajes.conversations)}
                    Conversaciones
                  </CardTitle>
                  <CardDescription>
                    Migrados: {status.mongodb.conversations} de {status.supabase.conversations} (
                    {status.porcentajes.conversations}%)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Progress
                    value={status.porcentajes.conversations}
                    className={getStatusColor(status.porcentajes.conversations)}
                  />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {getStatusIcon(status.porcentajes.messages)}
                    Mensajes
                  </CardTitle>
                  <CardDescription>
                    Migrados: {status.mongodb.messages} de {status.supabase.messages} ({status.porcentajes.messages}%)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Progress
                    value={status.porcentajes.messages}
                    className={getStatusColor(status.porcentajes.messages)}
                  />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {getStatusIcon(status.porcentajes.reviews)}
                    Reseñas
                  </CardTitle>
                  <CardDescription>
                    Migrados: {status.mongodb.reviews} de {status.supabase.reviews} ({status.porcentajes.reviews}%)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Progress value={status.porcentajes.reviews} className={getStatusColor(status.porcentajes.reviews)} />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    {getStatusIcon(status.porcentajes.orders)}
                    Órdenes
                  </CardTitle>
                  <CardDescription>
                    Migrados: {status.mongodb.orders} de {status.supabase.orders} ({status.porcentajes.orders}%)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Progress value={status.porcentajes.orders} className={getStatusColor(status.porcentajes.orders)} />
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      )}

      {!status && !error && (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-700"></div>
        </div>
      )}

      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Pasos para completar la migración</CardTitle>
          <CardDescription>Sigue estos pasos para asegurar una migración exitosa</CardDescription>
        </CardHeader>
        <CardContent>
          <ol className="list-decimal pl-5 space-y-2">
            <li>Verifica que todos los datos se hayan migrado correctamente (porcentaje cercano al 100%)</li>
            <li>Si la migración está incompleta, haz clic en "Iniciar/Continuar Migración"</li>
            <li>Una vez completada la migración, verifica que la aplicación funcione correctamente</li>
            <li>Crea índices en MongoDB para mejorar el rendimiento (esto se hace automáticamente en los modelos)</li>
            <li>Configura backups automáticos para tu base de datos MongoDB</li>
          </ol>
        </CardContent>
        <CardFooter>
          <p className="text-sm text-muted-foreground">
            Nota: La migración puede tardar varios minutos dependiendo de la cantidad de datos. No cierres esta página
            durante el proceso.
          </p>
        </CardFooter>
      </Card>
    </div>
  )
}
