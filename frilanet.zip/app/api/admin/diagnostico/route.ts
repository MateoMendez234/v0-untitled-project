import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { connectToDatabase } from "@/lib/mongodb"
import User from "@/lib/models/user"
import Profile from "@/lib/models/profile"
import Service from "@/lib/models/service"
import PortfolioItem from "@/lib/models/portfolio"
import { Conversation, Message } from "@/lib/models/conversation"
import Review from "@/lib/models/review"
import Order from "@/lib/models/order"

export async function GET() {
  try {
    const session = await getServerSession(authOptions)

    // Verificar autenticación y permisos de administrador
    if (!session || !session.user.isAdmin) {
      return NextResponse.json({ error: "No autorizado" }, { status: 401 })
    }

    // Intentar conectar a MongoDB
    let connection = false
    try {
      await connectToDatabase()
      connection = true
    } catch (error) {
      console.error("Error conectando a MongoDB:", error)
      connection = false
    }

    // Si no hay conexión, devolver resultado temprano
    if (!connection) {
      return NextResponse.json({
        connection: false,
        collections: {
          users: 0,
          profiles: 0,
          services: 0,
          portfolioItems: 0,
          conversations: 0,
          messages: 0,
          reviews: 0,
          orders: 0,
        },
      })
    }

    // Contar documentos en cada colección
    const [
      usersCount,
      profilesCount,
      servicesCount,
      portfolioItemsCount,
      conversationsCount,
      messagesCount,
      reviewsCount,
      ordersCount,
    ] = await Promise.all([
      User.countDocuments(),
      Profile.countDocuments(),
      Service.countDocuments(),
      PortfolioItem.countDocuments(),
      Conversation.countDocuments(),
      Message.countDocuments(),
      Review.countDocuments(),
      Order.countDocuments(),
    ])

    return NextResponse.json({
      connection: true,
      collections: {
        users: usersCount,
        profiles: profilesCount,
        services: servicesCount,
        portfolioItems: portfolioItemsCount,
        conversations: conversationsCount,
        messages: messagesCount,
        reviews: reviewsCount,
        orders: ordersCount,
      },
    })
  } catch (error) {
    console.error("Error en diagnóstico:", error)
    return NextResponse.json(
      {
        connection: false,
        collections: {
          users: 0,
          profiles: 0,
          services: 0,
          portfolioItems: 0,
          conversations: 0,
          messages: 0,
          reviews: 0,
          orders: 0,
        },
        error: "Error interno del servidor",
      },
      { status: 500 },
    )
  }
}
