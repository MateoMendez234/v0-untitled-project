import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { exec } from "child_process"
import { promisify } from "util"
import path from "path"

const execAsync = promisify(exec)

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    // Verificar autenticación y permisos de administrador
    if (!session || !session.user.isAdmin) {
      return NextResponse.json({ error: "No autorizado" }, { status: 401 })
    }

    // Ejecutar el script de migración
    const scriptPath = path.join(process.cwd(), "scripts", "migrate-data.ts")

    // Ejecutar el script con ts-node
    const { stdout, stderr } = await execAsync(`npx ts-node --project tsconfig.json ${scriptPath}`)

    if (stderr) {
      console.error("Error en la migración:", stderr)
      return NextResponse.json({ error: "Error durante la migración", details: stderr }, { status: 500 })
    }

    return NextResponse.json({
      success: true,
      message: "Migración completada con éxito",
      details: stdout,
    })
  } catch (error) {
    console.error("Error ejecutando la migración:", error)
    return NextResponse.json({ error: "Error interno del servidor", details: error }, { status: 500 })
  }
}
