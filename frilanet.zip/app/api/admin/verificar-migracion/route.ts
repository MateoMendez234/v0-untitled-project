import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { connectToDatabase } from "@/lib/mongodb"
import { createClient } from "@supabase/supabase-js"
import User from "@/lib/models/user"
import Profile from "@/lib/models/profile"
import Service from "@/lib/models/service"
import PortfolioItem from "@/lib/models/portfolio"
import { Conversation, Message } from "@/lib/models/conversation"
import Review from "@/lib/models/review"
import Order from "@/lib/models/order"
import type { Database } from "@/lib/database.types"

// Configuración de Supabase
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!

export async function GET() {
  try {
    const session = await getServerSession(authOptions)

    // Verificar autenticación y permisos de administrador
    if (!session || !session.user.isAdmin) {
      return NextResponse.json({ error: "No autorizado" }, { status: 401 })
    }

    // Conectar a MongoDB
    await connectToDatabase()

    // Conectar a Supabase
    const supabase = createClient<Database>(supabaseUrl, supabaseKey)

    // Obtener conteos de Supabase
    const [
      { count: supabaseUsersCount },
      { count: supabaseProfilesCount },
      { count: supabaseServicesCount },
      { count: supabasePortfolioCount },
      { count: supabaseConversationsCount },
      { count: supabaseMessagesCount },
      { count: supabaseReviewsCount },
      { count: supabaseOrdersCount },
    ] = await Promise.all([
      supabase.from("auth.users").select("*", { count: "exact", head: true }),
      supabase.from("profiles").select("*", { count: "exact", head: true }),
      supabase.from("services").select("*", { count: "exact", head: true }),
      supabase.from("portfolio").select("*", { count: "exact", head: true }),
      supabase.from("conversations").select("*", { count: "exact", head: true }),
      supabase.from("messages").select("*", { count: "exact", head: true }),
      supabase.from("reviews").select("*", { count: "exact", head: true }),
      supabase.from("orders").select("*", { count: "exact", head: true }),
    ])

    // Obtener conteos de MongoDB
    const [
      mongoUsersCount,
      mongoProfilesCount,
      mongoServicesCount,
      mongoPortfolioCount,
      mongoConversationsCount,
      mongoMessagesCount,
      mongoReviewsCount,
      mongoOrdersCount,
    ] = await Promise.all([
      User.countDocuments(),
      Profile.countDocuments(),
      Service.countDocuments(),
      PortfolioItem.countDocuments(),
      Conversation.countDocuments(),
      Message.countDocuments(),
      Review.countDocuments(),
      Order.countDocuments(),
    ])

    // Calcular porcentajes de migración
    const calculatePercentage = (mongo: number, supabase: number) => {
      if (supabase === 0) return 100 // Si no hay datos en Supabase, consideramos 100% migrado
      return Math.round((mongo / supabase) * 100)
    }

    const result = {
      supabase: {
        users: supabaseUsersCount || 0,
        profiles: supabaseProfilesCount || 0,
        services: supabaseServicesCount || 0,
        portfolio: supabasePortfolioCount || 0,
        conversations: supabaseConversationsCount || 0,
        messages: supabaseMessagesCount || 0,
        reviews: supabaseReviewsCount || 0,
        orders: supabaseOrdersCount || 0,
      },
      mongodb: {
        users: mongoUsersCount,
        profiles: mongoProfilesCount,
        services: mongoServicesCount,
        portfolio: mongoPortfolioCount,
        conversations: mongoConversationsCount,
        messages: mongoMessagesCount,
        reviews: mongoReviewsCount,
        orders: mongoOrdersCount,
      },
      porcentajes: {
        users: calculatePercentage(mongoUsersCount, supabaseUsersCount || 0),
        profiles: calculatePercentage(mongoProfilesCount, supabaseProfilesCount || 0),
        services: calculatePercentage(mongoServicesCount, supabaseServicesCount || 0),
        portfolio: calculatePercentage(mongoPortfolioCount, supabasePortfolioCount || 0),
        conversations: calculatePercentage(mongoConversationsCount, supabaseConversationsCount || 0),
        messages: calculatePercentage(mongoMessagesCount, supabaseMessagesCount || 0),
        reviews: calculatePercentage(mongoReviewsCount, supabaseReviewsCount || 0),
        orders: calculatePercentage(mongoOrdersCount, supabaseOrdersCount || 0),
      },
      totalPorcentaje: calculatePercentage(
        mongoUsersCount +
          mongoProfilesCount +
          mongoServicesCount +
          mongoPortfolioCount +
          mongoConversationsCount +
          mongoMessagesCount +
          mongoReviewsCount +
          mongoOrdersCount,
        (supabaseUsersCount || 0) +
          (supabaseProfilesCount || 0) +
          (supabaseServicesCount || 0) +
          (supabasePortfolioCount || 0) +
          (supabaseConversationsCount || 0) +
          (supabaseMessagesCount || 0) +
          (supabaseReviewsCount || 0) +
          (supabaseOrdersCount || 0),
      ),
    }

    return NextResponse.json(result)
  } catch (error: any) {
    console.error("Error verificando migración:", error)
    return NextResponse.json(
      {
        error: "Error verificando migración",
        details: error.message,
      },
      { status: 500 },
    )
  }
}
