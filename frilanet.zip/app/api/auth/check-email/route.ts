import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Usar el cliente estándar para el rol de servicio
function createServiceRoleClient() {
  return createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const email = searchParams.get("email")

    if (!email) {
      return NextResponse.json({ error: "Email es requerido" }, { status: 400 })
    }

    // Cliente con rol de servicio
    const supabaseAdmin = createServiceRoleClient()

    // Verificar si el usuario ya existe
    const { data: existingUser } = await supabaseAdmin.auth.admin.listUsers({
      filter: {
        email: email,
      },
    })

    const exists = existingUser && existingUser.users.length > 0

    return NextResponse.json({ exists })
  } catch (error) {
    console.error("Error al verificar email:", error)
    return NextResponse.json({ error: "Error en el servidor", exists: false }, { status: 500 })
  }
}
