import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Usar el cliente estándar para el rol de servicio
function createServiceRoleClient() {
  return createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
}

export async function POST(request: NextRequest) {
  try {
    const { email, password, name, isFreelancer } = await request.json()

    // Validar datos
    if (!email || !password || !name) {
      return NextResponse.json({ error: "Faltan campos requeridos" }, { status: 400 })
    }

    // Cliente con rol de servicio
    const supabaseAdmin = createServiceRoleClient()

    // Crear usuario con email_confirm=true para que no necesite confirmación
    const { data: userData, error: userError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: {
        name,
        is_freelancer: isFreelancer,
      },
    })

    if (userError) {
      return NextResponse.json({ error: userError.message }, { status: 500 })
    }

    // Crear perfil en la tabla profiles
    if (userData.user) {
      const { error: profileError } = await supabaseAdmin.from("profiles").insert({
        id: userData.user.id,
        username: email.split("@")[0],
        name,
        email,
        is_freelancer: isFreelancer,
      })

      if (profileError) {
        // Si falla la creación del perfil, eliminar el usuario para mantener consistencia
        await supabaseAdmin.auth.admin.deleteUser(userData.user.id)
        return NextResponse.json({ error: profileError.message }, { status: 500 })
      }
    }

    return NextResponse.json({
      success: true,
      user: {
        id: userData.user.id,
        email: userData.user.email,
      },
    })
  } catch (error) {
    console.error("Error al crear usuario de prueba:", error)
    return NextResponse.json({ error: "Error en el servidor" }, { status: 500 })
  }
}
