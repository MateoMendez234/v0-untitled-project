import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

// Usar el cliente estándar para el rol de servicio
function createServiceRoleClient() {
  return createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
}

export async function POST(request: NextRequest) {
  try {
    const { email } = await request.json()

    // Validar datos
    if (!email) {
      return NextResponse.json({ error: "Falta el correo electrónico" }, { status: 400 })
    }

    // Cliente con rol de servicio
    const supabaseAdmin = createServiceRoleClient()

    // Verificar si el usuario existe en auth.users
    const { data: authUsers, error: authError } = await supabaseAdmin.auth.admin.listUsers({
      filter: {
        email: email,
      },
    })

    if (authError) {
      return NextResponse.json({ error: authError.message }, { status: 500 })
    }

    // Verificar si el perfil existe en la tabla profiles
    const { data: profileData, error: profileError } = await supabaseAdmin
      .from("profiles")
      .select("*")
      .eq("email", email)
      .maybeSingle()

    if (profileError) {
      return NextResponse.json({ error: profileError.message }, { status: 500 })
    }

    return NextResponse.json({
      authUser:
        authUsers?.users?.length > 0
          ? {
              id: authUsers.users[0].id,
              email: authUsers.users[0].email,
              emailConfirmed: authUsers.users[0].email_confirmed_at !== null,
              createdAt: authUsers.users[0].created_at,
            }
          : null,
      profile: profileData,
    })
  } catch (error) {
    console.error("Error en la depuración:", error)
    return NextResponse.json({ error: "Error en el servidor" }, { status: 500 })
  }
}
