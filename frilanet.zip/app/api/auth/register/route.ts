import { NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"
import User from "@/lib/models/user"
import Profile from "@/lib/models/profile"

export async function POST(request: Request) {
  try {
    const { name, email, password, isFreelancer = false } = await request.json()

    // Validar datos
    if (!name || !email || !password) {
      return NextResponse.json({ error: "Faltan campos requeridos" }, { status: 400 })
    }

    await connectToDatabase()

    // Verificar si el usuario ya existe
    const existingUser = await User.findOne({ email: email.toLowerCase() })
    if (existingUser) {
      return NextResponse.json({ error: "El correo electrónico ya está registrado" }, { status: 409 })
    }

    // Crear usuario
    const user = new User({
      name,
      email: email.toLowerCase(),
      password,
      isFreelancer,
    })

    await user.save()

    // Crear perfil básico
    const username = email.split("@")[0].toLowerCase()
    const profile = new Profile({
      userId: user._id,
      username,
      name,
      email: email.toLowerCase(),
      isFreelancer,
      memberSince: new Date(),
      lastActive: new Date(),
      avatarUrl: "/placeholder.svg?height=150&width=150",
      coverImageUrl: "/placeholder.svg?height=400&width=1200",
    })

    await profile.save()

    return NextResponse.json({
      success: true,
      message: "Usuario registrado correctamente",
    })
  } catch (error) {
    console.error("Error al registrar usuario:", error)
    return NextResponse.json({ error: "Error en el servidor" }, { status: 500 })
  }
}
