import { NextResponse } from "next/server"
import { createServerSupabaseClient } from "@/lib/supabase/server"

export async function GET() {
  try {
    const supabase = createServerSupabaseClient()

    // Obtener la sesión actual
    const { data: sessionData, error: sessionError } = await supabase.auth.getSession()

    if (sessionError) {
      return NextResponse.json({ error: sessionError.message }, { status: 500 })
    }

    // Devolver información sobre la sesión (sin tokens sensibles)
    return NextResponse.json({
      authenticated: !!sessionData.session,
      user: sessionData.session?.user
        ? {
            id: sessionData.session.user.id,
            email: sessionData.session.user.email,
            role: sessionData.session.user.role,
          }
        : null,
      sessionExpires: sessionData.session?.expires_at,
    })
  } catch (error) {
    console.error("Error al obtener la sesión:", error)
    return NextResponse.json({ error: "Error al obtener la sesión" }, { status: 500 })
  }
}
