import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { connectToDatabase } from "@/lib/mongodb"
import { Conversation, Message } from "@/lib/models/conversation"
import { Types } from "mongoose"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)

    // Verificar autenticación
    if (!session) {
      return NextResponse.json({ error: "No autorizado" }, { status: 401 })
    }

    const conversationId = params.id

    await connectToDatabase()

    // Verificar que la conversación existe y que el usuario es participante
    const conversation = await Conversation.findById(conversationId)

    if (!conversation) {
      return NextResponse.json({ error: "Conversación no encontrada" }, { status: 404 })
    }

    // Verificar que el usuario es participante de la conversación
    const isParticipant =
      conversation.userId.toString() === session.user.id || conversation.freelancerId.toString() === session.user.id

    if (!isParticipant) {
      return NextResponse.json({ error: "No tienes permiso para ver esta conversación" }, { status: 403 })
    }

    // Obtener mensajes
    const messages = await Message.find({ conversationId: new Types.ObjectId(conversationId) }).sort({
      createdAt: 1,
    })

    return NextResponse.json(
      messages.map((message) => ({
        id: message._id.toString(),
        conversationId: message.conversationId.toString(),
        senderId: message.senderId.toString(),
        content: message.content,
        createdAt: message.createdAt,
        isRead: message.isRead,
      })),
    )
  } catch (error) {
    console.error("Error obteniendo mensajes:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}

export async function POST(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)

    // Verificar autenticación
    if (!session) {
      return NextResponse.json({ error: "No autorizado" }, { status: 401 })
    }

    const conversationId = params.id
    const { content } = await request.json()

    if (!content) {
      return NextResponse.json({ error: "El contenido del mensaje es requerido" }, { status: 400 })
    }

    await connectToDatabase()

    // Verificar que la conversación existe y que el usuario es participante
    const conversation = await Conversation.findById(conversationId)

    if (!conversation) {
      return NextResponse.json({ error: "Conversación no encontrada" }, { status: 404 })
    }

    // Verificar que el usuario es participante de la conversación
    const isParticipant =
      conversation.userId.toString() === session.user.id || conversation.freelancerId.toString() === session.user.id

    if (!isParticipant) {
      return NextResponse.json(
        { error: "No tienes permiso para enviar mensajes en esta conversación" },
        { status: 403 },
      )
    }

    // Crear mensaje
    const message = new Message({
      conversationId: new Types.ObjectId(conversationId),
      senderId: new Types.ObjectId(session.user.id),
      content,
    })

    await message.save()

    // Actualizar la conversación con el último mensaje
    await Conversation.findByIdAndUpdate(conversationId, {
      lastMessage: content,
      lastMessageAt: new Date(),
    })

    return NextResponse.json({
      success: true,
      messageId: message._id.toString(),
    })
  } catch (error) {
    console.error("Error enviando mensaje:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}
