import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { connectToDatabase } from "@/lib/mongodb"
import { Conversation } from "@/lib/models/conversation"
import Profile from "@/lib/models/profile"
import { Types } from "mongoose"

export async function GET(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    // Verificar autenticación
    if (!session) {
      return NextResponse.json({ error: "No autorizado" }, { status: 401 })
    }

    await connectToDatabase()

    // Obtener todas las conversaciones del usuario
    const conversations = await Conversation.find({
      $or: [{ userId: new Types.ObjectId(session.user.id) }, { freelancerId: new Types.ObjectId(session.user.id) }],
    }).sort({ updatedAt: -1 })

    // Obtener detalles adicionales para cada conversación
    const conversationsWithDetails = await Promise.all(
      conversations.map(async (conversation) => {
        // Determinar si el usuario actual es el freelancer o el cliente
        const isFreelancer = conversation.freelancerId.toString() === session.user.id

        // Obtener información del otro participante
        const otherParticipantId = isFreelancer ? conversation.userId : conversation.freelancerId
        const otherProfile = await Profile.findOne({ userId: otherParticipantId })

        return {
          id: conversation._id.toString(),
          userId: conversation.userId.toString(),
          freelancerId: conversation.freelancerId.toString(),
          subject: conversation.subject,
          serviceId: conversation.serviceId?.toString(),
          lastMessage: conversation.lastMessage,
          lastMessageAt: conversation.lastMessageAt,
          createdAt: conversation.createdAt,
          updatedAt: conversation.updatedAt,
          otherParticipant: otherProfile
            ? {
                id: otherProfile._id.toString(),
                name: otherProfile.name,
                username: otherProfile.username,
                avatarUrl: otherProfile.avatarUrl,
              }
            : null,
        }
      }),
    )

    return NextResponse.json(conversationsWithDetails)
  } catch (error) {
    console.error("Error obteniendo conversaciones:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    // Verificar autenticación
    if (!session) {
      return NextResponse.json({ error: "No autorizado" }, { status: 401 })
    }

    const data = await request.json()
    const { freelancerId, subject, serviceId } = data

    if (!freelancerId) {
      return NextResponse.json({ error: "Se requiere el ID del freelancer" }, { status: 400 })
    }

    await connectToDatabase()

    // Verificar si ya existe una conversación entre estos usuarios
    const existingConversation = await Conversation.findOne({
      userId: new Types.ObjectId(session.user.id),
      freelancerId: new Types.ObjectId(freelancerId),
    })

    if (existingConversation) {
      return NextResponse.json({
        success: true,
        conversationId: existingConversation._id.toString(),
        message: "Ya existe una conversación con este freelancer",
      })
    }

    // Crear nueva conversación
    const conversation = new Conversation({
      userId: new Types.ObjectId(session.user.id),
      freelancerId: new Types.ObjectId(freelancerId),
      subject: subject || "Nueva conversación",
      serviceId: serviceId ? new Types.ObjectId(serviceId) : undefined,
    })

    await conversation.save()

    return NextResponse.json({
      success: true,
      conversationId: conversation._id.toString(),
    })
  } catch (error) {
    console.error("Error creando conversación:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}
