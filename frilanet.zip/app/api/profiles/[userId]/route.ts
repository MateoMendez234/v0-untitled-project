import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { connectToDatabase } from "@/lib/mongodb"
import Profile from "@/lib/models/profile"
import { Types } from "mongoose"

export async function GET(request: Request, { params }: { params: { userId: string } }) {
  try {
    const session = await getServerSession(authOptions)
    const userId = params.userId

    // Verificar autenticación para perfiles privados
    if (!session && userId !== "public") {
      return NextResponse.json({ error: "No autorizado" }, { status: 401 })
    }

    await connectToDatabase()

    const profile = await Profile.findOne({ userId: new Types.ObjectId(userId) })

    if (!profile) {
      return NextResponse.json({ error: "Perfil no encontrado" }, { status: 404 })
    }

    // Obtener habilidades y lenguajes
    const skills = profile.skills || []
    const languages = profile.languages || []

    return NextResponse.json({
      _id: profile._id.toString(),
      userId: profile.userId.toString(),
      username: profile.username,
      name: profile.name,
      title: profile.title,
      avatarUrl: profile.avatarUrl,
      coverImageUrl: profile.coverImageUrl,
      location: profile.location,
      about: profile.about,
      email: profile.email,
      phone: profile.phone,
      website: profile.website,
      memberSince: profile.memberSince,
      lastActive: profile.lastActive,
      completionRate: profile.completionRate,
      responseTime: profile.responseTime,
      isFreelancer: profile.isFreelancer,
      skills,
      languages,
      createdAt: profile.createdAt,
      updatedAt: profile.updatedAt,
    })
  } catch (error) {
    console.error("Error obteniendo perfil:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}

export async function PUT(request: Request, { params }: { params: { userId: string } }) {
  try {
    const session = await getServerSession(authOptions)
    const userId = params.userId

    // Verificar autenticación
    if (!session) {
      return NextResponse.json({ error: "No autorizado" }, { status: 401 })
    }

    // Verificar que el usuario solo puede actualizar su propio perfil
    if (session.user.id !== userId && !session.user.isAdmin) {
      return NextResponse.json({ error: "No tienes permiso para actualizar este perfil" }, { status: 403 })
    }

    const data = await request.json()

    await connectToDatabase()

    // Buscar el perfil existente
    const existingProfile = await Profile.findOne({ userId: new Types.ObjectId(userId) })

    if (existingProfile) {
      // Actualizar perfil existente
      await Profile.findByIdAndUpdate(existingProfile._id, {
        ...data,
        lastActive: new Date(),
      })
    } else {
      // Crear nuevo perfil
      const newProfile = new Profile({
        userId: new Types.ObjectId(userId),
        ...data,
        memberSince: new Date(),
        lastActive: new Date(),
      })
      await newProfile.save()
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error actualizando perfil:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}
