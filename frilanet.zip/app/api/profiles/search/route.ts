import { NextResponse } from "next/server"
import { connectToDatabase } from "@/lib/mongodb"
import Profile from "@/lib/models/profile"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const query = searchParams.get("q") || ""
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const offset = Number.parseInt(searchParams.get("offset") || "0")
    const isFreelancer = searchParams.get("freelancer") === "true"

    await connectToDatabase()

    // Construir la consulta
    const searchQuery: any = {}

    if (isFreelancer) {
      searchQuery.isFreelancer = true
    }

    if (query) {
      searchQuery.$or = [
        { name: { $regex: query, $options: "i" } },
        { username: { $regex: query, $options: "i" } },
        { title: { $regex: query, $options: "i" } },
        { location: { $regex: query, $options: "i" } },
        { skills: { $regex: query, $options: "i" } },
      ]
    }

    // Ejecutar la consulta
    const profiles = await Profile.find(searchQuery).sort({ lastActive: -1 }).skip(offset).limit(limit)

    // Contar el total de resultados
    const total = await Profile.countDocuments(searchQuery)

    // Formatear los resultados
    const results = profiles.map((profile) => ({
      _id: profile._id.toString(),
      userId: profile.userId.toString(),
      username: profile.username,
      name: profile.name,
      title: profile.title,
      avatarUrl: profile.avatarUrl,
      location: profile.location,
      isFreelancer: profile.isFreelancer,
      skills: profile.skills,
      languages: profile.languages,
    }))

    return NextResponse.json({
      results,
      total,
      limit,
      offset,
    })
  } catch (error) {
    console.error("Error en búsqueda de perfiles:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}
