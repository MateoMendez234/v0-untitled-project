import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { connectToDatabase } from "@/lib/mongodb"
import Service from "@/lib/models/service"
import Profile from "@/lib/models/profile"
import Review from "@/lib/models/review"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const serviceId = params.id

    await connectToDatabase()

    const service = await Service.findById(serviceId)

    if (!service) {
      return NextResponse.json({ error: "Servicio no encontrado" }, { status: 404 })
    }

    // Obtener información del freelancer
    const profile = await Profile.findById(service.profileId)

    if (!profile) {
      return NextResponse.json({ error: "Perfil de freelancer no encontrado" }, { status: 404 })
    }

    // Obtener reseñas
    const reviews = await Review.find({ serviceId: service._id, status: "published" })

    // Calcular rating promedio
    const totalReviews = reviews.length
    const rating = totalReviews > 0 ? reviews.reduce((sum, review) => sum + review.rating, 0) / totalReviews : 0

    return NextResponse.json({
      _id: service._id.toString(),
      profileId: service.profileId.toString(),
      title: service.title,
      description: service.description,
      longDescription: service.longDescription,
      price: service.price,
      deliveryTime: service.deliveryTime,
      revisions: service.revisions,
      imageUrl: service.imageUrl,
      featured: service.featured,
      packages: service.packages.map((pkg) => ({
        _id: pkg._id.toString(),
        name: pkg.name,
        price: pkg.price,
        deliveryTime: pkg.deliveryTime,
        revisions: pkg.revisions,
        recommended: pkg.recommended,
        features: pkg.features.map((f) => ({ feature: f.feature })),
      })),
      faqs: service.faqs.map((faq) => ({
        _id: faq._id.toString(),
        question: faq.question,
        answer: faq.answer,
      })),
      freelancer: {
        id: profile._id.toString(),
        username: profile.username,
        name: profile.name,
        title: profile.title,
        avatarUrl: profile.avatarUrl,
        location: profile.location,
        rating,
        totalReviews,
      },
      createdAt: service.createdAt,
      updatedAt: service.updatedAt,
    })
  } catch (error) {
    console.error("Error obteniendo servicio:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)
    const serviceId = params.id

    // Verificar autenticación
    if (!session) {
      return NextResponse.json({ error: "No autorizado" }, { status: 401 })
    }

    await connectToDatabase()

    // Obtener el servicio
    const service = await Service.findById(serviceId)

    if (!service) {
      return NextResponse.json({ error: "Servicio no encontrado" }, { status: 404 })
    }

    // Obtener el perfil del freelancer
    const profile = await Profile.findById(service.profileId)

    if (!profile) {
      return NextResponse.json({ error: "Perfil de freelancer no encontrado" }, { status: 404 })
    }

    // Verificar que el usuario es el dueño del servicio o un administrador
    if (profile.userId.toString() !== session.user.id && !session.user.isAdmin) {
      return NextResponse.json({ error: "No tienes permiso para actualizar este servicio" }, { status: 403 })
    }

    const data = await request.json()

    // Actualizar el servicio
    await Service.findByIdAndUpdate(serviceId, data)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error actualizando servicio:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    const session = await getServerSession(authOptions)
    const serviceId = params.id

    // Verificar autenticación
    if (!session) {
      return NextResponse.json({ error: "No autorizado" }, { status: 401 })
    }

    await connectToDatabase()

    // Obtener el servicio
    const service = await Service.findById(serviceId)

    if (!service) {
      return NextResponse.json({ error: "Servicio no encontrado" }, { status: 404 })
    }

    // Obtener el perfil del freelancer
    const profile = await Profile.findById(service.profileId)

    if (!profile) {
      return NextResponse.json({ error: "Perfil de freelancer no encontrado" }, { status: 404 })
    }

    // Verificar que el usuario es el dueño del servicio o un administrador
    if (profile.userId.toString() !== session.user.id && !session.user.isAdmin) {
      return NextResponse.json({ error: "No tienes permiso para eliminar este servicio" }, { status: 403 })
    }

    // Eliminar el servicio
    await Service.findByIdAndDelete(serviceId)

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error eliminando servicio:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}
