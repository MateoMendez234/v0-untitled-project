import { NextResponse } from "next/server"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"
import { connectToDatabase } from "@/lib/mongodb"
import Service from "@/lib/models/service"
import Profile from "@/lib/models/profile"
import Review from "@/lib/models/review" // Import Review model
import { Types } from "mongoose"

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    // Verificar autenticación
    if (!session) {
      return NextResponse.json({ error: "No autorizado" }, { status: 401 })
    }

    // Verificar que el usuario es freelancer
    if (!session.user.isFreelancer) {
      return NextResponse.json({ error: "Solo los freelancers pueden crear servicios" }, { status: 403 })
    }

    const data = await request.json()

    await connectToDatabase()

    // Obtener el perfil del usuario
    const profile = await Profile.findOne({ userId: new Types.ObjectId(session.user.id) })

    if (!profile) {
      return NextResponse.json({ error: "Perfil no encontrado" }, { status: 404 })
    }

    // Crear el servicio
    const service = new Service({
      profileId: profile._id,
      title: data.title,
      description: data.description,
      longDescription: data.longDescription,
      price: data.price,
      deliveryTime: data.deliveryTime,
      revisions: data.revisions,
      imageUrl: data.imageUrl,
      featured: data.featured || false,
      packages: data.packages || [],
      faqs: data.faqs || [],
    })

    await service.save()

    return NextResponse.json({
      success: true,
      serviceId: service._id.toString(),
    })
  } catch (error) {
    console.error("Error creando servicio:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const featured = searchParams.get("featured") === "true"
    const profileId = searchParams.get("profileId")
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const offset = Number.parseInt(searchParams.get("offset") || "0")

    await connectToDatabase()

    // Construir la consulta
    const query: any = {}

    if (featured) {
      query.featured = true
    }

    if (profileId) {
      query.profileId = new Types.ObjectId(profileId)
    }

    // Ejecutar la consulta
    const services = await Service.find(query).sort({ createdAt: -1 }).skip(offset).limit(limit)

    // Obtener información adicional para cada servicio
    const servicesWithDetails = await Promise.all(
      services.map(async (service) => {
        // Obtener información del freelancer
        const profile = await Profile.findById(service.profileId)

        if (!profile) {
          return null
        }

        // Obtener reseñas
        const reviews = await Review.find({ serviceId: service._id, status: "published" })

        // Calcular rating promedio
        const totalReviews = reviews.length
        const rating = totalReviews > 0 ? reviews.reduce((sum, review) => sum + review.rating, 0) / totalReviews : 0

        return {
          _id: service._id.toString(),
          profileId: service.profileId.toString(),
          title: service.title,
          description: service.description,
          price: service.price,
          deliveryTime: service.deliveryTime,
          revisions: service.revisions,
          imageUrl: service.imageUrl,
          featured: service.featured,
          freelancer: {
            id: profile._id.toString(),
            username: profile.username,
            name: profile.name,
            avatarUrl: profile.avatarUrl,
            rating,
            totalReviews,
          },
          createdAt: service.createdAt,
        }
      }),
    )

    return NextResponse.json({
      services: servicesWithDetails.filter(Boolean),
      total: await Service.countDocuments(query),
    })
  } catch (error) {
    console.error("Error obteniendo servicios:", error)
    return NextResponse.json({ error: "Error interno del servidor" }, { status: 500 })
  }
}
