import { AuthForm } from "@/components/auth/auth-form"
import { Globe } from "lucide-react"
import Link from "next/link"

export default function LoginPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="w-full border-b py-4">
        <div className="container flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 font-bold text-xl text-emerald-600">
            <Globe className="h-6 w-6" />
            <span>Frilanet</span>
          </Link>
        </div>
      </header>

      <main className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <AuthForm />
        </div>
      </main>

      <footer className="w-full py-6 bg-gray-100">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 font-bold text-xl text-emerald-600 mb-4 md:mb-0">
              <Globe className="h-6 w-6" />
              <span>Frilanet</span>
            </div>
            <p className="text-center text-sm text-gray-500">© 2024 Frilanet. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
