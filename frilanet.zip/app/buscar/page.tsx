import { Suspense } from "react"
import { notFound } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Clock, Filter, MapPin, Search, Star } from "lucide-react"
import { searchFreelancersAndServices } from "@/lib/services/search-service"
import { SiteHeader } from "@/components/layout/site-header"
import { SiteFooter } from "@/components/layout/site-footer"

// Componente de carga
function SearchSkeleton() {
  return (
    <div className="space-y-4">
      <div className="h-8 w-64 bg-gray-200 rounded animate-pulse"></div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <div key={i} className="border rounded-lg overflow-hidden">
            <div className="h-40 bg-gray-200 animate-pulse"></div>
            <div className="p-4 space-y-3">
              <div className="h-6 w-3/4 bg-gray-200 rounded animate-pulse"></div>
              <div className="h-4 w-full bg-gray-200 rounded animate-pulse"></div>
              <div className="h-4 w-2/3 bg-gray-200 rounded animate-pulse"></div>
              <div className="flex justify-between">
                <div className="h-5 w-20 bg-gray-200 rounded animate-pulse"></div>
                <div className="h-5 w-16 bg-gray-200 rounded animate-pulse"></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// Componente de resultados de búsqueda
async function SearchResults({
  query,
  category,
  minPrice,
  maxPrice,
  page,
}: {
  query: string
  category?: string
  minPrice?: number
  maxPrice?: number
  page?: number
}) {
  const results = await searchFreelancersAndServices(query, category, minPrice, maxPrice, page || 1)

  if (results.totalFreelancers === 0 && results.totalServices === 0) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-2">No se encontraron resultados</h2>
        <p className="text-gray-600">Intenta con otros términos de búsqueda o filtros</p>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <Tabs defaultValue="services">
        <TabsList>
          <TabsTrigger value="services">Servicios ({results.totalServices})</TabsTrigger>
          <TabsTrigger value="freelancers">Freelancers ({results.totalFreelancers})</TabsTrigger>
        </TabsList>

        {/* Servicios */}
        <TabsContent value="services" className="space-y-6">
          <h2 className="text-xl font-semibold">Servicios encontrados</h2>
          {results.services.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {results.services.map((service) => (
                <Card key={service._id} className={service.featured ? "border-emerald-500" : ""}>
                  <div className="relative h-40 w-full">
                    <Image
                      src={service.imageUrl || "/placeholder.svg?height=200&width=300"}
                      alt={service.title}
                      className="object-cover rounded-t-lg"
                      fill
                    />
                    {service.featured && <Badge className="absolute top-2 right-2 bg-emerald-600">Destacado</Badge>}
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-lg mb-2">{service.title}</h3>
                    <p className="text-gray-600 text-sm mb-4">{service.description}</p>
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Clock className="h-4 w-4" />
                        <span>Entrega en {service.deliveryTime}</span>
                      </div>
                      <div className="font-bold text-lg">€{service.price}</div>
                    </div>
                    <Button className="w-full mt-4 bg-emerald-600 hover:bg-emerald-700">
                      <Link href={`/freelancers/servicios/${service._id}`} className="w-full">
                        Ver detalles
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <p className="text-gray-500">No se encontraron servicios con los criterios especificados.</p>
          )}
        </TabsContent>

        {/* Freelancers */}
        <TabsContent value="freelancers" className="space-y-6">
          <h2 className="text-xl font-semibold">Freelancers encontrados</h2>
          {results.freelancers.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {results.freelancers.map((freelancer) => (
                <Card key={freelancer._id}>
                  <CardContent className="p-6">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="relative w-16 h-16 rounded-full overflow-hidden">
                        <Image
                          src={freelancer.avatarUrl || "/placeholder.svg?height=64&width=64"}
                          alt={freelancer.name || ""}
                          className="object-cover"
                          fill
                        />
                      </div>
                      <div>
                        <h3 className="font-semibold">{freelancer.name}</h3>
                        <p className="text-sm text-gray-600">{freelancer.title}</p>
                        <div className="flex items-center gap-1 mt-1">
                          <div className="flex">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`h-3 w-3 ${star <= 5 ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                              />
                            ))}
                          </div>
                          <span className="text-xs text-gray-600">(0)</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-gray-600 mb-3">
                      <MapPin className="h-4 w-4" />
                      <span>{freelancer.location || "Sin ubicación"}</span>
                    </div>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {freelancer.skills?.slice(0, 3).map((skill, index) => (
                        <Badge key={index} variant="secondary" className="bg-gray-100">
                          {skill}
                        </Badge>
                      ))}
                      {freelancer.skills?.length > 3 && (
                        <Badge variant="secondary" className="bg-gray-100">
                          +{freelancer.skills.length - 3}
                        </Badge>
                      )}
                    </div>
                    <Button className="w-full bg-emerald-600 hover:bg-emerald-700">
                      <Link href={`/freelancers/${freelancer.username}`} className="w-full">
                        Ver perfil
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <p className="text-gray-500">No se encontraron freelancers con los criterios especificados.</p>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}

export default function SearchPage({
  searchParams,
}: {
  searchParams: { q?: string; category?: string; minPrice?: string; maxPrice?: string; page?: string }
}) {
  const { q, category, minPrice, maxPrice, page } = searchParams

  if (!q) {
    notFound()
  }

  return (
    <div className="flex flex-col min-h-screen">
      <SiteHeader />

      <main className="flex-1 container px-4 md:px-6 py-8">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Filtros */}
          <div className="w-full md:w-64 shrink-0">
            <div className="sticky top-24 space-y-6">
              <div>
                <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  <Filter className="h-5 w-5" />
                  Filtros
                </h2>
                <form className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="search">Buscar</Label>
                    <div className="relative">
                      <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                      <Input
                        id="search"
                        type="search"
                        placeholder="Buscar..."
                        defaultValue={q}
                        name="q"
                        className="pl-8"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="category">Categoría</Label>
                    <select
                      id="category"
                      name="category"
                      defaultValue={category}
                      className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
                    >
                      <option value="">Todas las categorías</option>
                      <option value="design">Diseño</option>
                      <option value="development">Desarrollo</option>
                      <option value="marketing">Marketing</option>
                      <option value="writing">Redacción</option>
                      <option value="translation">Traducción</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <Label>Rango de precio</Label>
                    <div className="pt-4">
                      <Slider
                        defaultValue={[
                          minPrice ? Number.parseInt(minPrice) : 0,
                          maxPrice ? Number.parseInt(maxPrice) : 1000,
                        ]}
                        max={1000}
                        step={10}
                        className="mb-6"
                      />
                      <div className="flex items-center justify-between">
                        <Input
                          type="number"
                          placeholder="Min"
                          name="minPrice"
                          defaultValue={minPrice}
                          className="w-20"
                        />
                        <span className="text-gray-500">-</span>
                        <Input
                          type="number"
                          placeholder="Max"
                          name="maxPrice"
                          defaultValue={maxPrice}
                          className="w-20"
                        />
                      </div>
                    </div>
                  </div>

                  <Button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700">
                    Aplicar filtros
                  </Button>
                </form>
              </div>
            </div>
          </div>

          {/* Resultados */}
          <div className="flex-1">
            <h1 className="text-2xl font-bold mb-6">Resultados para "{q}"</h1>
            <Suspense fallback={<SearchSkeleton />}>
              <SearchResults
                query={q}
                category={category}
                minPrice={minPrice ? Number.parseInt(minPrice) : undefined}
                maxPrice={maxPrice ? Number.parseInt(maxPrice) : undefined}
                page={page ? Number.parseInt(page) : 1}
              />
            </Suspense>
          </div>
        </div>
      </main>

      <SiteFooter />
    </div>
  )
}
