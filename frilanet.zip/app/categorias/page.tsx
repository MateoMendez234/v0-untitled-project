import { SiteHeader } from "@/components/layout/site-header"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import Link from "next/link"
import {
  Paintbrush,
  Code,
  FileText,
  Globe,
  MessageSquare,
  Headphones,
  ShieldCheck,
  Wallet,
  Camera,
  Briefcase,
  BookOpen,
  Utensils,
} from "lucide-react"

export default function CategoriasPage() {
  // Datos de ejemplo para mostrar en la página
  const categorias = [
    { id: "design", nombre: "Diseño Gráfico", count: 2345, icon: <Paintbrush className="h-6 w-6" /> },
    { id: "development", nombre: "Desarrollo Web", count: 1987, icon: <Code className="h-6 w-6" /> },
    { id: "writing", nombre: "Redacción", count: 1456, icon: <FileText className="h-6 w-6" /> },
    { id: "marketing", nombre: "Marketing Digital", count: 1234, icon: <Globe className="h-6 w-6" /> },
    { id: "translation", nombre: "Traducción", count: 987, icon: <MessageSquare className="h-6 w-6" /> },
    { id: "audio", nombre: "Audio y Video", count: 876, icon: <Headphones className="h-6 w-6" /> },
    { id: "legal", nombre: "Asesoría Legal", count: 654, icon: <ShieldCheck className="h-6 w-6" /> },
    { id: "finance", nombre: "Finanzas", count: 543, icon: <Wallet className="h-6 w-6" /> },
    { id: "photography", nombre: "Fotografía", count: 432, icon: <Camera className="h-6 w-6" /> },
    { id: "business", nombre: "Consultoría de Negocios", count: 321, icon: <Briefcase className="h-6 w-6" /> },
    { id: "education", nombre: "Educación y Formación", count: 210, icon: <BookOpen className="h-6 w-6" /> },
    { id: "lifestyle", nombre: "Estilo de Vida", count: 198, icon: <Utensils className="h-6 w-6" /> },
  ]

  return (
    <div className="flex flex-col min-h-screen">
      <SiteHeader />

      <main className="flex-1">
        {/* Hero */}
        <section className="bg-emerald-50 py-12">
          <div className="container px-4 md:px-6">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Explora nuestras categorías
              </h1>
              <p className="mt-4 text-gray-600 md:text-xl">
                Encuentra el servicio perfecto para tu proyecto entre miles de profesionales calificados
              </p>
            </div>
          </div>
        </section>

        {/* Lista de categorías */}
        <section className="py-12">
          <div className="container px-4 md:px-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {categorias.map((categoria) => (
                <Link key={categoria.id} href={`/buscar?category=${categoria.id}`} className="block">
                  <Card className="overflow-hidden transition-all hover:shadow-md">
                    <CardContent className="p-6 flex flex-col items-center text-center">
                      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-100 text-emerald-900 mb-4">
                        {categoria.icon}
                      </div>
                      <h3 className="font-medium">{categoria.nombre}</h3>
                      <p className="text-sm text-gray-500">{categoria.count} servicios</p>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-12 bg-emerald-600 text-white">
          <div className="container px-4 md:px-6">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-2xl font-bold tracking-tighter sm:text-3xl">
                ¿Listo para encontrar el servicio perfecto?
              </h2>
              <p className="mt-4 md:text-lg">
                Miles de freelancers especializados están listos para ayudarte con tu proyecto
              </p>
              <div className="mt-8">
                <Button className="bg-white text-emerald-600 hover:bg-gray-100" asChild>
                  <Link href="/explorar">Explorar servicios</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="w-full py-6 bg-gray-100">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 font-bold text-xl text-emerald-600 mb-4 md:mb-0">
              <Link href="/">Frilanet</Link>
            </div>
            <p className="text-center text-sm text-gray-500">© 2024 Frilanet. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
