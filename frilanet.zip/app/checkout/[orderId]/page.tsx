import { redirect } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { StripePaymentFormWrapper } from "@/components/payments/stripe-payment-form"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import { createPaymentIntent } from "@/lib/stripe"
import { Globe, Lock } from "lucide-react"

interface CheckoutPageProps {
  params: {
    orderId: string
  }
}

export default async function CheckoutPage({ params }: CheckoutPageProps) {
  const supabase = createServerSupabaseClient()

  // Verificar si el usuario está autenticado
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login?redirect=/checkout/" + params.orderId)
  }

  // Obtener la orden
  const { data: order } = await supabase
    .from("orders")
    .select(`
      *,
      client: profiles!client_id (name, email),
      freelancer: profiles!freelancer_id (name, username),
      service: services!service_id (title, description, image_url, price),
      package: service_packages (name, price)
    `)
    .eq("id", params.orderId)
    .eq("client_id", user.id)
    .single()

  if (!order) {
    redirect("/dashboard")
  }

  // Si la orden ya está pagada o completada, redirigir a la página de confirmación
  if (order.status === "paid" || order.status === "completed") {
    redirect("/checkout/confirmacion/" + params.orderId)
  }

  // Crear un intent de pago con Stripe
  const paymentIntent = await createPaymentIntent(order.amount, "eur", {
    orderId: order.id,
    serviceId: order.service_id,
    clientId: order.client_id,
  })

  return (
    <div className="flex flex-col min-h-screen">
      <header className="w-full border-b py-4">
        <div className="container flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 font-bold text-xl text-emerald-600">
            <Globe className="h-6 w-6" />
            <span>Frilanet</span>
          </Link>
        </div>
      </header>

      <main className="flex-1 container py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Formulario de pago */}
          <div>
            <h1 className="text-2xl font-bold mb-6">Información de pago</h1>
            <Card>
              <CardContent className="p-6">
                <StripePaymentFormWrapper
                  clientSecret={paymentIntent.client_secret}
                  orderId={order.id}
                  amount={order.amount}
                  onSuccess={() => {
                    // Redirigir a la página de confirmación
                    window.location.href = `/checkout/confirmacion/${order.id}`
                  }}
                />

                <div className="flex items-center gap-2 text-sm text-gray-600 mt-6">
                  <Lock className="h-4 w-4" />
                  <span>Tus datos de pago están seguros y encriptados</span>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Resumen del pedido */}
          <div>
            <h2 className="text-xl font-bold mb-6">Resumen del pedido</h2>
            <Card>
              <CardContent className="p-6 space-y-4">
                {order.service && (
                  <>
                    <div className="flex gap-4">
                      <div className="relative w-20 h-20 rounded-lg overflow-hidden">
                        <Image
                          src={order.service.image_url || "/placeholder.svg?height=80&width=80"}
                          alt={order.service.title}
                          className="object-cover"
                          fill
                        />
                      </div>
                      <div>
                        <h3 className="font-semibold">{order.service.title}</h3>
                        <p className="text-sm text-gray-600">
                          por{" "}
                          <Link
                            href={`/freelancers/${order.freelancer?.username}`}
                            className="text-emerald-600 hover:underline"
                          >
                            {order.freelancer?.name}
                          </Link>
                        </p>
                      </div>
                    </div>

                    <div className="border-t border-b py-4 space-y-2">
                      <div className="flex justify-between">
                        <span>Precio del servicio</span>
                        <span>€{order.service.price.toFixed(2)}</span>
                      </div>

                      {order.package && (
                        <div className="flex justify-between">
                          <span>Paquete: {order.package.name}</span>
                          <span>€{order.package.price.toFixed(2)}</span>
                        </div>
                      )}

                      <div className="flex justify-between">
                        <span>Comisión de servicio</span>
                        <span>€{(order.amount - (order.package?.price || order.service.price)).toFixed(2)}</span>
                      </div>
                    </div>

                    <div className="flex justify-between font-bold">
                      <span>Total</span>
                      <span>€{order.amount.toFixed(2)}</span>
                    </div>

                    <div className="text-sm text-gray-600">
                      <p>
                        Al completar tu compra, aceptas los{" "}
                        <Link href="/terminos" className="text-emerald-600 hover:underline">
                          Términos de Servicio
                        </Link>{" "}
                        y la{" "}
                        <Link href="/privacidad" className="text-emerald-600 hover:underline">
                          Política de Privacidad
                        </Link>
                        .
                      </p>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <footer className="w-full py-6 bg-gray-100">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 font-bold text-xl text-emerald-600 mb-4 md:mb-0">
              <Globe className="h-6 w-6" />
              <span>Frilanet</span>
            </div>
            <p className="text-center text-sm text-gray-500">© 2024 Frilanet. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
