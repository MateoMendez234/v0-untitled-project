import { redirect } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import { Check, Globe } from "lucide-react"

interface ConfirmationPageProps {
  params: {
    orderId: string
  }
}

export default async function ConfirmationPage({ params }: ConfirmationPageProps) {
  const supabase = createServerSupabaseClient()

  // Verificar si el usuario está autenticado
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Obtener la orden
  const { data: order } = await supabase
    .from("orders")
    .select(`
      *,
      client: profiles!client_id (name, email),
      freelancer: profiles!freelancer_id (name, username),
      service: services!service_id (title)
    `)
    .eq("id", params.orderId)
    .eq("client_id", user.id)
    .single()

  if (!order) {
    redirect("/dashboard")
  }

  // Si la orden no está pagada o completada, redirigir al checkout
  if (order.status !== "paid" && order.status !== "completed") {
    redirect("/checkout/" + params.orderId)
  }

  // Crear conversación con el freelancer si no existe
  await supabase.rpc("create_or_get_conversation", {
    user1_id: user.id,
    user2_id: order.freelancer_id,
  })

  return (
    <div className="flex flex-col min-h-screen">
      <header className="w-full border-b py-4">
        <div className="container flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2 font-bold text-xl text-emerald-600">
            <Globe className="h-6 w-6" />
            <span>Frilanet</span>
          </Link>
        </div>
      </header>

      <main className="flex-1 container py-8 flex justify-center items-center">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto bg-emerald-100 p-3 rounded-full w-16 h-16 flex items-center justify-center mb-4">
              <Check className="h-8 w-8 text-emerald-600" />
            </div>
            <CardTitle className="text-2xl">¡Pago completado!</CardTitle>
            <CardDescription>Tu pedido ha sido procesado correctamente</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="border-t border-b py-4">
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Servicio:</span>
                <span className="font-medium">{order.service?.title}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="text-gray-600">Freelancer:</span>
                <span className="font-medium">{order.freelancer?.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Total pagado:</span>
                <span className="font-bold">€{order.amount.toFixed(2)}</span>
              </div>
            </div>
            <p className="text-center text-sm text-gray-600">
              El freelancer ha sido notificado y se pondrá en contacto contigo pronto.
            </p>
          </CardContent>
          <CardFooter className="flex flex-col gap-2">
            <Button className="w-full bg-emerald-600 hover:bg-emerald-700">
              <Link href="/dashboard/pedidos">Ver mis pedidos</Link>
            </Button>
            <Button variant="outline" className="w-full">
              <Link href="/dashboard/mensajes">Ir a mensajes</Link>
            </Button>
          </CardFooter>
        </Card>
      </main>

      <footer className="w-full py-6 bg-gray-100">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 font-bold text-xl text-emerald-600 mb-4 md:mb-0">
              <Globe className="h-6 w-6" />
              <span>Frilanet</span>
            </div>
            <p className="text-center text-sm text-gray-500">© 2024 Frilanet. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
