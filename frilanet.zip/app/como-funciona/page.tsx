import { SiteHeader } from "@/components/layout/site-header"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Search, MessageSquare, Wallet, CheckCircle } from "lucide-react"

export default function ComoFuncionaPage() {
  return (
    <div className="flex flex-col min-h-screen">
      <SiteHeader />

      <main className="flex-1">
        {/* Hero */}
        <section className="bg-emerald-50 py-12">
          <div className="container px-4 md:px-6">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">¿Cómo funciona Frilanet?</h1>
              <p className="mt-4 text-gray-600 md:text-xl">
                Conectamos talento con oportunidades en tres simples pasos
              </p>
            </div>
          </div>
        </section>

        {/* Pasos */}
        <section className="py-12">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 md:grid-cols-3 lg:gap-12">
              <div className="flex flex-col items-center space-y-4 text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100 text-emerald-900">
                  <Search className="h-8 w-8" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-bold">1. Busca</h3>
                  <p className="text-gray-500">
                    Explora miles de servicios en diferentes categorías y encuentra el profesional ideal para tu
                    proyecto.
                  </p>
                </div>
              </div>
              <div className="flex flex-col items-center space-y-4 text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100 text-emerald-900">
                  <MessageSquare className="h-8 w-8" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-bold">2. Contacta</h3>
                  <p className="text-gray-500">
                    Comunícate directamente con el freelancer, define los detalles del proyecto y acuerda los términos.
                  </p>
                </div>
              </div>
              <div className="flex flex-col items-center space-y-4 text-center">
                <div className="flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100 text-emerald-900">
                  <Wallet className="h-8 w-8" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-xl font-bold">3. Paga</h3>
                  <p className="text-gray-500">
                    Realiza pagos seguros a través de nuestra plataforma y recibe tu trabajo con garantía de
                    satisfacción.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Para clientes */}
        <section className="py-12 bg-gray-50">
          <div className="container px-4 md:px-6">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-2xl font-bold mb-6 text-center">Para clientes</h2>
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="flex-shrink-0">
                    <CheckCircle className="h-6 w-6 text-emerald-600" />
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Encuentra el talento perfecto</h3>
                    <p className="text-gray-600">
                      Accede a una amplia red de profesionales independientes con habilidades en más de 100 categorías
                      diferentes.
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex-shrink-0">
                    <CheckCircle className="h-6 w-6 text-emerald-600" />
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Pagos seguros</h3>
                    <p className="text-gray-600">
                      Tu pago se mantiene en depósito hasta que apruebes el trabajo entregado, garantizando tu
                      satisfacción.
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex-shrink-0">
                    <CheckCircle className="h-6 w-6 text-emerald-600" />
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Soporte 24/7</h3>
                    <p className="text-gray-600">
                      Nuestro equipo de atención al cliente está disponible para ayudarte en cualquier momento del
                      proceso.
                    </p>
                  </div>
                </div>
              </div>
              <div className="mt-8 text-center">
                <Button className="bg-emerald-600 hover:bg-emerald-700" asChild>
                  <Link href="/explorar">Buscar servicios</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Para freelancers */}
        <section className="py-12">
          <div className="container px-4 md:px-6">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-2xl font-bold mb-6 text-center">Para freelancers</h2>
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="flex-shrink-0">
                    <CheckCircle className="h-6 w-6 text-emerald-600" />
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Encuentra clientes</h3>
                    <p className="text-gray-600">
                      Accede a una base global de clientes buscando tus habilidades específicas.
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex-shrink-0">
                    <CheckCircle className="h-6 w-6 text-emerald-600" />
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Cobra por tu trabajo</h3>
                    <p className="text-gray-600">
                      Recibe pagos de forma segura y puntual por cada proyecto que completes.
                    </p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex-shrink-0">
                    <CheckCircle className="h-6 w-6 text-emerald-600" />
                  </div>
                  <div>
                    <h3 className="font-medium mb-2">Construye tu reputación</h3>
                    <p className="text-gray-600">
                      Acumula reseñas positivas y construye un portafolio que destaque tus habilidades.
                    </p>
                  </div>
                </div>
              </div>
              <div className="mt-8 text-center">
                <Button className="bg-emerald-600 hover:bg-emerald-700" asChild>
                  <Link href="/auth/register">Regístrate como freelancer</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* FAQ */}
        <section className="py-12 bg-gray-50">
          <div className="container px-4 md:px-6">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-2xl font-bold mb-6 text-center">Preguntas frecuentes</h2>
              <div className="space-y-6">
                <div className="border-b pb-4">
                  <h3 className="font-medium mb-2">¿Cómo me registro en Frilanet?</h3>
                  <p className="text-gray-600">
                    Puedes registrarte haciendo clic en el botón "Registrarse" en la parte superior de la página.
                    Completa el formulario con tus datos y selecciona si quieres registrarte como cliente o como
                    freelancer.
                  </p>
                </div>
                <div className="border-b pb-4">
                  <h3 className="font-medium mb-2">¿Cuánto cuesta usar Frilanet?</h3>
                  <p className="text-gray-600">
                    Registrarse y buscar servicios en Frilanet es completamente gratuito. Solo pagas cuando contratas un
                    servicio, y aplicamos una pequeña comisión sobre el precio del servicio.
                  </p>
                </div>
                <div className="border-b pb-4">
                  <h3 className="font-medium mb-2">¿Cómo funciona el sistema de pagos?</h3>
                  <p className="text-gray-600">
                    Cuando contratas un servicio, el pago se mantiene en depósito hasta que apruebes el trabajo
                    entregado. Esto garantiza que solo pagas por trabajo que cumple con tus expectativas.
                  </p>
                </div>
                <div className="border-b pb-4">
                  <h3 className="font-medium mb-2">¿Qué pasa si no estoy satisfecho con el trabajo?</h3>
                  <p className="text-gray-600">
                    Si no estás satisfecho con el trabajo entregado, puedes solicitar revisiones al freelancer. Si aún
                    así no se resuelve, nuestro equipo de soporte intervendrá para mediar y encontrar una solución
                    justa.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-12 bg-emerald-600 text-white">
          <div className="container px-4 md:px-6">
            <div className="max-w-3xl mx-auto text-center">
              <h2 className="text-2xl font-bold tracking-tighter sm:text-3xl">¿Listo para comenzar?</h2>
              <p className="mt-4 md:text-lg">Únete a miles de usuarios que ya están aprovechando Frilanet</p>
              <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
                <Button className="bg-white text-emerald-600 hover:bg-gray-100" asChild>
                  <Link href="/explorar">Explorar servicios</Link>
                </Button>
                <Button variant="outline" className="text-white border-white hover:bg-emerald-700" asChild>
                  <Link href="/auth/register">Registrarse</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="w-full py-6 bg-gray-100">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 font-bold text-xl text-emerald-600 mb-4 md:mb-0">
              <Link href="/">Frilanet</Link>
            </div>
            <p className="text-center text-sm text-gray-500">© 2024 Frilanet. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
