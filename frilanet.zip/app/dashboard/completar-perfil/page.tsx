import { redirect } from "next/navigation"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default async function CompletarPerfilPage() {
  const supabase = createServerSupabaseClient()

  // Verificar la sesión del usuario
  const { data: sessionData, error: sessionError } = await supabase.auth.getSession()

  if (sessionError || !sessionData.session) {
    redirect("/auth/login")
  }

  return (
    <div className="container py-8 max-w-2xl mx-auto">
      <Card>
        <CardHeader>
          <CardTitle>Completa tu perfil</CardTitle>
          <CardDescription>
            Para continuar usando Frilanet, necesitamos algunos datos adicionales sobre ti.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
            <h3 className="font-medium text-blue-800 mb-2">¿Por qué necesitamos esta información?</h3>
            <p className="text-blue-700 text-sm">
              Completar tu perfil nos ayuda a personalizar tu experiencia y conectarte con los servicios o clientes
              adecuados. También aumenta la confianza en la plataforma.
            </p>
          </div>

          <div className="space-y-4">
            <h3 className="font-medium">Necesitamos que completes:</h3>
            <ul className="space-y-2">
              <li className="flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-blue-600"></div>
                <span>Información personal básica</span>
              </li>
              <li className="flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-blue-600"></div>
                <span>Foto de perfil</span>
              </li>
              <li className="flex items-center gap-2">
                <div className="h-2 w-2 rounded-full bg-blue-600"></div>
                <span>Habilidades y experiencia</span>
              </li>
              {/* Más elementos según sea necesario */}
            </ul>
          </div>

          <Button className="w-full bg-blue-600 hover:bg-blue-700" asChild>
            <Link href="/freelancers/editar-perfil">Completar mi perfil ahora</Link>
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
