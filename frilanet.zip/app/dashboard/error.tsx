"use client"

import { useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertCircle, Home, RefreshCw } from "lucide-react"
import Link from "next/link"

export default function DashboardError({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    // Registrar el error en un servicio de análisis de errores
    console.error("Error en el dashboard:", error)
  }, [error])

  return (
    <div className="container py-8 max-w-md mx-auto">
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2 text-red-600 mb-2">
            <AlertCircle className="h-5 w-5" />
            <span className="text-sm font-medium">Error en el dashboard</span>
          </div>
          <CardTitle>Ha ocurrido un problema</CardTitle>
          <CardDescription>
            No hemos podido cargar tu dashboard. Esto puede deberse a un problema temporal o a un error en la conexión.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="bg-red-50 p-4 rounded-lg border border-red-100 text-sm text-red-800">
            <p className="font-medium mb-1">Detalles del error:</p>
            <p className="font-mono text-xs">{error.message || "Error desconocido"}</p>
          </div>
        </CardContent>
        <CardFooter className="flex gap-2 justify-between">
          <Button variant="outline" asChild>
            <Link href="/">
              <Home className="mr-2 h-4 w-4" />
              Ir al inicio
            </Link>
          </Button>
          <Button onClick={reset} className="bg-blue-600 hover:bg-blue-700">
            <RefreshCw className="mr-2 h-4 w-4" />
            Intentar de nuevo
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
