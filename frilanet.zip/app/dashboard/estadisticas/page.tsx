import { redirect } from "next/navigation"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import { getFreelancerAnalytics } from "@/lib/analytics"
import { DollarSign, FileText } from "lucide-react"

export default async function StatsPage() {
  const supabase = createServerSupabaseClient()
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) {
    redirect("/auth/login")
  }
  
  // Verificar si el usuario es freelancer
  const { data: profile } = await supabase
    .from("profiles")
    .select("is_freelancer")
    .eq("id", user.id)
    .single()
  
  if (!profile || !profile.is_freelancer) {
    redirect("/dashboard")
  }
  
  // Obtener estadísticas
  const stats = await getFreelancerAnalytics(user.id)

  return (
    <div className="container py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-2xl font-bold">Estadísticas</h1>
          <p className="text-gray-600">Analiza el rendimiento de tus servicios</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" asChild>
            <Link href="/dashboard/servicios">
              <FileText className="mr-2 h-4 w-4" />
              Mis servicios
            </Link>
          </Button>
        </div>
      </div>

      {/* Tarjetas de resumen */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6 flex items-center gap-4">
            <div className="bg-emerald-100 p-3 rounded-full">
              <DollarSign className="h-6 w-6 text-emerald-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Ingresos totales</p>
              <h3 className="text-2xl font-bold">&#x20AC;{stats.totalRevenue.toFixed(2)}</h3>
            </div>\
