import type { ReactNode } from "react"
import Link from "next/link"
import { redirect } from "next/navigation"
import { SiteHeader } from "@/components/layout/site-header"
import { MobileDashboardNav } from "@/components/mobile/mobile-dashboard-nav"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import { BarChart, FileText, Home, MessageSquare, Package, Settings, User } from "lucide-react"

interface DashboardLayoutProps {
  children: ReactNode
}

export default async function DashboardLayout({ children }: DashboardLayoutProps) {
  const supabase = createServerSupabaseClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login?redirect=/dashboard")
  }

  // Obtener perfil del usuario
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (!profile) {
    redirect("/dashboard/completar-perfil")
  }

  // Obtener mensajes no leídos
  const { data: unreadMessages } = await supabase.rpc("get_unread_messages_count", {
    user_id: user.id,
  })

  const unreadCount = unreadMessages || 0

  return (
    <div className="flex flex-col min-h-screen">
      <SiteHeader />

      <div className="flex-1 flex">
        {/* Sidebar para desktop */}
        <div className="hidden md:flex w-64 flex-col border-r bg-gray-50">
          <div className="p-6">
            <h2 className="text-lg font-semibold">Dashboard</h2>
            <p className="text-sm text-gray-600">Gestiona tu cuenta</p>
          </div>

          <nav className="flex-1 px-4 space-y-1">
            <Link
              href="/dashboard"
              className="flex items-center gap-3 px-3 py-2 text-sm rounded-md hover:bg-gray-100 transition-colors"
            >
              <Home className="h-4 w-4" />
              Dashboard
            </Link>

            <Link
              href="/dashboard/mensajes"
              className="flex items-center gap-3 px-3 py-2 text-sm rounded-md hover:bg-gray-100 transition-colors"
            >
              <MessageSquare className="h-4 w-4" />
              Mensajes
              {unreadCount > 0 && (
                <span className="ml-auto bg-emerald-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </Link>

            <Link
              href="/dashboard/pedidos"
              className="flex items-center gap-3 px-3 py-2 text-sm rounded-md hover:bg-gray-100 transition-colors"
            >
              <Package className="h-4 w-4" />
              Pedidos
            </Link>

            {profile.is_freelancer && (
              <>
                <Link
                  href="/dashboard/servicios"
                  className="flex items-center gap-3 px-3 py-2 text-sm rounded-md hover:bg-gray-100 transition-colors"
                >
                  <FileText className="h-4 w-4" />
                  Mis servicios
                </Link>

                <Link
                  href="/dashboard/estadisticas"
                  className="flex items-center gap-3 px-3 py-2 text-sm rounded-md hover:bg-gray-100 transition-colors"
                >
                  <BarChart className="h-4 w-4" />
                  Estadísticas
                </Link>
              </>
            )}

            <div className="pt-4 mt-4 border-t">
              <Link
                href="/dashboard/perfil"
                className="flex items-center gap-3 px-3 py-2 text-sm rounded-md hover:bg-gray-100 transition-colors"
              >
                <User className="h-4 w-4" />
                Mi perfil
              </Link>

              <Link
                href="/dashboard/ajustes"
                className="flex items-center gap-3 px-3 py-2 text-sm rounded-md hover:bg-gray-100 transition-colors"
              >
                <Settings className="h-4 w-4" />
                Ajustes
              </Link>
            </div>
          </nav>
        </div>

        {/* Contenido principal */}
        <div className="flex-1">
          <div className="md:hidden flex items-center justify-between p-4 border-b">
            <h1 className="text-lg font-semibold">Dashboard</h1>
            <MobileDashboardNav />
          </div>

          <main>{children}</main>
        </div>
      </div>
    </div>
  )
}
