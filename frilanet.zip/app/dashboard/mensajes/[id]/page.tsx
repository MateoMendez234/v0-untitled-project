import { notFound } from "next/navigation"
import { Card } from "@/components/ui/card"
import { ConversationHeader } from "@/components/messages/conversation-header"
import { ConversationMessages } from "@/components/messages/conversation-messages"
import { MessageInput } from "@/components/messages/message-input"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import { getMessages } from "@/lib/messages"
import { getServiceById } from "@/lib/services"

interface ConversationPageProps {
  params: {
    id: string
  }
}

export default async function ConversationPage({ params }: ConversationPageProps) {
  const supabase = createServerSupabaseClient()

  // Obtener el usuario actual
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return notFound()
  }

  // Obtener la conversación
  const { data: conversation, error: convError } = await supabase
    .from("conversations")
    .select(`
      id,
      subject,
      service_id,
      client_id,
      freelancer_id,
      client:profiles!conversations_client_id_fkey(id, name, username, avatar_url),
      freelancer:profiles!conversations_freelancer_id_fkey(id, name, username, avatar_url)
    `)
    .eq("id", params.id)
    .single()

  if (convError || !conversation) {
    console.error("Error fetching conversation:", convError)
    return notFound()
  }

  // Verificar que el usuario es participante
  if (conversation.client_id !== user.id && conversation.freelancer_id !== user.id) {
    return notFound()
  }

  // Determinar el otro participante
  const isClient = conversation.client_id === user.id
  const participant = isClient ? conversation.freelancer : conversation.client

  // Obtener mensajes
  const messages = await getMessages(params.id)

  // Obtener servicio si existe
  let service = null
  if (conversation.service_id) {
    service = await getServiceById(conversation.service_id)
  }

  return (
    <div className="container py-8">
      <Card className="flex flex-col h-[calc(100vh-200px)]">
        <ConversationHeader
          participant={participant}
          subject={conversation.subject}
          service={
            service
              ? {
                  id: service.id,
                  title: service.title,
                }
              : null
          }
        />
        <ConversationMessages conversationId={params.id} messages={messages} currentUserId={user.id} />
        <MessageInput conversationId={params.id} senderId={user.id} />
      </Card>
    </div>
  )
}
