import { redirect } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { getConversations } from "@/lib/messages"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import { formatDistanceToNow } from "date-fns"
import { es } from "date-fns/locale"

export default async function MessagesPage() {
  const supabase = createServerSupabaseClient()
  const { data: session } = await supabase.auth.getSession()

  if (!session?.session?.user) {
    redirect("/auth/login")
  }

  const userId = session.session.user.id
  const conversations = await getConversations(userId)

  return (
    <div className="container py-8">
      <h1 className="text-2xl font-bold mb-6">Mis Mensajes</h1>

      {conversations.length > 0 ? (
        <div className="space-y-4">
          {conversations.map((conversation) => {
            const isParticipant1 = conversation.participant1_id === userId
            const otherParticipantName = isParticipant1
              ? conversation.participant2_name
              : conversation.participant1_name
            const otherParticipantAvatar = isParticipant1
              ? conversation.participant2_avatar
              : conversation.participant1_avatar

            return (
              <Link key={conversation.id} href={`/dashboard/mensajes/${conversation.id}`}>
                <Card className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4 flex items-center gap-4">
                    <div className="relative w-12 h-12 rounded-full overflow-hidden">
                      <Image
                        src={otherParticipantAvatar || "/placeholder.svg?height=48&width=48"}
                        alt={otherParticipantName || "Usuario"}
                        className="object-cover"
                        fill
                      />
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-center">
                        <h3 className="font-medium">{otherParticipantName || "Usuario"}</h3>
                        <span className="text-xs text-gray-500">
                          {conversation.last_message_time
                            ? formatDistanceToNow(new Date(conversation.last_message_time), {
                                addSuffix: true,
                                locale: es,
                              })
                            : ""}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 truncate">
                        {conversation.last_message || "Iniciar conversación"}
                      </p>
                      {conversation.unread_count > 0 && (
                        <span className="inline-flex items-center justify-center w-5 h-5 text-xs font-medium text-white bg-emerald-600 rounded-full">
                          {conversation.unread_count}
                        </span>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </Link>
            )
          })}
        </div>
      ) : (
        <div className="text-center py-12">
          <h2 className="text-xl font-semibold mb-2">No tienes mensajes</h2>
          <p className="text-gray-600 mb-6">Comienza a contactar freelancers o clientes para iniciar conversaciones</p>
          <Button className="bg-emerald-600 hover:bg-emerald-700">
            <Link href="/buscar">Explorar servicios</Link>
          </Button>
        </div>
      )}
    </div>
  )
}
