import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import { getServicesByProfileId } from "@/lib/services"
import { getOrdersByClient } from "@/lib/payments"
import { Calendar, Clock, DollarSign, FileText, MessageSquare, Settings, Star } from "lucide-react"
import { redirect } from "next/navigation"

export default async function DashboardPage() {
  const supabase = createServerSupabaseClient()

  // Verificar la sesión del usuario
  const { data: sessionData, error: sessionError } = await supabase.auth.getSession()

  if (sessionError || !sessionData.session) {
    // Redirección directa sin try/catch
    redirect("/auth/login")
  }

  const userId = sessionData.session.user.id

  // Obtener perfil del usuario
  const { data: profileData, error: profileError } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", userId)
    .single()

  if (profileError || !profileData) {
    // Redirección directa sin try/catch
    redirect("/dashboard/completar-perfil")
  }

  // Obtener servicios si es freelancer
  let services = []
  let orders = []
  const stats = {
    totalEarnings: 0,
    completedOrders: 0,
    activeOrders: 0,
    averageRating: 0,
  }

  try {
    if (profileData.is_freelancer) {
      services = await getServicesByProfileId(userId)

      // Obtener órdenes de los servicios
      const serviceIds = services.map((service) => service.id)
      if (serviceIds.length > 0) {
        const { data: ordersData } = await supabase
          .from("orders")
          .select("*")
          .in("service_id", serviceIds)
          .order("created_at", { ascending: false })

        orders = ordersData || []

        // Calcular estadísticas
        stats.totalEarnings = orders.reduce((sum, order) => sum + (order.status === "completed" ? order.amount : 0), 0)
        stats.completedOrders = orders.filter((order) => order.status === "completed").length
        stats.activeOrders = orders.filter((order) => order.status === "paid").length
      }

      // Obtener valoraciones
      const { data: reviewsData } = await supabase.from("reviews").select("rating").in("service_id", serviceIds)

      if (reviewsData && reviewsData.length > 0) {
        stats.averageRating = reviewsData.reduce((sum, review) => sum + review.rating, 0) / reviewsData.length
      }
    } else {
      // Si es cliente, obtener sus órdenes
      orders = await getOrdersByClient(userId)
    }
  } catch (error) {
    console.error("Error al obtener datos de servicios u órdenes:", error)
    // No redirigimos en caso de error en datos secundarios
  }

  // Obtener mensajes no leídos
  let unreadCount = 0
  try {
    const { data: unreadMessages, error: messagesError } = await supabase.rpc("get_unread_messages_count", {
      user_id: userId,
    })

    if (!messagesError) {
      unreadCount = unreadMessages || 0
    }
  } catch (error) {
    console.error("Error al obtener mensajes no leídos:", error)
    // No redirigimos en caso de error en datos secundarios
  }

  return (
    <div className="container py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-gray-600">Bienvenido de nuevo, {profileData.name}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" asChild>
            <Link href="/dashboard/mensajes">
              <MessageSquare className="mr-2 h-4 w-4" />
              Mensajes
              {unreadCount > 0 && (
                <span className="ml-2 bg-blue-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/dashboard/ajustes">
              <Settings className="mr-2 h-4 w-4" />
              Ajustes
            </Link>
          </Button>
        </div>
      </div>

      {/* Estadísticas para freelancers */}
      {profileData.is_freelancer && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6 flex items-center gap-4">
              <div className="bg-blue-100 p-3 rounded-full">
                <DollarSign className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Ganancias totales</p>
                <h3 className="text-2xl font-bold">€{stats.totalEarnings.toFixed(2)}</h3>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 flex items-center gap-4">
              <div className="bg-blue-100 p-3 rounded-full">
                <FileText className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Pedidos completados</p>
                <h3 className="text-2xl font-bold">{stats.completedOrders}</h3>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 flex items-center gap-4">
              <div className="bg-blue-100 p-3 rounded-full">
                <Clock className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Pedidos activos</p>
                <h3 className="text-2xl font-bold">{stats.activeOrders}</h3>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 flex items-center gap-4">
              <div className="bg-blue-100 p-3 rounded-full">
                <Star className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-sm text-gray-500">Valoración media</p>
                <h3 className="text-2xl font-bold">
                  {stats.averageRating > 0 ? stats.averageRating.toFixed(1) : "N/A"}
                </h3>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Sección principal */}
        <div className="lg:col-span-2 space-y-8">
          {/* Servicios para freelancers */}
          {profileData.is_freelancer && (
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Mis servicios</CardTitle>
                  <CardDescription>Gestiona los servicios que ofreces</CardDescription>
                </div>
                <Button className="bg-blue-600 hover:bg-blue-700" asChild>
                  <Link href="/dashboard/servicios/nuevo">Crear servicio</Link>
                </Button>
              </CardHeader>
              <CardContent>
                {services.length > 0 ? (
                  <div className="space-y-4">
                    {services.slice(0, 3).map((service) => (
                      <div key={service.id} className="flex gap-4 border-b pb-4">
                        <div className="relative w-16 h-16 rounded-lg overflow-hidden">
                          <Image
                            src={service.image_url || "/placeholder.svg?height=64&width=64"}
                            alt={service.title}
                            className="object-cover"
                            fill
                          />
                        </div>
                        <div className="flex-1">
                          <div className="flex justify-between">
                            <h3 className="font-medium">{service.title}</h3>
                            <span className="font-bold">€{service.price}</span>
                          </div>
                          <p className="text-sm text-gray-600 line-clamp-1">{service.description}</p>
                          <div className="flex gap-2 mt-2">
                            <Button variant="outline" size="sm" asChild>
                              <Link href={`/dashboard/servicios/${service.id}`}>Editar</Link>
                            </Button>
                            <Button variant="outline" size="sm" asChild>
                              <Link href={`/freelancers/servicios/${service.id}`}>Ver</Link>
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                    {services.length > 3 && (
                      <div className="text-center">
                        <Button variant="link" asChild>
                          <Link href="/dashboard/servicios">Ver todos los servicios</Link>
                        </Button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-500 mb-4">Aún no has creado ningún servicio</p>
                    <Button className="bg-blue-600 hover:bg-blue-700" asChild>
                      <Link href="/dashboard/servicios/nuevo">Crear mi primer servicio</Link>
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Pedidos recientes */}
          <Card>
            <CardHeader>
              <CardTitle>Pedidos recientes</CardTitle>
              <CardDescription>
                {profileData.is_freelancer ? "Pedidos recibidos para tus servicios" : "Tus compras recientes"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {orders.length > 0 ? (
                <div className="space-y-4">
                  {orders.slice(0, 5).map((order) => (
                    <div key={order.id} className="flex justify-between items-center border-b pb-4">
                      <div>
                        <p className="font-medium">Pedido #{order.id.substring(0, 8)}</p>
                        <p className="text-sm text-gray-600">{new Date(order.created_at).toLocaleDateString()}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold">€{order.amount.toFixed(2)}</p>
                        <span
                          className={`text-xs px-2 py-1 rounded-full ${
                            order.status === "completed"
                              ? "bg-green-100 text-green-800"
                              : order.status === "paid"
                                ? "bg-blue-100 text-blue-800"
                                : order.status === "pending"
                                  ? "bg-yellow-100 text-yellow-800"
                                  : "bg-red-100 text-red-800"
                          }`}
                        >
                          {order.status === "completed"
                            ? "Completado"
                            : order.status === "paid"
                              ? "En progreso"
                              : order.status === "pending"
                                ? "Pendiente"
                                : "Cancelado"}
                        </span>
                      </div>
                    </div>
                  ))}
                  <div className="text-center">
                    <Button variant="link" asChild>
                      <Link href="/dashboard/pedidos">Ver todos los pedidos</Link>
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500 mb-4">
                    {profileData.is_freelancer
                      ? "Aún no has recibido ningún pedido"
                      : "Aún no has realizado ninguna compra"}
                  </p>
                  {!profileData.is_freelancer && (
                    <Button className="bg-blue-600 hover:bg-blue-700" asChild>
                      <Link href="/buscar">Explorar servicios</Link>
                    </Button>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-8">
          {/* Perfil */}
          <Card>
            <CardHeader>
              <CardTitle>Mi perfil</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col items-center">
                <div className="relative w-24 h-24 rounded-full overflow-hidden mb-4">
                  <Image
                    src={profileData.avatar_url || "/placeholder.svg?height=96&width=96"}
                    alt={profileData.name || ""}
                    className="object-cover"
                    fill
                  />
                </div>
                <h3 className="font-bold text-lg">{profileData.name}</h3>
                <p className="text-gray-600">{profileData.title || "Sin título"}</p>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Perfil completado</span>
                  <span>{profileData.completion_rate || 0}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full"
                    style={{ width: `${profileData.completion_rate || 0}%` }}
                  ></div>
                </div>
              </div>

              <Button className="w-full" variant="outline" asChild>
                <Link href="/freelancers/editar-perfil">Editar perfil</Link>
              </Button>

              {profileData.is_freelancer && profileData.username && (
                <Button className="w-full" variant="outline" asChild>
                  <Link href={`/freelancers/${profileData.username}`}>Ver perfil público</Link>
                </Button>
              )}
            </CardContent>
          </Card>

          {/* Calendario / Próximos eventos */}
          <Card>
            <CardHeader>
              <CardTitle>Próximos eventos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
                  <Calendar className="h-10 w-10 text-blue-600" />
                  <div>
                    <p className="font-medium">Sin eventos próximos</p>
                    <p className="text-sm text-gray-600">Tu calendario está vacío</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
