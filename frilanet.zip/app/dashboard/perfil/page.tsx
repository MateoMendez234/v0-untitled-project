"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { SiteHeader } from "@/components/layout/site-header"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Camera, Check, Loader2, Plus, Save, X } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import type { ProfileWithDetails } from "@/lib/profiles"

export default function EditProfile() {
  const router = useRouter()
  const [profile, setProfile] = useState<Partial<ProfileWithDetails>>({})
  const [newSkill, setNewSkill] = useState("")
  const [newLanguage, setNewLanguage] = useState("")
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [userId, setUserId] = useState<string | null>(null)

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const supabase = createClientSupabaseClient()

        // Obtener usuario actual
        const {
          data: { user },
        } = await supabase.auth.getUser()

        if (!user) {
          router.push("/auth")
          return
        }

        setUserId(user.id)

        // Obtener perfil
        const { data: profileData, error: profileError } = await supabase
          .from("profiles")
          .select("*")
          .eq("id", user.id)
          .single()

        if (profileError) throw profileError

        // Obtener habilidades
        const { data: skills, error: skillsError } = await supabase
          .from("skills")
          .select("skill")
          .eq("profile_id", user.id)

        if (skillsError) throw skillsError

        // Obtener idiomas
        const { data: languages, error: languagesError } = await supabase
          .from("languages")
          .select("language")
          .eq("profile_id", user.id)

        if (languagesError) throw languagesError

        setProfile({
          ...profileData,
          skills: skills.map((s) => s.skill),
          languages: languages.map((l) => l.language),
        })
      } catch (err) {
        console.error("Error al cargar perfil:", err)
        setError("Error al cargar el perfil. Intenta recargar la página.")
      } finally {
        setLoading(false)
      }
    }

    fetchProfile()
  }, [router])

  // Función para manejar cambios en los campos de texto
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setProfile((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  // Función para añadir una nueva habilidad
  const addSkill = () => {
    if (newSkill && !profile.skills?.includes(newSkill)) {
      setProfile((prev) => ({
        ...prev,
        skills: [...(prev.skills || []), newSkill],
      }))
      setNewSkill("")
    }
  }

  // Función para eliminar una habilidad
  const removeSkill = (skill: string) => {
    setProfile((prev) => ({
      ...prev,
      skills: prev.skills?.filter((s) => s !== skill),
    }))
  }

  // Función para añadir un nuevo idioma
  const addLanguage = () => {
    if (newLanguage && !profile.languages?.includes(newLanguage)) {
      setProfile((prev) => ({
        ...prev,
        languages: [...(prev.languages || []), newLanguage],
      }))
      setNewLanguage("")
    }
  }

  // Función para eliminar un idioma
  const removeLanguage = (language: string) => {
    setProfile((prev) => ({
      ...prev,
      languages: prev.languages?.filter((l) => l !== language),
    }))
  }

  // Función para guardar los cambios
  const saveChanges = async () => {
    if (!userId) return

    setSaving(true)
    setError(null)

    try {
      const supabase = createClientSupabaseClient()

      // Datos a actualizar en el perfil
      const profileData = {
        username: profile.username,
        name: profile.name,
        title: profile.title,
        location: profile.location,
        about: profile.about,
        website: profile.website,
        email: profile.email,
        phone: profile.phone,
        is_freelancer: true,
      }

      // Actualizar perfil
      const { error: profileError } = await supabase.from("profiles").update(profileData).eq("id", userId)

      if (profileError) throw profileError

      // Actualizar habilidades
      // Primero eliminar todas las habilidades existentes
      await supabase.from("skills").delete().eq("profile_id", userId)

      // Luego insertar las nuevas habilidades
      if (profile.skills && profile.skills.length > 0) {
        const skillsToInsert = profile.skills.map((skill) => ({
          profile_id: userId,
          skill,
        }))

        const { error: skillsError } = await supabase.from("skills").insert(skillsToInsert)

        if (skillsError) throw skillsError
      }

      // Actualizar idiomas
      // Primero eliminar todos los idiomas existentes
      await supabase.from("languages").delete().eq("profile_id", userId)

      // Luego insertar los nuevos idiomas
      if (profile.languages && profile.languages.length > 0) {
        const languagesToInsert = profile.languages.map((language) => ({
          profile_id: userId,
          language,
        }))

        const { error: languagesError } = await supabase.from("languages").insert(languagesToInsert)

        if (languagesError) throw languagesError
      }

      setSaved(true)
      setTimeout(() => setSaved(false), 3000)
    } catch (err) {
      console.error("Error al guardar cambios:", err)
      setError(err instanceof Error ? err.message : "Error al guardar los cambios")
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="flex flex-col min-h-screen">
        <SiteHeader />
        <div className="flex-1 flex items-center justify-center">
          <div className="flex flex-col items-center gap-2">
            <Loader2 className="h-8 w-8 animate-spin text-emerald-600" />
            <p>Cargando perfil...</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col min-h-screen">
      <SiteHeader />

      <main className="flex-1 container px-4 md:px-6 py-8">
        <div className="flex items-center gap-2 mb-6">
          <Link href="/dashboard" className="text-gray-500 hover:text-emerald-600">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <h1 className="text-2xl font-bold">Editar Perfil</h1>
        </div>

        {error && (
          <Alert className="mb-6 bg-red-50 text-red-800 border-red-200">
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {saved && (
          <Alert className="mb-6 bg-emerald-50 text-emerald-800 border-emerald-200">
            <Check className="h-4 w-4" />
            <AlertDescription>Los cambios han sido guardados correctamente.</AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="personal" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="personal">Información Personal</TabsTrigger>
            <TabsTrigger value="skills">Habilidades e Idiomas</TabsTrigger>
            <TabsTrigger value="account">Cuenta</TabsTrigger>
          </TabsList>

          {/* Información Personal */}
          <TabsContent value="personal" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Imágenes de perfil</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label>Imagen de portada</Label>
                  <div className="relative w-full h-48 overflow-hidden rounded-lg border">
                    <Image
                      src={profile.cover_image_url || "/placeholder.svg?height=400&width=800"}
                      alt="Portada"
                      className="object-cover"
                      fill
                    />
                    <div className="absolute inset-0 flex items-center justify-center bg-black/30 opacity-0 hover:opacity-100 transition-opacity">
                      <Button variant="secondary" size="sm" className="gap-2">
                        <Camera className="h-4 w-4" />
                        Cambiar imagen
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Foto de perfil</Label>
                  <div className="flex items-center gap-4">
                    <div className="relative w-24 h-24 rounded-full overflow-hidden border">
                      <Image
                        src={profile.avatar_url || "/placeholder.svg?height=150&width=150"}
                        alt="Avatar"
                        className="object-cover"
                        fill
                      />
                      <div className="absolute inset-0 flex items-center justify-center bg-black/30 opacity-0 hover:opacity-100 transition-opacity rounded-full">
                        <Button variant="secondary" size="sm" className="w-8 h-8 p-0 rounded-full">
                          <Camera className="h-4 w-4" />
                          <span className="sr-only">Cambiar foto</span>
                        </Button>
                      </div>
                    </div>
                    <div className="text-sm text-gray-500">
                      <p>Recomendado: JPG, PNG. Máximo 1MB</p>
                      <p>Tamaño mínimo: 400x400 píxeles</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Información básica</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nombre completo</Label>
                    <Input
                      id="name"
                      name="name"
                      value={profile.name || ""}
                      onChange={handleChange}
                      placeholder="Tu nombre completo"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="title">Título profesional</Label>
                    <Input
                      id="title"
                      name="title"
                      value={profile.title || ""}
                      onChange={handleChange}
                      placeholder="Ej: Diseñador Gráfico & Ilustrador"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="location">Ubicación</Label>
                    <Input
                      id="location"
                      name="location"
                      value={profile.location || ""}
                      onChange={handleChange}
                      placeholder="Ej: Madrid, España"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="website">Sitio web</Label>
                    <Input
                      id="website"
                      name="website"
                      value={profile.website || ""}
                      onChange={handleChange}
                      placeholder="Ej: www.tusitio.com"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="about">Acerca de mí</Label>
                  <Textarea
                    id="about"
                    name="about"
                    value={profile.about || ""}
                    onChange={handleChange}
                    placeholder="Describe tu experiencia, especialidades y enfoque profesional"
                    rows={6}
                  />
                  <p className="text-sm text-gray-500">
                    Una buena descripción ayuda a los clientes a conocerte mejor y aumenta tus posibilidades de ser
                    contratado.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Habilidades e Idiomas */}
          <TabsContent value="skills" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Habilidades e idiomas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <Label>Habilidades</Label>
                  <div className="flex flex-wrap gap-2 mb-2">
                    {profile.skills?.map((skill, index) => (
                      <Badge key={index} variant="secondary" className="pl-2 pr-1 py-1 flex items-center gap-1">
                        {skill}
                        <button onClick={() => removeSkill(skill)} className="ml-1 rounded-full hover:bg-gray-200 p-1">
                          <X className="h-3 w-3" />
                          <span className="sr-only">Eliminar {skill}</span>
                        </button>
                      </Badge>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Input
                      value={newSkill}
                      onChange={(e) => setNewSkill(e.target.value)}
                      placeholder="Añadir nueva habilidad"
                      onKeyDown={(e) => e.key === "Enter" && addSkill()}
                    />
                    <Button type="button" onClick={addSkill} variant="outline" className="shrink-0">
                      <Plus className="h-4 w-4 mr-2" />
                      Añadir
                    </Button>
                  </div>
                </div>

                <div className="space-y-4">
                  <Label>Idiomas</Label>
                  <div className="flex flex-wrap gap-2 mb-2">
                    {profile.languages?.map((language, index) => (
                      <Badge key={index} variant="secondary" className="pl-2 pr-1 py-1 flex items-center gap-1">
                        {language}
                        <button
                          onClick={() => removeLanguage(language)}
                          className="ml-1 rounded-full hover:bg-gray-200 p-1"
                        >
                          <X className="h-3 w-3" />
                          <span className="sr-only">Eliminar {language}</span>
                        </button>
                      </Badge>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Input
                      value={newLanguage}
                      onChange={(e) => setNewLanguage(e.target.value)}
                      placeholder="Añadir nuevo idioma"
                      onKeyDown={(e) => e.key === "Enter" && addLanguage()}
                    />
                    <Button type="button" onClick={addLanguage} variant="outline" className="shrink-0">
                      <Plus className="h-4 w-4 mr-2" />
                      Añadir
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Cuenta */}
          <TabsContent value="account" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Información de contacto</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Correo electrónico</Label>
                    <Input
                      id="email"
                      name="email"
                      value={profile.email || ""}
                      onChange={handleChange}
                      placeholder="tu@email.com"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Teléfono</Label>
                    <Input
                      id="phone"
                      name="phone"
                      value={profile.phone || ""}
                      onChange={handleChange}
                      placeholder="+34 612 345 678"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Configuración de cuenta</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="username">Nombre de usuario</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      id="username"
                      name="username"
                      value={profile.username || ""}
                      onChange={handleChange}
                      placeholder="tunombredeusuario"
                    />
                    <Button variant="outline" className="shrink-0">
                      Verificar
                    </Button>
                  </div>
                  <p className="text-sm text-gray-500">Tu URL será: frilanet.com/freelancers/{profile.username}</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end gap-4 mt-8">
          <Button variant="outline">Cancelar</Button>
          <Button onClick={saveChanges} className="bg-emerald-600 hover:bg-emerald-700" disabled={saving}>
            {saving ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Guardando...
              </>
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" />
                Guardar cambios
              </>
            )}
          </Button>
        </div>
      </main>

      <footer className="w-full py-6 bg-gray-100">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 font-bold text-xl text-emerald-600 mb-4 md:mb-0">
              <Link href="/">Frilanet</Link>
            </div>
            <p className="text-center text-sm text-gray-500">© 2024 Frilanet. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
