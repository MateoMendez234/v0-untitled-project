"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useAuth } from "@/components/auth/auth-provider"

export default function AuthDebugPage() {
  const router = useRouter()
  const { user, profile, loading, signOut } = useAuth()
  const [sessionInfo, setSessionInfo] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(false)

  // Función para verificar la sesión desde el servidor
  const checkServerSession = async () => {
    setIsLoading(true)
    try {
      const response = await fetch("/api/auth/session")
      const data = await response.json()
      setSessionInfo(data)
    } catch (error) {
      console.error("Error al verificar la sesión:", error)
      setSessionInfo({ error: "Error al obtener datos de sesión" })
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    checkServerSession()
  }, [])

  return (
    <div className="container py-8 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Diagnóstico de Autenticación</h1>

      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Estado de Autenticación (Cliente)</CardTitle>
            <CardDescription>Información del contexto de autenticación en el cliente</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <p>Cargando información de usuario...</p>
            ) : (
              <div className="space-y-2">
                <p>
                  <strong>Autenticado:</strong> {user ? "Sí" : "No"}
                </p>
                {user && (
                  <>
                    <p>
                      <strong>ID de Usuario:</strong> {user.id}
                    </p>
                    <p>
                      <strong>Email:</strong> {user.email}
                    </p>
                    <p>
                      <strong>Perfil cargado:</strong> {profile ? "Sí" : "No"}
                    </p>
                    {profile && (
                      <>
                        <p>
                          <strong>Nombre:</strong> {profile.name}
                        </p>
                        <p>
                          <strong>Es Freelancer:</strong> {profile.is_freelancer ? "Sí" : "No"}
                        </p>
                        <p>
                          <strong>Es Admin:</strong> {profile.is_admin ? "Sí" : "No"}
                        </p>
                      </>
                    )}
                  </>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Estado de Sesión (Servidor)</CardTitle>
            <CardDescription>Información de la sesión desde el servidor</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <p>Verificando sesión en el servidor...</p>
            ) : (
              <div className="space-y-2">
                {sessionInfo ? (
                  <pre className="bg-gray-100 p-4 rounded overflow-auto text-sm">
                    {JSON.stringify(sessionInfo, null, 2)}
                  </pre>
                ) : (
                  <p>No se pudo obtener información de sesión</p>
                )}
              </div>
            )}
          </CardContent>
          <CardFooter>
            <Button onClick={checkServerSession} disabled={isLoading}>
              Verificar sesión
            </Button>
          </CardFooter>
        </Card>

        <div className="flex gap-4">
          <Button onClick={() => router.push("/dashboard")}>Ir al Dashboard</Button>

          <Button variant="outline" onClick={() => router.push("/auth/login")}>
            Ir a Login
          </Button>

          {user && (
            <Button variant="destructive" onClick={signOut}>
              Cerrar Sesión
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}
