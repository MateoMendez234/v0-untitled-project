import { Suspense } from "react"
import { SearchFilters } from "@/components/search/search-filters"
import { SearchResults } from "@/components/search/search-results"

export default function ExplorePage({
  searchParams,
}: {
  searchParams: { q?: string; category?: string[] | string; location?: string; page?: string }
}) {
  // Normalizar los parámetros de búsqueda
  const query = searchParams.q || ""
  const categories = Array.isArray(searchParams.category)
    ? searchParams.category
    : searchParams.category
      ? [searchParams.category]
      : []
  const location = searchParams.location || ""
  const page = searchParams.page ? Number.parseInt(searchParams.page) : 1

  return (
    <main className="container px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Explorar servicios y freelancers</h1>

      <div className="flex flex-col md:flex-row gap-8">
        <div className="w-full md:w-1/4">
          <SearchFilters currentQuery={query} currentCategories={categories} currentLocation={location} />
        </div>

        <div className="w-full md:w-3/4">
          <Suspense fallback={<div>Cargando resultados...</div>}>
            <SearchResults query={query} categories={categories} location={location} page={page} />
          </Suspense>
        </div>
      </div>
    </main>
  )
}
