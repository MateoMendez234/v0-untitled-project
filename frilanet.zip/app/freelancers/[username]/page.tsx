import { notFound } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import type { Metadata } from "next"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { StarRating } from "@/components/reviews/star-rating"
import { MapPin, Calendar, Globe, Award, Briefcase, ExternalLink } from "lucide-react"
import { ContactFreelancerButton } from "@/components/messages/contact-freelancer-button"
import { PortfolioGallery } from "@/components/portfolio/portfolio-gallery"
import { getProfileByUsername } from "@/lib/services/profile-service"
import { getServicesByProfileId } from "@/lib/services/service-service"
import { getPortfolioByProfileId } from "@/lib/services/portfolio-service"
import { getServerSession } from "next-auth"
import { authOptions } from "@/lib/auth"

interface FreelancerProfilePageProps {
  params: {
    username: string
  }
}

export async function generateMetadata({ params }: FreelancerProfilePageProps): Promise<Metadata> {
  const profile = await getProfileByUsername(params.username)

  if (!profile) {
    return {
      title: "Perfil no encontrado",
    }
  }

  return {
    title: `${profile.name || profile.username} | Frilanet`,
    description: profile.about || `Perfil de ${profile.name || profile.username} en Frilanet`,
  }
}

export default async function FreelancerProfilePage({ params }: FreelancerProfilePageProps) {
  const profile = await getProfileByUsername(params.username)

  if (!profile) {
    notFound()
  }

  const services = await getServicesByProfileId(profile._id)
  const portfolioItems = await getPortfolioByProfileId(profile._id)

  // Obtener el usuario actual
  const session = await getServerSession(authOptions)
  const currentUserId = session?.user?.id

  // Verificar si el perfil actual es del usuario logueado
  const isOwnProfile = currentUserId === profile.userId

  const formatDate = (dateString: Date) => {
    return new Intl.DateTimeFormat("es-ES", { year: "numeric", month: "long" }).format(dateString)
  }

  return (
    <div className="container py-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Sidebar con información del perfil */}
        <div className="md:col-span-1 space-y-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col items-center text-center">
                <div className="relative w-32 h-32 rounded-full overflow-hidden mb-4">
                  <Image
                    src={profile.avatarUrl || "/placeholder.svg?height=128&width=128"}
                    alt={profile.name || ""}
                    className="object-cover"
                    fill
                    priority
                  />
                </div>
                <h1 className="text-2xl font-bold">{profile.name}</h1>
                <p className="text-gray-500 mb-2">@{profile.username}</p>
                {profile.title && <p className="text-blue-600 font-medium mb-4">{profile.title}</p>}

                {profile.rating && profile.ratingCount ? (
                  <div className="flex items-center justify-center mb-4">
                    <StarRating rating={profile.rating} />
                    <span className="ml-2 text-sm text-gray-500">({profile.ratingCount})</span>
                  </div>
                ) : (
                  <p className="text-sm text-gray-500 mb-4">Sin valoraciones</p>
                )}

                {!isOwnProfile && (
                  <ContactFreelancerButton
                    freelancerId={profile._id}
                    freelancerName={profile.name || profile.username || "Freelancer"}
                    currentUserId={currentUserId}
                  />
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Información</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {profile.location && (
                <div className="flex items-center">
                  <MapPin className="h-5 w-5 text-gray-500 mr-2" />
                  <span>{profile.location}</span>
                </div>
              )}
              {profile.memberSince && (
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 text-gray-500 mr-2" />
                  <span>Miembro desde {formatDate(profile.memberSince)}</span>
                </div>
              )}
              {profile.languages && profile.languages.length > 0 && (
                <div className="flex items-start">
                  <Globe className="h-5 w-5 text-gray-500 mr-2 mt-0.5" />
                  <div>
                    <span className="font-medium">Idiomas:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {profile.languages.map((language) => (
                        <Badge key={language} variant="outline">
                          {language}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              )}
              {profile.skills && profile.skills.length > 0 && (
                <div className="flex items-start">
                  <Award className="h-5 w-5 text-gray-500 mr-2 mt-0.5" />
                  <div>
                    <span className="font-medium">Habilidades:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {profile.skills.map((skill) => (
                        <Badge key={skill} variant="outline" className="bg-blue-50">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              )}
              {profile.website && (
                <div className="flex items-center">
                  <ExternalLink className="h-5 w-5 text-gray-500 mr-2" />
                  <a
                    href={profile.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:underline"
                  >
                    {profile.website.replace(/^https?:\/\//, "")}
                  </a>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Contenido principal */}
        <div className="md:col-span-2">
          <Tabs defaultValue="about">
            <TabsList className="mb-6">
              <TabsTrigger value="about">Sobre mí</TabsTrigger>
              <TabsTrigger value="services">Servicios</TabsTrigger>
              <TabsTrigger value="portfolio">Portafolio</TabsTrigger>
            </TabsList>

            <TabsContent value="about">
              <Card>
                <CardHeader>
                  <CardTitle>Sobre mí</CardTitle>
                </CardHeader>
                <CardContent>
                  {profile.about ? (
                    <div className="prose max-w-none">
                      <p className="whitespace-pre-line">{profile.about}</p>
                    </div>
                  ) : (
                    <p className="text-gray-500">Este freelancer no ha añadido información sobre sí mismo.</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="services">
              {services.length > 0 ? (
                <div className="grid grid-cols-1 gap-6">
                  {services.map((service) => (
                    <Card key={service._id}>
                      <CardHeader>
                        <CardTitle>{service.title}</CardTitle>
                        <CardDescription>
                          {service.category && <Badge className="bg-blue-100 text-blue-800">{service.category}</Badge>}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <p className="line-clamp-3">{service.description}</p>
                      </CardContent>
                      <CardFooter className="flex justify-between items-center">
                        <div className="flex items-center">
                          <span className="font-bold text-lg">${service.basePrice.toFixed(2)}</span>
                          <span className="text-gray-500 ml-1">USD</span>
                        </div>
                        <Button asChild className="bg-blue-600 hover:bg-blue-700">
                          <Link href={`/freelancers/${profile.username}/servicios/${service._id}`}>Ver detalles</Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card>
                  <CardContent className="py-8 text-center">
                    <Briefcase className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500">Este freelancer no ha publicado servicios todavía.</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="portfolio">
              {portfolioItems.length > 0 ? (
                <Card>
                  <CardHeader>
                    <CardTitle>Portafolio</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <PortfolioGallery items={portfolioItems} />
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardContent className="py-8 text-center">
                    <Image
                      src="/placeholder.svg?height=64&width=64"
                      alt="No portfolio"
                      width={64}
                      height={64}
                      className="mx-auto mb-4"
                    />
                    <p className="text-gray-500">Este freelancer no ha añadido elementos a su portafolio.</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
