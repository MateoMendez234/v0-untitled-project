import { notFound } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import type { Metadata } from "next"
import { getServiceById } from "@/lib/services"
import { getProfileByUsername } from "@/lib/profiles"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { StarRating } from "@/components/reviews/star-rating"
import { ReviewSummary } from "@/components/reviews/review-summary"
import { ReviewList } from "@/components/reviews/review-list"
import { getReviewsForService } from "@/lib/reviews"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import { ContactFreelancerButton } from "@/components/messages/contact-freelancer-button"

interface ServicePageProps {
  params: {
    username: string
    id: string
  }
}

export async function generateMetadata({ params }: ServicePageProps): Promise<Metadata> {
  const service = await getServiceById(params.id)

  if (!service) {
    return {
      title: "Servicio no encontrado",
    }
  }

  return {
    title: `${service.title} | Frilanet`,
    description: service.description || `Servicio ofrecido por ${service.profile?.name || "un freelancer"} en Frilanet`,
  }
}

export default async function ServicePage({ params }: ServicePageProps) {
  const service = await getServiceById(params.id)

  if (!service) {
    notFound()
  }

  const profile = await getProfileByUsername(params.username)

  if (!profile || profile.id !== service.profile_id) {
    notFound()
  }

  const reviews = await getReviewsForService(service.id)

  // Obtener el usuario actual
  const supabase = createServerSupabaseClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  const currentUserId = user?.id

  // Verificar si el perfil actual es del usuario logueado
  const isOwnProfile = currentUserId === profile.id

  return (
    <div className="container py-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Sidebar con información del servicio */}
        <div className="md:col-span-1 space-y-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col items-center text-center">
                <div className="relative w-32 h-32 rounded-full overflow-hidden mb-4">
                  <Image
                    src={profile.avatar_url || "/placeholder.svg?height=128&width=128"}
                    alt={profile.name || ""}
                    className="object-cover"
                    fill
                    priority
                  />
                </div>
                <h2 className="text-xl font-bold">{profile.name}</h2>
                <p className="text-gray-500 mb-2">@{profile.username}</p>
                {profile.title && <p className="text-blue-600 font-medium mb-4">{profile.title}</p>}

                {profile.rating && profile.rating_count ? (
                  <div className="flex items-center justify-center mb-4">
                    <StarRating rating={profile.rating} />
                    <span className="ml-2 text-sm text-gray-500">({profile.rating_count})</span>
                  </div>
                ) : (
                  <p className="text-sm text-gray-500 mb-4">Sin valoraciones</p>
                )}

                {!isOwnProfile && (
                  <ContactFreelancerButton
                    freelancerId={profile.id}
                    freelancerName={profile.name || profile.username || "Freelancer"}
                    currentUserId={currentUserId}
                    serviceId={service.id}
                    serviceTitle={service.title}
                  />
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Paquetes</CardTitle>
              <CardDescription>Selecciona el paquete que mejor se adapte a tus necesidades</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {service.packages && service.packages.length > 0 ? (
                service.packages.map((pkg) => (
                  <Card key={pkg.id} className="border-2 hover:border-blue-500 transition-colors">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">{pkg.title}</CardTitle>
                      <CardDescription>{pkg.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="pb-2">
                      <div className="font-bold text-xl mb-2">
                        ${pkg.price.toFixed(2)} <span className="text-sm font-normal text-gray-500">USD</span>
                      </div>
                      <div className="text-sm text-gray-500 mb-2">Entrega en {pkg.delivery_time} días</div>
                      <ul className="space-y-1 text-sm">
                        {pkg.features &&
                          pkg.features.map((feature, index) => (
                            <li key={index} className="flex items-start">
                              <span className="text-blue-500 mr-2">✓</span>
                              {feature.description}
                            </li>
                          ))}
                      </ul>
                    </CardContent>
                    <CardFooter>
                      <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
                        <Link href={`/checkout?service=${service.id}&package=${pkg.id}`}>Contratar</Link>
                      </Button>
                    </CardFooter>
                  </Card>
                ))
              ) : (
                <p className="text-gray-500 text-center py-4">No hay paquetes disponibles para este servicio.</p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Contenido principal */}
        <div className="md:col-span-2">
          <Card className="mb-6">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-2xl">{service.title}</CardTitle>
                  {service.category && <Badge className="mt-2 bg-blue-100 text-blue-800">{service.category}</Badge>}
                </div>
                <div className="text-right">
                  <div className="font-bold text-2xl">${service.base_price.toFixed(2)}</div>
                  <div className="text-sm text-gray-500">Precio base</div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="prose max-w-none">
                <p className="whitespace-pre-line">{service.description}</p>
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="details">
            <TabsList className="mb-6">
              <TabsTrigger value="details">Detalles</TabsTrigger>
              <TabsTrigger value="reviews">Reseñas ({reviews.length})</TabsTrigger>
              <TabsTrigger value="faq">Preguntas frecuentes</TabsTrigger>
            </TabsList>

            <TabsContent value="details">
              <Card>
                <CardHeader>
                  <CardTitle>Detalles del servicio</CardTitle>
                </CardHeader>
                <CardContent>
                  {service.details ? (
                    <div className="prose max-w-none">
                      <p className="whitespace-pre-line">{service.details}</p>
                    </div>
                  ) : (
                    <p className="text-gray-500">No hay detalles adicionales para este servicio.</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="reviews">
              <Card>
                <CardHeader>
                  <CardTitle>Reseñas de clientes</CardTitle>
                </CardHeader>
                <CardContent>
                  {reviews.length > 0 ? (
                    <>
                      <ReviewSummary reviews={reviews} className="mb-8" />
                      <ReviewList reviews={reviews} />
                    </>
                  ) : (
                    <p className="text-gray-500 text-center py-4">Este servicio aún no tiene reseñas.</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="faq">
              <Card>
                <CardHeader>
                  <CardTitle>Preguntas frecuentes</CardTitle>
                </CardHeader>
                <CardContent>
                  {service.faqs && service.faqs.length > 0 ? (
                    <Accordion type="single" collapsible className="w-full">
                      {service.faqs.map((faq, index) => (
                        <AccordionItem key={index} value={`item-${index}`}>
                          <AccordionTrigger>{faq.question}</AccordionTrigger>
                          <AccordionContent>{faq.answer}</AccordionContent>
                        </AccordionItem>
                      ))}
                    </Accordion>
                  ) : (
                    <p className="text-gray-500 text-center py-4">No hay preguntas frecuentes para este servicio.</p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
