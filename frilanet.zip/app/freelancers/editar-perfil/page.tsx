"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { AlertCircle, ArrowLeft, Camera, Check, Globe, Loader2, Plus, Save, Trash2, Upload, X } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"

// Datos de ejemplo para el perfil
const freelancerData = {
  id: "1",
  username: "anamartinez",
  name: "Ana Martínez",
  title: "Diseñadora Gráfica & Ilustradora",
  avatar: "/placeholder.svg?height=150&width=150",
  coverImage: "/placeholder.svg?height=400&width=1200",
  location: "Madrid, España",
  email: "ana.martinez@ejemplo.com",
  phone: "+34 612 345 678",
  website: "www.anamartinez.com",
  languages: ["Español", "Inglés", "Francés"],
  skills: ["Diseño Gráfico", "Ilustración", "Branding", "UI/UX", "Adobe Photoshop", "Adobe Illustrator"],
  about:
    "Soy una diseñadora gráfica con más de 8 años de experiencia especializada en branding e identidad visual. Me apasiona crear diseños únicos y memorables que ayuden a las marcas a destacar en el mercado. Mi enfoque combina creatividad con estrategia para entregar resultados que no solo se ven bien, sino que también cumplen objetivos comerciales.",
  services: [
    {
      id: "1",
      title: "Diseño de Logo Profesional",
      description: "Diseño de logo único y memorable para tu marca con revisiones ilimitadas.",
      price: 150,
      deliveryTime: "3 días",
      image: "/placeholder.svg?height=200&width=300",
      featured: true,
    },
    {
      id: "2",
      title: "Identidad Visual Completa",
      description:
        "Paquete completo de identidad visual incluyendo logo, paleta de colores, tipografía y aplicaciones.",
      price: 350,
      deliveryTime: "7 días",
      image: "/placeholder.svg?height=200&width=300",
      featured: false,
    },
    {
      id: "3",
      title: "Ilustración Personalizada",
      description: "Ilustraciones únicas para tu sitio web, redes sociales o material impreso.",
      price: 120,
      deliveryTime: "5 días",
      image: "/placeholder.svg?height=200&width=300",
      featured: false,
    },
  ],
  portfolio: [
    {
      id: "1",
      title: "Rediseño de marca para Café Aroma",
      description: "Renovación completa de identidad visual para cadena de cafeterías.",
      image: "/placeholder.svg?height=300&width=400",
      category: "Branding",
    },
    {
      id: "2",
      title: "Ilustraciones para revista Natura",
      description: "Serie de ilustraciones para artículo sobre sostenibilidad.",
      image: "/placeholder.svg?height=300&width=400",
      category: "Ilustración",
    },
    {
      id: "3",
      title: "Diseño de packaging para Organic Foods",
      description: "Línea completa de packaging para productos orgánicos.",
      image: "/placeholder.svg?height=300&width=400",
      category: "Packaging",
    },
    {
      id: "4",
      title: "Identidad visual para Tech Summit 2023",
      description: "Branding completo para evento tecnológico internacional.",
      image: "/placeholder.svg?height=300&width=400",
      category: "Branding",
    },
  ],
}

export default function EditarPerfil() {
  const [freelancer, setFreelancer] = useState(freelancerData)
  const [newSkill, setNewSkill] = useState("")
  const [newLanguage, setNewLanguage] = useState("")
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  // Función para manejar cambios en los campos de texto
  const handleChange = (e) => {
    const { name, value } = e.target
    setFreelancer((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  // Función para añadir una nueva habilidad
  const addSkill = () => {
    if (newSkill && !freelancer.skills.includes(newSkill)) {
      setFreelancer((prev) => ({
        ...prev,
        skills: [...prev.skills, newSkill],
      }))
      setNewSkill("")
    }
  }

  // Función para eliminar una habilidad
  const removeSkill = (skill) => {
    setFreelancer((prev) => ({
      ...prev,
      skills: prev.skills.filter((s) => s !== skill),
    }))
  }

  // Función para añadir un nuevo idioma
  const addLanguage = () => {
    if (newLanguage && !freelancer.languages.includes(newLanguage)) {
      setFreelancer((prev) => ({
        ...prev,
        languages: [...prev.languages, newLanguage],
      }))
      setNewLanguage("")
    }
  }

  // Función para eliminar un idioma
  const removeLanguage = (language) => {
    setFreelancer((prev) => ({
      ...prev,
      languages: prev.languages.filter((l) => l !== language),
    }))
  }

  // Función para actualizar un servicio
  const updateService = (id, field, value) => {
    setFreelancer((prev) => ({
      ...prev,
      services: prev.services.map((service) => (service.id === id ? { ...service, [field]: value } : service)),
    }))
  }

  // Función para cambiar el estado de destacado de un servicio
  const toggleFeatured = (id) => {
    setFreelancer((prev) => ({
      ...prev,
      services: prev.services.map((service) =>
        service.id === id ? { ...service, featured: !service.featured } : service,
      ),
    }))
  }

  // Función para eliminar un servicio
  const removeService = (id) => {
    setFreelancer((prev) => ({
      ...prev,
      services: prev.services.filter((service) => service.id !== id),
    }))
  }

  // Función para añadir un nuevo servicio
  const addService = () => {
    const newService = {
      id: `new-${Date.now()}`,
      title: "Nuevo Servicio",
      description: "Descripción del servicio",
      price: 100,
      deliveryTime: "5 días",
      image: "/placeholder.svg?height=200&width=300",
      featured: false,
    }
    setFreelancer((prev) => ({
      ...prev,
      services: [...prev.services, newService],
    }))
  }

  // Función para actualizar un elemento del portafolio
  const updatePortfolioItem = (id, field, value) => {
    setFreelancer((prev) => ({
      ...prev,
      portfolio: prev.portfolio.map((item) => (item.id === id ? { ...item, [field]: value } : item)),
    }))
  }

  // Función para eliminar un elemento del portafolio
  const removePortfolioItem = (id) => {
    setFreelancer((prev) => ({
      ...prev,
      portfolio: prev.portfolio.filter((item) => item.id !== id),
    }))
  }

  // Función para añadir un nuevo elemento al portafolio
  const addPortfolioItem = () => {
    const newItem = {
      id: `new-${Date.now()}`,
      title: "Nuevo Proyecto",
      description: "Descripción del proyecto",
      image: "/placeholder.svg?height=300&width=400",
      category: "Otro",
    }
    setFreelancer((prev) => ({
      ...prev,
      portfolio: [...prev.portfolio, newItem],
    }))
  }

  // Función para guardar los cambios
  const saveChanges = () => {
    setSaving(true)
    // Aquí iría la lógica para guardar los cambios en la base de datos
    setTimeout(() => {
      setSaving(false)
      setSaved(true)
      setTimeout(() => setSaved(false), 3000)
    }, 1500)
  }

  return (
    <div className="flex flex-col min-h-screen">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2 font-bold text-xl text-emerald-600">
            <Globe className="h-6 w-6" />
            <span>Frilanet</span>
          </div>
          <nav className="hidden md:flex gap-6">
            <Link href="/" className="text-sm font-medium hover:text-emerald-600 transition-colors">
              Inicio
            </Link>
            <Link href="#" className="text-sm font-medium hover:text-emerald-600 transition-colors">
              Explorar
            </Link>
            <Link href="#" className="text-sm font-medium hover:text-emerald-600 transition-colors">
              Categorías
            </Link>
            <Link href="#" className="text-sm font-medium hover:text-emerald-600 transition-colors">
              Cómo funciona
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <Link href="#" className="text-sm font-medium hover:text-emerald-600 transition-colors hidden md:block">
              Iniciar sesión
            </Link>
            <Button className="bg-emerald-600 hover:bg-emerald-700">Registrarse</Button>
          </div>
        </div>
      </header>

      <main className="flex-1 container px-4 md:px-6 py-8">
        <div className="flex items-center gap-2 mb-6">
          <Link href={`/freelancers/${freelancer.username}`} className="text-gray-500 hover:text-emerald-600">
            <ArrowLeft className="h-5 w-5" />
          </Link>
          <h1 className="text-2xl font-bold">Editar Perfil</h1>
        </div>

        {saved && (
          <Alert className="mb-6 bg-emerald-50 text-emerald-800 border-emerald-200">
            <Check className="h-4 w-4" />
            <AlertDescription>Los cambios han sido guardados correctamente.</AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="personal" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="personal">Información Personal</TabsTrigger>
            <TabsTrigger value="services">Servicios</TabsTrigger>
            <TabsTrigger value="portfolio">Portafolio</TabsTrigger>
            <TabsTrigger value="account">Cuenta</TabsTrigger>
          </TabsList>

          {/* Información Personal */}
          <TabsContent value="personal" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Imágenes de perfil</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label>Imagen de portada</Label>
                  <div className="relative w-full h-48 overflow-hidden rounded-lg border">
                    <Image
                      src={freelancer.coverImage || "/placeholder.svg"}
                      alt="Portada"
                      className="object-cover"
                      fill
                    />
                    <div className="absolute inset-0 flex items-center justify-center bg-black/30 opacity-0 hover:opacity-100 transition-opacity">
                      <Button variant="secondary" size="sm" className="gap-2">
                        <Camera className="h-4 w-4" />
                        Cambiar imagen
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Foto de perfil</Label>
                  <div className="flex items-center gap-4">
                    <div className="relative w-24 h-24 rounded-full overflow-hidden border">
                      <Image src={freelancer.avatar || "/placeholder.svg"} alt="Avatar" className="object-cover" fill />
                      <div className="absolute inset-0 flex items-center justify-center bg-black/30 opacity-0 hover:opacity-100 transition-opacity rounded-full">
                        <Button variant="secondary" size="sm" className="w-8 h-8 p-0 rounded-full">
                          <Camera className="h-4 w-4" />
                          <span className="sr-only">Cambiar foto</span>
                        </Button>
                      </div>
                    </div>
                    <div className="text-sm text-gray-500">
                      <p>Recomendado: JPG, PNG. Máximo 1MB</p>
                      <p>Tamaño mínimo: 400x400 píxeles</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Información básica</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nombre completo</Label>
                    <Input
                      id="name"
                      name="name"
                      value={freelancer.name}
                      onChange={handleChange}
                      placeholder="Tu nombre completo"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="title">Título profesional</Label>
                    <Input
                      id="title"
                      name="title"
                      value={freelancer.title}
                      onChange={handleChange}
                      placeholder="Ej: Diseñador Gráfico & Ilustrador"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="location">Ubicación</Label>
                    <Input
                      id="location"
                      name="location"
                      value={freelancer.location}
                      onChange={handleChange}
                      placeholder="Ej: Madrid, España"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="website">Sitio web</Label>
                    <Input
                      id="website"
                      name="website"
                      value={freelancer.website}
                      onChange={handleChange}
                      placeholder="Ej: www.tusitio.com"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="about">Acerca de mí</Label>
                  <Textarea
                    id="about"
                    name="about"
                    value={freelancer.about}
                    onChange={handleChange}
                    placeholder="Describe tu experiencia, especialidades y enfoque profesional"
                    rows={6}
                  />
                  <p className="text-sm text-gray-500">
                    Una buena descripción ayuda a los clientes a conocerte mejor y aumenta tus posibilidades de ser
                    contratado.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Habilidades e idiomas</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <Label>Habilidades</Label>
                  <div className="flex flex-wrap gap-2 mb-2">
                    {freelancer.skills.map((skill, index) => (
                      <Badge key={index} variant="secondary" className="pl-2 pr-1 py-1 flex items-center gap-1">
                        {skill}
                        <button onClick={() => removeSkill(skill)} className="ml-1 rounded-full hover:bg-gray-200 p-1">
                          <X className="h-3 w-3" />
                          <span className="sr-only">Eliminar {skill}</span>
                        </button>
                      </Badge>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Input
                      value={newSkill}
                      onChange={(e) => setNewSkill(e.target.value)}
                      placeholder="Añadir nueva habilidad"
                      onKeyDown={(e) => e.key === "Enter" && addSkill()}
                    />
                    <Button type="button" onClick={addSkill} variant="outline" className="shrink-0">
                      <Plus className="h-4 w-4 mr-2" />
                      Añadir
                    </Button>
                  </div>
                </div>

                <div className="space-y-4">
                  <Label>Idiomas</Label>
                  <div className="flex flex-wrap gap-2 mb-2">
                    {freelancer.languages.map((language, index) => (
                      <Badge key={index} variant="secondary" className="pl-2 pr-1 py-1 flex items-center gap-1">
                        {language}
                        <button
                          onClick={() => removeLanguage(language)}
                          className="ml-1 rounded-full hover:bg-gray-200 p-1"
                        >
                          <X className="h-3 w-3" />
                          <span className="sr-only">Eliminar {language}</span>
                        </button>
                      </Badge>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <Input
                      value={newLanguage}
                      onChange={(e) => setNewLanguage(e.target.value)}
                      placeholder="Añadir nuevo idioma"
                      onKeyDown={(e) => e.key === "Enter" && addLanguage()}
                    />
                    <Button type="button" onClick={addLanguage} variant="outline" className="shrink-0">
                      <Plus className="h-4 w-4 mr-2" />
                      Añadir
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Servicios */}
          <TabsContent value="services" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Tus servicios</h2>
              <Button onClick={addService} className="bg-emerald-600 hover:bg-emerald-700">
                <Plus className="h-4 w-4 mr-2" />
                Nuevo servicio
              </Button>
            </div>

            <div className="grid grid-cols-1 gap-6">
              {freelancer.services.map((service) => (
                <Card key={service.id}>
                  <CardContent className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="space-y-4">
                        <div className="relative h-40 w-full rounded-lg overflow-hidden border">
                          <Image
                            src={service.image || "/placeholder.svg"}
                            alt={service.title}
                            className="object-cover"
                            fill
                          />
                          <div className="absolute inset-0 flex items-center justify-center bg-black/30 opacity-0 hover:opacity-100 transition-opacity">
                            <Button variant="secondary" size="sm" className="gap-2">
                              <Upload className="h-4 w-4" />
                              Cambiar imagen
                            </Button>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Switch
                            checked={service.featured}
                            onCheckedChange={() => toggleFeatured(service.id)}
                            id={`featured-${service.id}`}
                          />
                          <Label htmlFor={`featured-${service.id}`} className="text-sm">
                            Destacar este servicio
                          </Label>
                        </div>
                      </div>

                      <div className="md:col-span-2 space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor={`title-${service.id}`}>Título del servicio</Label>
                          <Input
                            id={`title-${service.id}`}
                            value={service.title}
                            onChange={(e) => updateService(service.id, "title", e.target.value)}
                            placeholder="Ej: Diseño de Logo Profesional"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label htmlFor={`description-${service.id}`}>Descripción</Label>
                          <Textarea
                            id={`description-${service.id}`}
                            value={service.description}
                            onChange={(e) => updateService(service.id, "description", e.target.value)}
                            placeholder="Describe lo que incluye tu servicio"
                            rows={3}
                          />
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor={`price-${service.id}`}>Precio (€)</Label>
                            <Input
                              id={`price-${service.id}`}
                              type="number"
                              value={service.price}
                              onChange={(e) => updateService(service.id, "price", Number(e.target.value))}
                              placeholder="Ej: 150"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor={`delivery-${service.id}`}>Tiempo de entrega</Label>
                            <Input
                              id={`delivery-${service.id}`}
                              value={service.deliveryTime}
                              onChange={(e) => updateService(service.id, "deliveryTime", e.target.value)}
                              placeholder="Ej: 3 días"
                            />
                          </div>
                        </div>

                        <div className="flex justify-end">
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => removeService(service.id)}
                            className="gap-2"
                          >
                            <Trash2 className="h-4 w-4" />
                            Eliminar servicio
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Portafolio */}
          <TabsContent value="portfolio" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Tu portafolio</h2>
              <Button onClick={addPortfolioItem} className="bg-emerald-600 hover:bg-emerald-700">
                <Plus className="h-4 w-4 mr-2" />
                Nuevo proyecto
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {freelancer.portfolio.map((item) => (
                <Card key={item.id}>
                  <CardContent className="p-6 space-y-4">
                    <div className="relative h-48 w-full rounded-lg overflow-hidden border">
                      <Image src={item.image || "/placeholder.svg"} alt={item.title} className="object-cover" fill />
                      <div className="absolute inset-0 flex items-center justify-center bg-black/30 opacity-0 hover:opacity-100 transition-opacity">
                        <Button variant="secondary" size="sm" className="gap-2">
                          <Upload className="h-4 w-4" />
                          Cambiar imagen
                        </Button>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor={`portfolio-title-${item.id}`}>Título del proyecto</Label>
                        <Input
                          id={`portfolio-title-${item.id}`}
                          value={item.title}
                          onChange={(e) => updatePortfolioItem(item.id, "title", e.target.value)}
                          placeholder="Ej: Rediseño de marca"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor={`portfolio-category-${item.id}`}>Categoría</Label>
                        <Select
                          value={item.category}
                          onValueChange={(value) => updatePortfolioItem(item.id, "category", value)}
                        >
                          <SelectTrigger id={`portfolio-category-${item.id}`}>
                            <SelectValue placeholder="Selecciona una categoría" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Branding">Branding</SelectItem>
                            <SelectItem value="Ilustración">Ilustración</SelectItem>
                            <SelectItem value="UI/UX">UI/UX</SelectItem>
                            <SelectItem value="Packaging">Packaging</SelectItem>
                            <SelectItem value="Web">Diseño Web</SelectItem>
                            <SelectItem value="Otro">Otro</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor={`portfolio-description-${item.id}`}>Descripción</Label>
                        <Textarea
                          id={`portfolio-description-${item.id}`}
                          value={item.description}
                          onChange={(e) => updatePortfolioItem(item.id, "description", e.target.value)}
                          placeholder="Describe brevemente el proyecto"
                          rows={2}
                        />
                      </div>

                      <div className="flex justify-end">
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => removePortfolioItem(item.id)}
                          className="gap-2"
                        >
                          <Trash2 className="h-4 w-4" />
                          Eliminar
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Cuenta */}
          <TabsContent value="account" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Información de contacto</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">Correo electrónico</Label>
                    <Input
                      id="email"
                      name="email"
                      value={freelancer.email}
                      onChange={handleChange}
                      placeholder="tu@email.com"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Teléfono</Label>
                    <Input
                      id="phone"
                      name="phone"
                      value={freelancer.phone}
                      onChange={handleChange}
                      placeholder="+34 612 345 678"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Configuración de cuenta</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="username">Nombre de usuario</Label>
                  <div className="flex items-center gap-2">
                    <Input
                      id="username"
                      name="username"
                      value={freelancer.username}
                      onChange={handleChange}
                      placeholder="tunombredeusuario"
                    />
                    <Button variant="outline" className="shrink-0">
                      Verificar
                    </Button>
                  </div>
                  <p className="text-sm text-gray-500">Tu URL será: frilanet.com/freelancers/{freelancer.username}</p>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="password">Contraseña</Label>
                    <Button variant="link" className="h-auto p-0 text-emerald-600">
                      Cambiar contraseña
                    </Button>
                  </div>
                  <Input id="password" type="password" value="••••••••" disabled />
                </div>

                <Alert className="bg-amber-50 text-amber-800 border-amber-200">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    Para eliminar tu cuenta, por favor contacta con soporte. Esta acción no se puede deshacer.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end gap-4 mt-8">
          <Button variant="outline">Cancelar</Button>
          <Button onClick={saveChanges} className="bg-emerald-600 hover:bg-emerald-700" disabled={saving}>
            {saving ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Guardando...
              </>
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" />
                Guardar cambios
              </>
            )}
          </Button>
        </div>
      </main>

      <footer className="w-full py-6 bg-gray-100">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center gap-2 font-bold text-xl text-emerald-600 mb-4 md:mb-0">
              <Globe className="h-6 w-6" />
              <span>Frilanet</span>
            </div>
            <p className="text-center text-sm text-gray-500">© 2024 Frilanet. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
