import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { SearchBar } from "@/components/search/search-bar"
import { Globe, Star, Shield, Search } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-white to-gray-100">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center space-y-4 text-center">
            <div className="space-y-2">
              <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl">
                Encuentra el freelancer perfecto para tu proyecto
              </h1>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl">
                Conectamos a empresas con los mejores profesionales independientes para cualquier tipo de proyecto.
              </p>
            </div>
            <div className="w-full max-w-lg">
              <SearchBar />
            </div>
            <div className="flex flex-wrap justify-center gap-4">
              <Button asChild className="bg-emerald-600 hover:bg-emerald-700">
                <Link href="/explorar">Explorar servicios</Link>
              </Button>
              <Button asChild variant="outline">
                <Link href="/auth/register?type=freelancer">Registrarse como freelancer</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Categorías populares */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Categorías populares</h2>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl">
                Explora las categorías más demandadas en nuestra plataforma
              </p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-8 w-full max-w-4xl">
              {[
                { name: "Diseño Gráfico", icon: "🎨" },
                { name: "Desarrollo Web", icon: "💻" },
                { name: "Marketing Digital", icon: "📱" },
                { name: "Redacción", icon: "✍️" },
                { name: "Traducción", icon: "🌐" },
                { name: "Video y Animación", icon: "🎬" },
                { name: "Audio y Música", icon: "🎵" },
                { name: "Consultoría", icon: "📊" },
              ].map((category) => (
                <Link
                  key={category.name}
                  href={`/explorar?category=${encodeURIComponent(category.name)}`}
                  className="flex flex-col items-center justify-center p-4 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  <span className="text-3xl mb-2">{category.icon}</span>
                  <span className="font-medium text-sm md:text-base">{category.name}</span>
                </Link>
              ))}
            </div>
            <Button asChild variant="outline" className="mt-4">
              <Link href="/categorias">Ver todas las categorías</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Cómo funciona */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-100">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Cómo funciona</h2>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl">
                Sigue estos sencillos pasos para encontrar el freelancer perfecto para tu proyecto
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-4xl">
              <div className="flex flex-col items-center space-y-2">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-100 text-emerald-600">
                  <Search className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold">Busca</h3>
                <p className="text-gray-500">Encuentra freelancers o servicios que se ajusten a tus necesidades</p>
              </div>
              <div className="flex flex-col items-center space-y-2">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-100 text-emerald-600">
                  <Star className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold">Compara</h3>
                <p className="text-gray-500">Revisa perfiles, portafolios y reseñas para elegir el mejor</p>
              </div>
              <div className="flex flex-col items-center space-y-2">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-100 text-emerald-600">
                  <Shield className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold">Contrata</h3>
                <p className="text-gray-500">Realiza el pago de forma segura y comienza a trabajar</p>
              </div>
            </div>
            <Button asChild className="bg-emerald-600 hover:bg-emerald-700 mt-4">
              <Link href="/como-funciona">Saber más</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Freelancers destacados */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Freelancers destacados</h2>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl">
                Conoce a algunos de nuestros mejores profesionales
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 w-full max-w-5xl">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex flex-col items-center space-y-2 p-6 border rounded-lg">
                  <div className="relative w-20 h-20 rounded-full overflow-hidden">
                    <Image
                      src={`/placeholder.svg?height=80&width=80&text=User+${i}`}
                      alt={`Freelancer ${i}`}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <h3 className="text-xl font-bold">Nombre del Freelancer</h3>
                  <p className="text-gray-500">Especialista en Diseño Web</p>
                  <div className="flex items-center space-x-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-4 w-4 text-yellow-400 fill-yellow-400" aria-hidden="true" />
                    ))}
                    <span className="ml-1 text-sm text-gray-500">(25 reseñas)</span>
                  </div>
                  <Button asChild variant="outline" className="mt-2">
                    <Link href={`/freelancers/usuario-${i}`}>Ver perfil</Link>
                  </Button>
                </div>
              ))}
            </div>
            <Button asChild className="bg-emerald-600 hover:bg-emerald-700 mt-4">
              <Link href="/explorar">Ver todos los freelancers</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Testimonios */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-100">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Lo que dicen nuestros clientes
              </h2>
              <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl">
                Descubre por qué empresas de todo el mundo confían en nosotros
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 w-full max-w-5xl">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex flex-col p-6 bg-white rounded-lg shadow-sm">
                  <div className="flex items-center space-x-1 mb-4">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-4 w-4 text-yellow-400 fill-yellow-400" aria-hidden="true" />
                    ))}
                  </div>
                  <p className="flex-1 text-gray-700 mb-4">
                    "Encontré al freelancer perfecto para mi proyecto en cuestión de horas. El proceso fue muy sencillo
                    y el resultado superó mis expectativas."
                  </p>
                  <div className="flex items-center space-x-3">
                    <div className="relative w-10 h-10 rounded-full overflow-hidden">
                      <Image
                        src={`/placeholder.svg?height=40&width=40&text=C${i}`}
                        alt={`Cliente ${i}`}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div>
                      <h4 className="font-semibold">Nombre del Cliente</h4>
                      <p className="text-sm text-gray-500">Empresa S.L.</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-emerald-600">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center text-white">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                ¿Listo para encontrar el talento que necesitas?
              </h2>
              <p className="mx-auto max-w-[700px] md:text-xl">
                Únete a miles de empresas que ya han encontrado a los mejores freelancers en nuestra plataforma
              </p>
            </div>
            <div className="flex flex-wrap justify-center gap-4">
              <Button asChild className="bg-white text-emerald-600 hover:bg-gray-100">
                <Link href="/explorar">Explorar servicios</Link>
              </Button>
              <Button asChild variant="outline" className="text-white border-white hover:bg-emerald-700">
                <Link href="/auth/register">Registrarse gratis</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="w-full py-6 bg-gray-900 text-white">
        <div className="container px-4 md:px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">Frilanet</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/sobre-nosotros" className="hover:text-emerald-400 transition-colors">
                    Sobre nosotros
                  </Link>
                </li>
                <li>
                  <Link href="/como-funciona" className="hover:text-emerald-400 transition-colors">
                    Cómo funciona
                  </Link>
                </li>
                <li>
                  <Link href="/blog" className="hover:text-emerald-400 transition-colors">
                    Blog
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Para clientes</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/explorar" className="hover:text-emerald-400 transition-colors">
                    Encontrar freelancers
                  </Link>
                </li>
                <li>
                  <Link href="/publicar-proyecto" className="hover:text-emerald-400 transition-colors">
                    Publicar un proyecto
                  </Link>
                </li>
                <li>
                  <Link href="/precios" className="hover:text-emerald-400 transition-colors">
                    Precios
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Para freelancers</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/auth/register?type=freelancer" className="hover:text-emerald-400 transition-colors">
                    Registrarse como freelancer
                  </Link>
                </li>
                <li>
                  <Link href="/encontrar-trabajos" className="hover:text-emerald-400 transition-colors">
                    Encontrar trabajos
                  </Link>
                </li>
                <li>
                  <Link href="/comisiones" className="hover:text-emerald-400 transition-colors">
                    Comisiones
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-4">Legal</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/privacidad" className="hover:text-emerald-400 transition-colors">
                    Política de privacidad
                  </Link>
                </li>
                <li>
                  <Link href="/terminos" className="hover:text-emerald-400 transition-colors">
                    Términos y condiciones
                  </Link>
                </li>
                <li>
                  <Link href="/cookies" className="hover:text-emerald-400 transition-colors">
                    Política de cookies
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="flex flex-col md:flex-row justify-between items-center mt-8 pt-8 border-t border-gray-800">
            <div className="flex items-center gap-2 font-bold text-xl text-emerald-400 mb-4 md:mb-0">
              <Globe className="h-6 w-6" />
              <span>Frilanet</span>
            </div>
            <p className="text-center text-sm text-gray-400">© 2024 Frilanet. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
