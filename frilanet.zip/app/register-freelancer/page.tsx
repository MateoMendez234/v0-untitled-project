"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { SiteHeader } from "@/components/layout/site-header"
import { SiteFooter } from "@/components/layout/site-footer"
import { Loader2 } from "lucide-react"

export default function RegisterFreelancerPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setLoading(true)
    setError(null)

    try {
      const formData = new FormData(event.currentTarget)
      const data = {
        name: formData.get("name") as string,
        email: formData.get("email") as string,
        password: formData.get("password") as string,
        title: formData.get("title") as string,
        location: formData.get("location") as string,
        about: formData.get("about") as string,
        skills: (formData.get("skills") as string).split(",").map((skill) => skill.trim()),
        languages: (formData.get("languages") as string).split(",").map((language) => language.trim()),
        isFreelancer: true,
      }

      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.error || "Error al registrar freelancer")
      }

      // Redirigir al login
      router.push("/auth/login?registered=true")
    } catch (err) {
      console.error("Error al registrar:", err)
      setError(err instanceof Error ? err.message : "Error al registrar freelancer")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex flex-col min-h-screen">
      <SiteHeader />

      <main className="flex-1 container px-4 md:px-6 py-8">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl font-bold">Regístrate como Freelancer</CardTitle>
              <CardDescription>
                Completa el formulario para crear tu perfil de freelancer y comenzar a ofrecer tus servicios.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Nombre completo</Label>
                      <Input id="name" name="name" required />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Correo electrónico</Label>
                      <Input id="email" name="email" type="email" required />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="password">Contraseña</Label>
                    <Input id="password" name="password" type="password" required />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="title">Título profesional</Label>
                    <Input id="title" name="title" placeholder="Ej: Diseñador Gráfico & Ilustrador" required />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="location">Ubicación</Label>
                    <Input id="location" name="location" placeholder="Ej: Madrid, España" required />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="about">Acerca de ti</Label>
                    <Textarea
                      id="about"
                      name="about"
                      placeholder="Describe tu experiencia, especialidades y lo que te hace único..."
                      rows={5}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="skills">Habilidades (separadas por comas)</Label>
                    <Input
                      id="skills"
                      name="skills"
                      placeholder="Ej: Diseño Gráfico, Ilustración, Adobe Photoshop"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="languages">Idiomas (separados por comas)</Label>
                    <Input id="languages" name="languages" placeholder="Ej: Español, Inglés, Francés" required />
                  </div>
                </div>

                {error && <div className="p-3 rounded-md bg-red-50 text-red-700">{error}</div>}

                <div className="flex flex-col space-y-4">
                  <Button type="submit" className="bg-emerald-600 hover:bg-emerald-700" disabled={loading}>
                    {loading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Registrando...
                      </>
                    ) : (
                      "Registrarse como Freelancer"
                    )}
                  </Button>
                  <p className="text-center text-sm text-gray-500">
                    ¿Ya tienes una cuenta?{" "}
                    <Link href="/auth/login" className="text-emerald-600 hover:underline">
                      Inicia sesión
                    </Link>
                  </p>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </main>

      <SiteFooter />
    </div>
  )
}
