"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import {
  LayoutDashboard,
  Users,
  Briefcase,
  Star,
  ShoppingCart,
  Settings,
  Database,
  FileText,
  AlertTriangle,
} from "lucide-react"
import { MongoDBStatus } from "./mongodb-status"

const adminRoutes = [
  {
    href: "/admin",
    label: "Dashboard",
    icon: LayoutDashboard,
  },
  {
    href: "/admin/usuarios",
    label: "Usuarios",
    icon: Users,
  },
  {
    href: "/admin/freelancers",
    label: "Freelancers",
    icon: Users,
  },
  {
    href: "/admin/servicios",
    label: "Servicios",
    icon: Briefcase,
  },
  {
    href: "/admin/pagos",
    label: "Pagos",
    icon: ShoppingCart,
  },
  {
    href: "/admin/resenas",
    label: "Reseñas",
    icon: Star,
  },
  {
    href: "/admin/diagnostico",
    label: "Diagnóstico",
    icon: AlertTriangle,
  },
  {
    href: "/admin/migrate",
    label: "Migración",
    icon: Database,
  },
  {
    href: "/admin/verificar-migracion",
    label: "Verificar Migración",
    icon: FileText,
  },
  {
    href: "/admin/configuracion",
    label: "Configuración",
    icon: Settings,
  },
]

export function AdminSidebar() {
  const pathname = usePathname()

  return (
    <div className="w-64 border-r h-screen sticky top-0 overflow-y-auto">
      <div className="p-4">
        <h2 className="text-xl font-bold mb-4">Panel de Administración</h2>
        <div className="mb-4">
          <MongoDBStatus />
        </div>
        <nav className="space-y-1">
          {adminRoutes.map((route) => (
            <Link key={route.href} href={route.href} passHref>
              <Button
                variant="ghost"
                className={cn("w-full justify-start", pathname === route.href ? "bg-muted font-medium" : "font-normal")}
              >
                <route.icon className="mr-2 h-4 w-4" />
                {route.label}
              </Button>
            </Link>
          ))}
        </nav>
      </div>
    </div>
  )
}
