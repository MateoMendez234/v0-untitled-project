"use client"

import { useState, useEffect } from "react"
import { Badge } from "@/components/ui/badge"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Database, AlertCircle } from "lucide-react"

export function MongoDBStatus() {
  const [status, setStatus] = useState<"loading" | "connected" | "error">("loading")
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const checkConnection = async () => {
      try {
        const response = await fetch("/api/admin/diagnostico")
        const data = await response.json()

        if (data.connection) {
          setStatus("connected")
        } else {
          setStatus("error")
          setError("No se pudo conectar a MongoDB")
        }
      } catch (error) {
        setStatus("error")
        setError("Error al verificar la conexión")
      }
    }

    checkConnection()
  }, [])

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className="flex items-center gap-2">
            <Database className="h-4 w-4" />
            <Badge
              variant={status === "connected" ? "default" : status === "loading" ? "outline" : "destructive"}
              className="px-2 py-0 h-5"
            >
              {status === "connected"
                ? "MongoDB Conectado"
                : status === "loading"
                  ? "Verificando..."
                  : "Error de Conexión"}
            </Badge>
            {status === "error" && <AlertCircle className="h-4 w-4 text-destructive" />}
          </div>
        </TooltipTrigger>
        <TooltipContent>
          {status === "connected"
            ? "La conexión a MongoDB está funcionando correctamente"
            : status === "loading"
              ? "Verificando conexión a MongoDB..."
              : error || "Error al conectar con MongoDB"}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  )
}
