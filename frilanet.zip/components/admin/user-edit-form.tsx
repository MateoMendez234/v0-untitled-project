"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import { Loader2, AlertCircle, Check } from "lucide-react"
import type { ProfileWithDetails } from "@/lib/profiles"

interface UserEditFormProps {
  user: ProfileWithDetails
}

export function UserEditForm({ user }: UserEditFormProps) {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  const [formData, setFormData] = useState({
    name: user.name || "",
    username: user.username || "",
    email: user.email || "",
    title: user.title || "",
    bio: user.bio || "",
    location: user.location || "",
    website: user.website || "",
    avatar_url: user.avatar_url || "",
    is_freelancer: user.is_freelancer || false,
    is_admin: user.is_admin || false,
    skills: user.skills || [],
    languages: user.languages || [],
    hourly_rate: user.hourly_rate || 0,
  })

  const [skillInput, setSkillInput] = useState("")
  const [languageInput, setLanguageInput] = useState("")

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSwitchChange = (name: string, checked: boolean) => {
    setFormData((prev) => ({ ...prev, [name]: checked }))
  }

  const addSkill = () => {
    if (skillInput.trim() && !formData.skills.includes(skillInput.trim())) {
      setFormData((prev) => ({
        ...prev,
        skills: [...prev.skills, skillInput.trim()],
      }))
      setSkillInput("")
    }
  }

  const removeSkill = (skill: string) => {
    setFormData((prev) => ({
      ...prev,
      skills: prev.skills.filter((s) => s !== skill),
    }))
  }

  const addLanguage = () => {
    if (languageInput.trim() && !formData.languages.includes(languageInput.trim())) {
      setFormData((prev) => ({
        ...prev,
        languages: [...prev.languages, languageInput.trim()],
      }))
      setLanguageInput("")
    }
  }

  const removeLanguage = (language: string) => {
    setFormData((prev) => ({
      ...prev,
      languages: prev.languages.filter((l) => l !== language),
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setSuccess(false)

    try {
      const supabase = createClientSupabaseClient()

      // Actualizar perfil
      const { error: profileError } = await supabase
        .from("profiles")
        .update({
          name: formData.name,
          username: formData.username,
          email: formData.email,
          title: formData.title,
          bio: formData.bio,
          location: formData.location,
          website: formData.website,
          avatar_url: formData.avatar_url,
          is_freelancer: formData.is_freelancer,
          is_admin: formData.is_admin,
          hourly_rate: formData.hourly_rate,
          updated_at: new Date().toISOString(),
        })
        .eq("id", user.id)

      if (profileError) throw profileError

      // Actualizar habilidades
      await supabase.from("skills").delete().eq("profile_id", user.id)

      if (formData.skills.length > 0) {
        const { error: skillsError } = await supabase.from("skills").insert(
          formData.skills.map((skill) => ({
            profile_id: user.id,
            skill,
          })),
        )

        if (skillsError) throw skillsError
      }

      // Actualizar idiomas
      await supabase.from("languages").delete().eq("profile_id", user.id)

      if (formData.languages.length > 0) {
        const { error: languagesError } = await supabase.from("languages").insert(
          formData.languages.map((language) => ({
            profile_id: user.id,
            language,
          })),
        )

        if (languagesError) throw languagesError
      }

      setSuccess(true)
      router.refresh()

      // Redirigir después de 2 segundos
      setTimeout(() => {
        router.push(`/admin/usuarios/${user.id}`)
      }, 2000)
    } catch (err) {
      console.error("Error al actualizar usuario:", err)
      setError("Error al actualizar el usuario. Por favor, inténtalo de nuevo.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="grid grid-cols-3 w-full max-w-md">
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="profile">Perfil</TabsTrigger>
          <TabsTrigger value="settings">Configuración</TabsTrigger>
        </TabsList>

        {/* Información general */}
        <TabsContent value="general">
          <Card>
            <CardContent className="pt-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Nombre completo</Label>
                  <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="username">Nombre de usuario</Label>
                  <Input id="username" name="username" value={formData.username} onChange={handleChange} />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Correo electrónico</Label>
                <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="avatar_url">URL de avatar</Label>
                <Input
                  id="avatar_url"
                  name="avatar_url"
                  value={formData.avatar_url}
                  onChange={handleChange}
                  placeholder="https://ejemplo.com/avatar.jpg"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Ubicación</Label>
                <Input
                  id="location"
                  name="location"
                  value={formData.location}
                  onChange={handleChange}
                  placeholder="Ciudad, País"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Información de perfil */}
        <TabsContent value="profile">
          <Card>
            <CardContent className="pt-6 space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Título profesional</Label>
                <Input
                  id="title"
                  name="title"
                  value={formData.title}
                  onChange={handleChange}
                  placeholder="Ej: Desarrollador Web Senior"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="bio">Biografía</Label>
                <Textarea
                  id="bio"
                  name="bio"
                  value={formData.bio}
                  onChange={handleChange}
                  rows={4}
                  placeholder="Cuéntanos sobre ti..."
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="website">Sitio web</Label>
                <Input
                  id="website"
                  name="website"
                  value={formData.website}
                  onChange={handleChange}
                  placeholder="https://tuwebsite.com"
                />
              </div>

              {formData.is_freelancer && (
                <div className="space-y-2">
                  <Label htmlFor="hourly_rate">Tarifa por hora (€)</Label>
                  <Input
                    id="hourly_rate"
                    name="hourly_rate"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.hourly_rate}
                    onChange={handleChange}
                  />
                </div>
              )}

              {/* Habilidades */}
              <div className="space-y-2">
                <Label>Habilidades</Label>
                <div className="flex gap-2">
                  <Input
                    value={skillInput}
                    onChange={(e) => setSkillInput(e.target.value)}
                    placeholder="Añadir habilidad"
                    onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addSkill())}
                  />
                  <Button type="button" onClick={addSkill}>
                    Añadir
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2 mt-2">
                  {formData.skills.map((skill, index) => (
                    <div
                      key={index}
                      className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full flex items-center"
                    >
                      {skill}
                      <button
                        type="button"
                        className="ml-1 text-blue-800 hover:text-blue-900"
                        onClick={() => removeSkill(skill)}
                      >
                        &times;
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Idiomas */}
              <div className="space-y-2">
                <Label>Idiomas</Label>
                <div className="flex gap-2">
                  <Input
                    value={languageInput}
                    onChange={(e) => setLanguageInput(e.target.value)}
                    placeholder="Añadir idioma"
                    onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addLanguage())}
                  />
                  <Button type="button" onClick={addLanguage}>
                    Añadir
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2 mt-2">
                  {formData.languages.map((language, index) => (
                    <div
                      key={index}
                      className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full flex items-center"
                    >
                      {language}
                      <button
                        type="button"
                        className="ml-1 text-green-800 hover:text-green-900"
                        onClick={() => removeLanguage(language)}
                      >
                        &times;
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Configuración */}
        <TabsContent value="settings">
          <Card>
            <CardContent className="pt-6 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="is_freelancer" className="text-base">
                    Freelancer
                  </Label>
                  <p className="text-sm text-gray-500">Permite al usuario ofrecer servicios como freelancer</p>
                </div>
                <Switch
                  id="is_freelancer"
                  checked={formData.is_freelancer}
                  onCheckedChange={(checked) => handleSwitchChange("is_freelancer", checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="is_admin" className="text-base">
                    Administrador
                  </Label>
                  <p className="text-sm text-gray-500">Otorga acceso completo al panel de administración</p>
                </div>
                <Switch
                  id="is_admin"
                  checked={formData.is_admin}
                  onCheckedChange={(checked) => handleSwitchChange("is_admin", checked)}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {error && (
        <Alert variant="destructive" className="mt-6">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription className="ml-2">{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert className="mt-6 bg-green-50 text-green-800 border-green-200">
          <Check className="h-4 w-4" />
          <AlertDescription className="ml-2">Usuario actualizado correctamente. Redirigiendo...</AlertDescription>
        </Alert>
      )}

      <div className="mt-6 flex justify-end">
        <Button type="button" variant="outline" className="mr-2" onClick={() => router.back()} disabled={loading}>
          Cancelar
        </Button>
        <Button type="submit" className="bg-blue-600 hover:bg-blue-700" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Guardando...
            </>
          ) : (
            "Guardar cambios"
          )}
        </Button>
      </div>
    </form>
  )
}
