"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { createClientSupabaseClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Checkbox } from "@/components/ui/checkbox"
import { Loader2, AlertCircle, Info, Eye, EyeOff } from "lucide-react"

export function AuthForm() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const redirectTo = searchParams.get("redirect") || "/dashboard"
  const defaultTab = searchParams.get("tab") || "login"

  const [activeTab, setActiveTab] = useState(defaultTab)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [name, setName] = useState("")
  const [isFreelancer, setIsFreelancer] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [resendingEmail, setResendingEmail] = useState(false)
  const [emailNotConfirmed, setEmailNotConfirmed] = useState(false)
  const [emailForResend, setEmailForResend] = useState("")
  const [userExists, setUserExists] = useState(false)
  const [invalidCredentials, setInvalidCredentials] = useState(false)
  const [loginAttempts, setLoginAttempts] = useState(0)
  const [showPassword, setShowPassword] = useState(false)
  const [debugInfo, setDebugInfo] = useState<any>(null)

  // Limpiar estados al cambiar de pestaña
  useEffect(() => {
    setError(null)
    setSuccess(null)
    setEmailNotConfirmed(false)
    setUserExists(false)
    setInvalidCredentials(false)
    setDebugInfo(null)
  }, [activeTab])

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setSuccess(null)
    setEmailNotConfirmed(false)
    setUserExists(false)
    setInvalidCredentials(false)
    setDebugInfo(null)

    try {
      // Usar el endpoint de API para el registro
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email,
          password,
          name,
          isFreelancer,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        // Verificar si es un error de usuario existente
        if (data.code === "user_exists") {
          setUserExists(true)
          throw new Error(data.error || "Ya existe una cuenta con este correo electrónico")
        }
        throw new Error(data.error || "Error al registrar usuario")
      }

      setSuccess("Registro exitoso. Ya puedes iniciar sesión con tus credenciales.")

      // Limpiar el formulario
      setName("")
      setEmail("")
      setPassword("")
      setIsFreelancer(false)

      // Cambiar a la pestaña de inicio de sesión después de 2 segundos
      setTimeout(() => {
        setActiveTab("login")
      }, 2000)
    } catch (error) {
      console.error("Error al registrar:", error)
      setError(error instanceof Error ? error.message : "Error al registrar usuario")
    } finally {
      setLoading(false)
    }
  }

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setEmailNotConfirmed(false)
    setInvalidCredentials(false)
    setDebugInfo(null)

    try {
      // Incrementar el contador de intentos
      setLoginAttempts((prev) => prev + 1)

      // Usar el endpoint de API para el inicio de sesión
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email,
          password,
        }),
      })

      const data = await response.json()

      // Guardar información de depuración
      setDebugInfo({
        status: response.status,
        responseData: data,
        timestamp: new Date().toISOString(),
      })

      if (!response.ok) {
        // Manejar diferentes tipos de errores
        if (data.code === "user_not_found") {
          throw new Error("No existe una cuenta con este correo electrónico. Por favor, regístrate primero.")
        } else if (data.code === "invalid_credentials") {
          setInvalidCredentials(true)
          throw new Error("La contraseña es incorrecta. Por favor, verifica tus credenciales.")
        } else if (data.code === "email_not_confirmed") {
          setEmailNotConfirmed(true)
          setEmailForResend(email)
          throw new Error(
            "Tu correo electrónico no ha sido confirmado. Por favor, verifica tu bandeja de entrada o reenvía el correo de confirmación.",
          )
        } else {
          throw new Error(data.error || "Error al iniciar sesión")
        }
      }

      // Inicio de sesión exitoso, redirigir
      console.log("Inicio de sesión exitoso, redirigiendo a:", redirectTo)
      router.push(redirectTo)
    } catch (error) {
      console.error("Error al iniciar sesión:", error)
      setError(error instanceof Error ? error.message : "Error al iniciar sesión")
    } finally {
      setLoading(false)
    }
  }

  const handleResendConfirmationEmail = async () => {
    if (!emailForResend) return

    setResendingEmail(true)
    try {
      const supabase = createClientSupabaseClient()
      const { error } = await supabase.auth.resend({
        type: "signup",
        email: emailForResend,
      })

      if (error) throw error

      setSuccess("Correo de confirmación reenviado. Por favor, revisa tu bandeja de entrada.")
      setEmailNotConfirmed(false)
    } catch (error) {
      console.error("Error al reenviar correo:", error)
      setError(error instanceof Error ? error.message : "Error al reenviar correo de confirmación")
    } finally {
      setResendingEmail(false)
    }
  }

  const handleForgotPassword = async () => {
    if (!email) {
      setError("Por favor, ingresa tu correo electrónico para recuperar tu contraseña")
      return
    }

    setLoading(true)
    try {
      const supabase = createClientSupabaseClient()

      // Simplificamos la recuperación de contraseña eliminando opciones adicionales
      const { error } = await supabase.auth.resetPasswordForEmail(email)

      if (error) throw error

      setSuccess("Se ha enviado un correo para restablecer tu contraseña. Por favor, revisa tu bandeja de entrada.")
    } catch (error) {
      console.error("Error al solicitar restablecimiento de contraseña:", error)
      setError(error instanceof Error ? error.message : "Error al solicitar restablecimiento de contraseña")
    } finally {
      setLoading(false)
    }
  }

  const handleCreateTestUser = async () => {
    setLoading(true)
    setError(null)
    setSuccess(null)

    try {
      const testEmail = `test${Math.floor(Math.random() * 10000)}@example.com`
      const testPassword = "password123"

      const response = await fetch("/api/auth/create-test-user", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: testEmail,
          password: testPassword,
          name: "Usuario de Prueba",
          isFreelancer: true,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Error al crear usuario de prueba")
      }

      // Establecer las credenciales en los campos
      setEmail(testEmail)
      setPassword(testPassword)

      setSuccess(`Usuario de prueba creado: ${testEmail} / ${testPassword}`)
    } catch (error) {
      console.error("Error al crear usuario de prueba:", error)
      setError(error instanceof Error ? error.message : "Error al crear usuario de prueba")
    } finally {
      setLoading(false)
    }
  }

  const switchToLogin = () => {
    setActiveTab("login")
  }

  const switchToRegister = () => {
    setActiveTab("register")
  }

  const toggleShowPassword = () => {
    setShowPassword(!showPassword)
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="login" data-value="login">
            Iniciar Sesión
          </TabsTrigger>
          <TabsTrigger value="register" data-value="register">
            Registrarse
          </TabsTrigger>
        </TabsList>

        {/* Iniciar Sesión */}
        <TabsContent value="login">
          <form onSubmit={handleSignIn}>
            <CardHeader>
              <CardTitle>Iniciar Sesión</CardTitle>
              <CardDescription>Ingresa tus credenciales para acceder a tu cuenta</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Correo electrónico</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="tu@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value.trim())}
                  required
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Contraseña</Label>
                  <Button type="button" variant="link" className="p-0 h-auto text-sm" onClick={handleForgotPassword}>
                    ¿Olvidaste tu contraseña?
                  </Button>
                </div>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3"
                    onClick={toggleShowPassword}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="ml-2">{error}</AlertDescription>
                </Alert>
              )}
              {success && (
                <Alert className="bg-blue-50 text-blue-800 border-blue-200">
                  <Info className="h-4 w-4" />
                  <AlertDescription className="ml-2">{success}</AlertDescription>
                </Alert>
              )}
              {invalidCredentials && (
                <div className="mt-2">
                  <Alert className="bg-amber-50 text-amber-800 border-amber-200">
                    <Info className="h-4 w-4" />
                    <AlertDescription className="ml-2">
                      <p>Consejos para iniciar sesión:</p>
                      <ul className="list-disc pl-5 mt-1 text-sm">
                        <li>Verifica que estás usando el mismo correo con el que te registraste</li>
                        <li>La contraseña distingue entre mayúsculas y minúsculas</li>
                        <li>Asegúrate de no tener espacios al inicio o final</li>
                      </ul>
                      <div className="mt-2">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          className="mr-2"
                          onClick={handleForgotPassword}
                        >
                          Recuperar contraseña
                        </Button>
                        <Button type="button" variant="outline" size="sm" onClick={switchToRegister}>
                          Crear nueva cuenta
                        </Button>
                      </div>
                    </AlertDescription>
                  </Alert>
                </div>
              )}
              {emailNotConfirmed && (
                <div className="mt-2">
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    onClick={handleResendConfirmationEmail}
                    disabled={resendingEmail}
                  >
                    {resendingEmail ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Reenviando...
                      </>
                    ) : (
                      "Reenviar correo de confirmación"
                    )}
                  </Button>
                </div>
              )}
              {debugInfo && (
                <div className="mt-2 p-2 bg-gray-100 rounded text-xs font-mono overflow-auto">
                  <p>Información de depuración:</p>
                  <pre>{JSON.stringify(debugInfo, null, 2)}</pre>
                </div>
              )}

              {/* Botón para crear usuario de prueba */}
              <div className="mt-4 pt-4 border-t border-gray-200">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="w-full"
                  onClick={handleCreateTestUser}
                  disabled={loading}
                >
                  Crear usuario de prueba
                </Button>
                <p className="text-xs text-gray-500 mt-1 text-center">Esto creará un usuario aleatorio para pruebas</p>
              </div>
            </CardContent>
            <CardFooter>
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Iniciando sesión...
                  </>
                ) : (
                  "Iniciar Sesión"
                )}
              </Button>
            </CardFooter>
          </form>
        </TabsContent>

        {/* Registrarse */}
        <TabsContent value="register">
          <form onSubmit={handleSignUp}>
            <CardHeader>
              <CardTitle>Crear Cuenta</CardTitle>
              <CardDescription>Regístrate para comenzar a usar Frilanet</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nombre completo</Label>
                <Input
                  id="name"
                  placeholder="Tu nombre"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="register-email">Correo electrónico</Label>
                <Input
                  id="register-email"
                  type="email"
                  placeholder="tu@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value.trim())}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="register-password">Contraseña</Label>
                <div className="relative">
                  <Input
                    id="register-password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3"
                    onClick={toggleShowPassword}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
                <p className="text-xs text-gray-500">La contraseña debe tener al menos 6 caracteres</p>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="is-freelancer"
                  checked={isFreelancer}
                  onCheckedChange={(checked) => setIsFreelancer(checked === true)}
                />
                <Label htmlFor="is-freelancer">Quiero ofrecer mis servicios como freelancer</Label>
              </div>
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="ml-2">
                    {error}
                    {userExists && (
                      <div className="mt-2 flex flex-col space-y-2">
                        <p className="text-sm">¿Ya tienes una cuenta? Puedes:</p>
                        <div className="flex space-x-2">
                          <Button type="button" variant="outline" size="sm" className="flex-1" onClick={switchToLogin}>
                            Iniciar sesión
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            className="flex-1"
                            onClick={handleForgotPassword}
                          >
                            Recuperar contraseña
                          </Button>
                        </div>
                      </div>
                    )}
                  </AlertDescription>
                </Alert>
              )}
              {success && (
                <Alert className="bg-blue-50 text-blue-800 border-blue-200">
                  <Info className="h-4 w-4" />
                  <AlertDescription className="ml-2">{success}</AlertDescription>
                </Alert>
              )}
            </CardContent>
            <CardFooter>
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creando cuenta...
                  </>
                ) : (
                  "Crear Cuenta"
                )}
              </Button>
            </CardFooter>
          </form>
        </TabsContent>
      </Tabs>
    </Card>
  )
}
