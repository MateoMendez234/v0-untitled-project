"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"
import { useSession, signOut } from "next-auth/react"
import { useRouter } from "next/navigation"
import type { ProfileWithDetails } from "@/lib/services/profile-service"

type AuthContextType = {
  user: {
    id: string
    email: string
    name: string
    isFreelancer: boolean
    isAdmin: boolean
  } | null
  profile: ProfileWithDetails | null
  loading: boolean
  signOut: () => Promise<void>
  refreshProfile: () => Promise<void>
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  profile: null,
  loading: true,
  signOut: async () => {},
  refreshProfile: async () => {},
})

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [profile, setProfile] = useState<ProfileWithDetails | null>(null)
  const [loading, setLoading] = useState(true)

  const refreshProfile = async () => {
    try {
      if (!session?.user?.id) return

      const response = await fetch(`/api/profiles/${session.user.id}`)
      if (response.ok) {
        const profileData = await response.json()
        setProfile(profileData)
      } else {
        console.warn("No profile found for user:", session.user.id)
        setProfile(null)
      }
    } catch (error) {
      console.error("Error in refreshProfile:", error)
    }
  }

  useEffect(() => {
    const initializeAuth = async () => {
      try {
        setLoading(true)

        if (status === "authenticated" && session?.user) {
          await refreshProfile()
        } else if (status === "unauthenticated") {
          setProfile(null)
        }

        setLoading(false)
      } catch (error) {
        console.error("Error initializing auth:", error)
        setLoading(false)
      }
    }

    initializeAuth()
  }, [status, session])

  const handleSignOut = async () => {
    try {
      await signOut({ redirect: false })
      setProfile(null)
      router.push("/auth/login")
    } catch (error) {
      console.error("Error signing out:", error)
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user: session?.user
          ? {
              id: session.user.id,
              email: session.user.email || "",
              name: session.user.name || "",
              isFreelancer: session.user.isFreelancer || false,
              isAdmin: session.user.isAdmin || false,
            }
          : null,
        profile,
        loading,
        signOut: handleSignOut,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
