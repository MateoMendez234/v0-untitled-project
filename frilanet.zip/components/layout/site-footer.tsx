import Link from "next/link"

export function SiteFooter() {
  return (
    <footer className="w-full border-t bg-background py-6">
      <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
        <div className="flex flex-col items-center gap-4 md:flex-row md:gap-6">
          <Link href="/" className="flex items-center gap-2 font-bold text-xl text-blue-600">
            Frilanet
          </Link>
          <nav className="flex gap-4 md:gap-6">
            <Link href="/terminos" className="text-sm font-medium hover:text-blue-600 transition-colors">
              Términos de Servicio
            </Link>
            <Link href="/privacidad" className="text-sm font-medium hover:text-blue-600 transition-colors">
              Política de Privacidad
            </Link>
            <Link href="/contacto" className="text-sm font-medium hover:text-blue-600 transition-colors">
              Contacto
            </Link>
          </nav>
        </div>
        <p className="text-sm text-muted-foreground">© 2025 Frilanet. Todos los derechos reservados.</p>
      </div>
    </footer>
  )
}
