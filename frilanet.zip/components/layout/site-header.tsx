import Link from "next/link"
import { UserMenu } from "@/components/auth/user-menu"
import { MobileNav } from "@/components/mobile/mobile-nav"
import { Globe } from "lucide-react"

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <MobileNav />
          <Link href="/" className="flex items-center gap-2 font-bold text-xl text-blue-600">
            <Globe className="h-6 w-6" />
            <span>Frilanet</span>
          </Link>
        </div>

        <nav className="hidden md:flex gap-6">
          <Link href="/" className="text-sm font-medium hover:text-blue-600 transition-colors">
            Inicio
          </Link>
          <Link href="/explorar" className="text-sm font-medium hover:text-blue-600 transition-colors">
            Explorar
          </Link>
          <Link href="/categorias" className="text-sm font-medium hover:text-blue-600 transition-colors">
            Categorías
          </Link>
          <Link href="/como-funciona" className="text-sm font-medium hover:text-blue-600 transition-colors">
            Cómo funciona
          </Link>
        </nav>

        <UserMenu />
      </div>
    </header>
  )
}
