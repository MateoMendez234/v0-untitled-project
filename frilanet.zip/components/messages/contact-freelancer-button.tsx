"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { MessageSquare, Loader2 } from "lucide-react"

interface ContactFreelancerButtonProps {
  freelancerId: string
  freelancerName: string
  currentUserId?: string
  serviceId?: string
  serviceTitle?: string
}

export function ContactFreelancerButton({
  freelancerId,
  freelancerName,
  currentUserId,
  serviceId,
  serviceTitle,
}: ContactFreelancerButtonProps) {
  const [open, setOpen] = useState(false)
  const [subject, setSubject] = useState(serviceTitle ? `Consulta sobre: ${serviceTitle}` : "")
  const [message, setMessage] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const { toast } = useToast()

  const handleContact = () => {
    if (!currentUserId) {
      router.push("/auth/login?redirect=back")
      return
    }
    setOpen(true)
  }

  const handleSendMessage = async () => {
    if (!currentUserId) return
    if (!message.trim()) {
      toast({
        title: "Error",
        description: "El mensaje no puede estar vacío",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)

    try {
      // Crear conversación
      const conversationResponse = await fetch("/api/conversations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          freelancerId,
          subject,
          serviceId,
        }),
      })

      if (!conversationResponse.ok) {
        throw new Error("Error al crear la conversación")
      }

      const conversationData = await conversationResponse.json()
      const conversationId = conversationData.conversationId

      // Enviar mensaje
      const messageResponse = await fetch(`/api/conversations/${conversationId}/messages`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          content: message,
        }),
      })

      if (!messageResponse.ok) {
        throw new Error("Error al enviar el mensaje")
      }

      toast({
        title: "Mensaje enviado",
        description: `Tu mensaje ha sido enviado a ${freelancerName}`,
      })

      setOpen(false)
      router.push(`/dashboard/mensajes/${conversationId}`)
    } catch (error) {
      console.error("Error al enviar mensaje:", error)
      toast({
        title: "Error",
        description: "No se pudo enviar el mensaje. Inténtalo de nuevo más tarde.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <>
      <Button onClick={handleContact} className="w-full bg-blue-600 hover:bg-blue-700">
        <MessageSquare className="mr-2 h-4 w-4" />
        Contactar
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Enviar mensaje a {freelancerName}</DialogTitle>
            <DialogDescription>Escribe tu mensaje para iniciar una conversación con este freelancer.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="subject">Asunto</Label>
              <Input
                id="subject"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                placeholder="Escribe un asunto para la conversación"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="message">Mensaje</Label>
              <Textarea
                id="message"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Escribe tu mensaje aquí..."
                rows={5}
                required
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setOpen(false)} disabled={isLoading}>
              Cancelar
            </Button>
            <Button
              type="button"
              onClick={handleSendMessage}
              disabled={isLoading}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Enviando...
                </>
              ) : (
                "Enviar mensaje"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
