import Link from "next/link"
import Image from "next/image"
import { CardHeader, CardTitle } from "@/components/ui/card"

interface ConversationHeaderProps {
  participant: {
    id: string
    name: string | null
    username: string | null
    avatar_url: string | null
  }
  subject: string | null
  service: {
    id: string
    title: string
  } | null
}

export function ConversationHeader({ participant, subject, service }: ConversationHeaderProps) {
  return (
    <CardHeader className="border-b p-4 bg-gray-50">
      <div className="flex items-center gap-4">
        <div className="relative h-10 w-10 rounded-full overflow-hidden">
          <Image
            src={participant.avatar_url || "/placeholder.svg?height=40&width=40"}
            alt={participant.name || ""}
            className="object-cover"
            fill
          />
        </div>
        <div className="flex-1">
          <CardTitle className="text-base flex items-center gap-2">
            <Link href={`/freelancers/${participant.username}`} className="hover:text-emerald-600 transition-colors">
              {participant.name || "Usuario"}
            </Link>
          </CardTitle>

          {subject && <p className="text-sm text-gray-600 font-medium">{subject}</p>}

          {service && (
            <Link
              href={`/freelancers/${participant.username}/servicios/${service.id}`}
              className="text-xs text-emerald-600 hover:underline"
            >
              {service.title}
            </Link>
          )}
        </div>
      </div>
    </CardHeader>
  )
}
