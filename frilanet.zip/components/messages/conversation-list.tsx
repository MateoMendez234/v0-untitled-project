import Link from "next/link"
import Image from "next/image"
import { formatDistanceToNow } from "date-fns"
import { es } from "date-fns/locale"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { getUserConversations } from "@/lib/messages"
import { createServerSupabaseClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"

export async function ConversationList() {
  const supabase = createServerSupabaseClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth")
  }

  const conversations = await getUserConversations(user.id)

  if (conversations.length === 0) {
    return (
      <div className="p-8 text-center">
        <p className="text-gray-500 mb-4">No tienes conversaciones activas.</p>
        <p className="text-gray-500">Explora servicios y contacta con freelancers para iniciar una conversación.</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {conversations.map((conversation) => (
        <Link href={`/dashboard/mensajes/${conversation.id}`} key={conversation.id}>
          <Card
            className={`hover:shadow-md transition-shadow ${conversation.unread_count > 0 ? "border-l-4 border-l-emerald-500" : ""}`}
          >
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                <div className="relative h-12 w-12 rounded-full overflow-hidden">
                  <Image
                    src={conversation.participant.avatar_url || "/placeholder.svg?height=50&width=50"}
                    alt={conversation.participant.name || ""}
                    className="object-cover"
                    fill
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-center mb-1">
                    <h3 className="font-medium truncate">{conversation.participant.name || "Usuario"}</h3>
                    <span className="text-xs text-gray-500">
                      {formatDistanceToNow(new Date(conversation.last_message_at), {
                        addSuffix: true,
                        locale: es,
                      })}
                    </span>
                  </div>
                  {conversation.subject && (
                    <p className="text-sm text-gray-600 font-medium truncate mb-1">{conversation.subject}</p>
                  )}
                  <p className="text-sm text-gray-500 truncate">
                    {conversation.last_message?.message || "No hay mensajes"}
                  </p>
                </div>
                {conversation.unread_count > 0 && (
                  <Badge className="bg-emerald-500 hover:bg-emerald-600">{conversation.unread_count}</Badge>
                )}
              </div>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  )
}
