"use client"

import { useEffect, useRef } from "react"
import Image from "next/image"
import { format } from "date-fns"
import { es } from "date-fns/locale"
import { type Message, markMessagesAsRead } from "@/lib/messages"

interface ConversationMessagesProps {
  conversationId: string
  messages: Message[]
  currentUserId: string
}

export function ConversationMessages({ conversationId, messages, currentUserId }: ConversationMessagesProps) {
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Desplazar al final cuando se cargan los mensajes o llegan nuevos
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Marcar mensajes como leídos cuando se carga la conversación
  useEffect(() => {
    markMessagesAsRead(conversationId, currentUserId).catch(console.error)
  }, [conversationId, currentUserId])

  if (messages.length === 0) {
    return (
      <div className="p-8 text-center flex-1 flex items-center justify-center">
        <p className="text-gray-500">No hay mensajes en esta conversación.</p>
      </div>
    )
  }

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-4">
      {messages.map((message) => {
        const isCurrentUser = message.sender_id === currentUserId

        return (
          <div key={message.id} className={`flex ${isCurrentUser ? "justify-end" : "justify-start"}`}>
            <div className={`flex gap-3 max-w-[80%] ${isCurrentUser ? "flex-row-reverse" : ""}`}>
              <div className="flex-shrink-0">
                <div className="relative h-8 w-8 rounded-full overflow-hidden">
                  <Image
                    src={message.sender?.avatar_url || "/placeholder.svg?height=32&width=32"}
                    alt={message.sender?.name || ""}
                    className="object-cover"
                    fill
                  />
                </div>
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs text-gray-500">
                    {format(new Date(message.created_at), "d MMM, HH:mm", { locale: es })}
                  </span>
                  <span className="font-medium text-sm">{message.sender?.name || "Usuario"}</span>
                </div>
                <div
                  className={`rounded-lg p-3 ${
                    isCurrentUser ? "bg-emerald-100 text-emerald-900" : "bg-gray-100 text-gray-900"
                  }`}
                >
                  <p className="whitespace-pre-line">{message.message}</p>
                </div>
              </div>
            </div>
          </div>
        )
      })}
      <div ref={messagesEndRef} />
    </div>
  )
}
