"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Loader2, Send } from "lucide-react"
import { sendMessage } from "@/lib/messages"

interface MessageInputProps {
  conversationId: string
  senderId: string
}

export function MessageInput({ conversationId, senderId }: MessageInputProps) {
  const [message, setMessage] = useState("")
  const [sending, setSending] = useState(false)

  const handleSendMessage = async () => {
    if (!message.trim() || sending) return

    setSending(true)

    try {
      await sendMessage(conversationId, senderId, message)
      setMessage("")
    } catch (error) {
      console.error("Error enviando mensaje:", error)
      alert("No se pudo enviar el mensaje. Intenta de nuevo.")
    } finally {
      setSending(false)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  return (
    <div className="border-t p-4 flex gap-2 bg-white">
      <Textarea
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        onKeyDown={handleKeyDown}
        placeholder="Escribe un mensaje..."
        className="resize-none"
        rows={2}
        disabled={sending}
      />
      <Button
        onClick={handleSendMessage}
        disabled={!message.trim() || sending}
        className="bg-emerald-600 hover:bg-emerald-700"
      >
        {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
        <span className="sr-only">Enviar</span>
      </Button>
    </div>
  )
}
