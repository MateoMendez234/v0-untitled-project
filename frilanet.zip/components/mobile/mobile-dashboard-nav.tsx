"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useAuth } from "@/components/auth/auth-provider"
import { BarChart, FileText, Globe, Home, Menu, MessageSquare, Package, Settings, User, X } from "lucide-react"

export function MobileDashboardNav() {
  const { user } = useAuth()
  const pathname = usePathname()
  const [isOpen, setIsOpen] = useState(false)

  const closeMenu = () => setIsOpen(false)

  const isActive = (path: string) => {
    return pathname === path || pathname.startsWith(`${path}/`)
  }

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden">
          <Menu className="h-6 w-6" />
          <span className="sr-only">Abrir menú</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-[300px] sm:w-[400px]">
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between py-4 border-b">
            <Link href="/" className="flex items-center gap-2 font-bold text-xl text-emerald-600" onClick={closeMenu}>
              <Globe className="h-6 w-6" />
              <span>Frilanet</span>
            </Link>
            <Button variant="ghost" size="icon" onClick={closeMenu}>
              <X className="h-6 w-6" />
              <span className="sr-only">Cerrar menú</span>
            </Button>
          </div>

          <nav className="flex flex-col gap-1 py-6">
            <Link
              href="/dashboard"
              className={`flex items-center gap-3 px-4 py-3 text-base rounded-md transition-colors ${
                isActive("/dashboard") && !isActive("/dashboard/mensajes") && !isActive("/dashboard/pedidos")
                  ? "bg-emerald-50 text-emerald-600 font-medium"
                  : "hover:bg-gray-100"
              }`}
              onClick={closeMenu}
            >
              <Home className="h-5 w-5" />
              Dashboard
            </Link>

            <Link
              href="/dashboard/mensajes"
              className={`flex items-center gap-3 px-4 py-3 text-base rounded-md transition-colors ${
                isActive("/dashboard/mensajes") ? "bg-emerald-50 text-emerald-600 font-medium" : "hover:bg-gray-100"
              }`}
              onClick={closeMenu}
            >
              <MessageSquare className="h-5 w-5" />
              Mensajes
            </Link>

            <Link
              href="/dashboard/pedidos"
              className={`flex items-center gap-3 px-4 py-3 text-base rounded-md transition-colors ${
                isActive("/dashboard/pedidos") ? "bg-emerald-50 text-emerald-600 font-medium" : "hover:bg-gray-100"
              }`}
              onClick={closeMenu}
            >
              <Package className="h-5 w-5" />
              Pedidos
            </Link>

            {user?.is_freelancer && (
              <>
                <Link
                  href="/dashboard/servicios"
                  className={`flex items-center gap-3 px-4 py-3 text-base rounded-md transition-colors ${
                    isActive("/dashboard/servicios")
                      ? "bg-emerald-50 text-emerald-600 font-medium"
                      : "hover:bg-gray-100"
                  }`}
                  onClick={closeMenu}
                >
                  <FileText className="h-5 w-5" />
                  Mis servicios
                </Link>

                <Link
                  href="/dashboard/estadisticas"
                  className={`flex items-center gap-3 px-4 py-3 text-base rounded-md transition-colors ${
                    isActive("/dashboard/estadisticas")
                      ? "bg-emerald-50 text-emerald-600 font-medium"
                      : "hover:bg-gray-100"
                  }`}
                  onClick={closeMenu}
                >
                  <BarChart className="h-5 w-5" />
                  Estadísticas
                </Link>
              </>
            )}

            <Link
              href="/dashboard/perfil"
              className={`flex items-center gap-3 px-4 py-3 text-base rounded-md transition-colors ${
                isActive("/dashboard/perfil") ? "bg-emerald-50 text-emerald-600 font-medium" : "hover:bg-gray-100"
              }`}
              onClick={closeMenu}
            >
              <User className="h-5 w-5" />
              Mi perfil
            </Link>

            <Link
              href="/dashboard/ajustes"
              className={`flex items-center gap-3 px-4 py-3 text-base rounded-md transition-colors ${
                isActive("/dashboard/ajustes") ? "bg-emerald-50 text-emerald-600 font-medium" : "hover:bg-gray-100"
              }`}
              onClick={closeMenu}
            >
              <Settings className="h-5 w-5" />
              Ajustes
            </Link>
          </nav>

          <div className="mt-auto border-t py-6">
            <div className="px-4">
              <Button className="w-full" variant="outline" asChild>
                <Link href="/" onClick={closeMenu}>
                  Volver al inicio
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  )
}
