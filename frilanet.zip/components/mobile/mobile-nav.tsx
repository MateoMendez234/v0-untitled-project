"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useAuth } from "@/components/auth/auth-provider"
import { Globe, Menu, X } from "lucide-react"

export function MobileNav() {
  const { user, isLoading } = useAuth()
  const [isOpen, setIsOpen] = useState(false)

  const closeMenu = () => setIsOpen(false)

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden">
          <Menu className="h-6 w-6" />
          <span className="sr-only">Abrir menú</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-[300px] sm:w-[400px]">
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between py-4 border-b">
            <Link href="/" className="flex items-center gap-2 font-bold text-xl text-emerald-600" onClick={closeMenu}>
              <Globe className="h-6 w-6" />
              <span>Frilanet</span>
            </Link>
            <Button variant="ghost" size="icon" onClick={closeMenu}>
              <X className="h-6 w-6" />
              <span className="sr-only">Cerrar menú</span>
            </Button>
          </div>

          <nav className="flex flex-col gap-4 py-6">
            <Link
              href="/"
              className="px-4 py-2 text-lg hover:bg-gray-100 rounded-md transition-colors"
              onClick={closeMenu}
            >
              Inicio
            </Link>
            <Link
              href="/explorar"
              className="px-4 py-2 text-lg hover:bg-gray-100 rounded-md transition-colors"
              onClick={closeMenu}
            >
              Explorar
            </Link>
            <Link
              href="/categorias"
              className="px-4 py-2 text-lg hover:bg-gray-100 rounded-md transition-colors"
              onClick={closeMenu}
            >
              Categorías
            </Link>
            <Link
              href="/como-funciona"
              className="px-4 py-2 text-lg hover:bg-gray-100 rounded-md transition-colors"
              onClick={closeMenu}
            >
              Cómo funciona
            </Link>
          </nav>

          <div className="mt-auto border-t py-6">
            {!isLoading && (
              <div className="space-y-4 px-4">
                {user ? (
                  <>
                    <Button className="w-full bg-emerald-600 hover:bg-emerald-700" asChild>
                      <Link href="/dashboard" onClick={closeMenu}>
                        Mi Dashboard
                      </Link>
                    </Button>
                    <Button variant="outline" className="w-full" asChild>
                      <Link href="/dashboard/mensajes" onClick={closeMenu}>
                        Mensajes
                      </Link>
                    </Button>
                  </>
                ) : (
                  <>
                    <Button className="w-full bg-emerald-600 hover:bg-emerald-700" asChild>
                      <Link href="/auth/register" onClick={closeMenu}>
                        Registrarse
                      </Link>
                    </Button>
                    <Button variant="outline" className="w-full" asChild>
                      <Link href="/auth/login" onClick={closeMenu}>
                        Iniciar sesión
                      </Link>
                    </Button>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  )
}
