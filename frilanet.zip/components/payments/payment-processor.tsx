"use client"

type PaymentProcessorProps = {}
