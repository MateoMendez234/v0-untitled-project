"use client"

import type React from "react"

import { useState } from "react"
import { Elements, PaymentElement, useStripe, useElements } from "@stripe/react-stripe-js"
import { loadStripe } from "@stripe/stripe-js"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2 } from "lucide-react"

// Inicializar Stripe
const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || "")

interface StripePaymentFormWrapperProps {
  clientSecret: string
  orderId: string
  amount: number
  onSuccess: () => void
}

export function StripePaymentFormWrapper({ clientSecret, orderId, amount, onSuccess }: StripePaymentFormWrapperProps) {
  return (
    <Elements
      stripe={stripePromise}
      options={{
        clientSecret,
        appearance: {
          theme: "stripe",
          variables: {
            colorPrimary: "#10b981",
            colorBackground: "#ffffff",
            colorText: "#1f2937",
          },
        },
      }}
    >
      <StripePaymentForm orderId={orderId} amount={amount} onSuccess={onSuccess} />
    </Elements>
  )
}

interface StripePaymentFormProps {
  orderId: string
  amount: number
  onSuccess: () => void
}

function StripePaymentForm({ orderId, amount, onSuccess }: StripePaymentFormProps) {
  const stripe = useStripe()
  const elements = useElements()
  const [isLoading, setIsLoading] = useState(false)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!stripe || !elements) {
      return
    }

    setIsLoading(true)
    setErrorMessage(null)

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/checkout/confirmacion/${orderId}`,
        },
        redirect: "if_required",
      })

      if (error) {
        setErrorMessage(error.message || "Ocurrió un error al procesar el pago.")
      } else {
        // El pago se ha completado correctamente
        onSuccess()
      }
    } catch (error) {
      setErrorMessage("Ocurrió un error inesperado. Por favor, inténtalo de nuevo.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />

      {errorMessage && (
        <Alert variant="destructive">
          <AlertDescription>{errorMessage}</AlertDescription>
        </Alert>
      )}

      <Button type="submit" disabled={!stripe || isLoading} className="w-full bg-emerald-600 hover:bg-emerald-700">
        {isLoading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Procesando...
          </>
        ) : (
          `Pagar €${amount.toFixed(2)}`
        )}
      </Button>
    </form>
  )
}
