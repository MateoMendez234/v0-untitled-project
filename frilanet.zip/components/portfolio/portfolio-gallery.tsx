"use client"

import { useState } from "react"
import Image from "next/image"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ExternalLink } from "lucide-react"

interface PortfolioItem {
  _id: string
  title: string
  description?: string | null
  imageUrl?: string | null
  category?: string | null
  tags?: string[]
  projectUrl?: string | null
  createdAt?: Date
}

interface PortfolioGalleryProps {
  items: PortfolioItem[]
}

export function PortfolioGallery({ items }: PortfolioGalleryProps) {
  const [selectedItem, setSelectedItem] = useState<PortfolioItem | null>(null)

  return (
    <>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.map((item) => (
          <Card
            key={item._id}
            className="overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => setSelectedItem(item)}
          >
            <div className="relative aspect-video">
              <Image
                src={item.imageUrl || "/placeholder.svg?height=200&width=300"}
                alt={item.title}
                className="object-cover"
                fill
              />
            </div>
            <CardContent className="p-3">
              <h3 className="font-medium text-sm truncate">{item.title}</h3>
              {item.category && (
                <Badge variant="outline" className="mt-2">
                  {item.category}
                </Badge>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={!!selectedItem} onOpenChange={(open) => !open && setSelectedItem(null)}>
        {selectedItem && (
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>{selectedItem.title}</DialogTitle>
              {selectedItem.projectUrl && (
                <DialogDescription>
                  <a
                    href={selectedItem.projectUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:underline flex items-center mt-1"
                  >
                    Ver proyecto <ExternalLink className="h-4 w-4 ml-1" />
                  </a>
                </DialogDescription>
              )}
            </DialogHeader>
            <div className="relative aspect-video w-full">
              <Image
                src={selectedItem.imageUrl || "/placeholder.svg?height=400&width=600"}
                alt={selectedItem.title}
                className="object-contain"
                fill
              />
            </div>
            <div className="mt-4">
              <p className="text-gray-700">{selectedItem.description}</p>
              {selectedItem.tags && selectedItem.tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-4">
                  {selectedItem.tags.map((tag) => (
                    <span key={tag} className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded">
                      {tag}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </DialogContent>
        )}
      </Dialog>
    </>
  )
}
