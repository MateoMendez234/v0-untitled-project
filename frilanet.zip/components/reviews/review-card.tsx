"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { formatDistanceToNow } from "date-fns"
import { es } from "date-fns/locale"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/components/auth/auth-provider"
import { respondToReview, markReviewAsHelpful } from "@/lib/reviews"
import { ThumbsUp, Star } from "lucide-react"

interface ReviewCardProps {
  review: any
  isOwner?: boolean
}

export function ReviewCard({ review, isOwner = false }: ReviewCardProps) {
  const { user } = useAuth()
  const { toast } = useToast()
  const [isResponding, setIsResponding] = useState(false)
  const [response, setResponse] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [helpfulCount, setHelpfulCount] = useState(review.helpful_count || 0)
  const [hasMarkedHelpful, setHasMarkedHelpful] = useState(false)

  const handleRespondClick = () => {
    setIsResponding(true)
  }

  const handleCancelResponse = () => {
    setIsResponding(false)
    setResponse("")
  }

  const handleSubmitResponse = async () => {
    if (!user || !response.trim()) return

    setIsSubmitting(true)

    try {
      const result = await respondToReview(review.id, user.id, response.trim())

      if (result.success) {
        toast({
          title: "Respuesta enviada",
          description: "Tu respuesta ha sido publicada correctamente.",
        })

        // Actualizar la UI sin necesidad de recargar
        review.response = response.trim()
        review.response_date = new Date().toISOString()
        setIsResponding(false)
      } else {
        toast({
          title: "Error",
          description: result.error || "No se pudo enviar tu respuesta. Inténtalo de nuevo.",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Ocurrió un error al enviar tu respuesta.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleMarkHelpful = async () => {
    if (hasMarkedHelpful) return

    try {
      const result = await markReviewAsHelpful(review.id)

      if (result.success) {
        setHelpfulCount(helpfulCount + 1)
        setHasMarkedHelpful(true)
      }
    } catch (error) {
      console.error("Error marking review as helpful:", error)
    }
  }

  return (
    <div className="border-b pb-6 mb-6 last:border-b-0 last:mb-0 last:pb-0">
      <div className="flex justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className="relative w-10 h-10 rounded-full overflow-hidden">
            <Image
              src={review.client?.avatar_url || "/placeholder.svg?height=40&width=40"}
              alt={review.client?.name || "Usuario"}
              className="object-cover"
              fill
            />
          </div>
          <div>
            <div className="font-medium">
              {review.client?.name || "Usuario"}
              {review.client?.username && (
                <Link href={`/perfiles/${review.client.username}`} className="text-emerald-600 hover:underline ml-1">
                  @{review.client.username}
                </Link>
              )}
            </div>
            <div className="text-sm text-gray-600">
              {formatDistanceToNow(new Date(review.created_at), { addSuffix: true, locale: es })}
            </div>
          </div>
        </div>
        <div className="flex items-center">
          {[1, 2, 3, 4, 5].map((star) => (
            <Star
              key={star}
              className={`h-4 w-4 ${star <= review.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
            />
          ))}
        </div>
      </div>

      {review.title && <h4 className="font-medium mb-2">{review.title}</h4>}

      <p className="text-gray-700 mb-4">{review.comment}</p>

      {/* Respuesta del freelancer */}
      {review.response && (
        <div className="bg-gray-50 p-4 rounded-lg mb-4">
          <div className="text-sm text-gray-600 mb-2">
            Respuesta del freelancer •{" "}
            {formatDistanceToNow(new Date(review.response_date), { addSuffix: true, locale: es })}
          </div>
          <p className="text-gray-700">{review.response}</p>
        </div>
      )}

      {/* Formulario de respuesta para el dueño del servicio */}
      {isOwner && !review.response && (
        <div className="mt-4">
          {isResponding ? (
            <div className="space-y-3">
              <Textarea
                placeholder="Escribe tu respuesta a esta reseña..."
                value={response}
                onChange={(e) => setResponse(e.target.value)}
                className="min-h-[100px]"
              />
              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={handleCancelResponse} disabled={isSubmitting}>
                  Cancelar
                </Button>
                <Button
                  onClick={handleSubmitResponse}
                  disabled={!response.trim() || isSubmitting}
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  {isSubmitting ? "Enviando..." : "Enviar respuesta"}
                </Button>
              </div>
            </div>
          ) : (
            <Button variant="outline" onClick={handleRespondClick} className="text-sm">
              Responder a esta reseña
            </Button>
          )}
        </div>
      )}

      {/* Botón de "útil" */}
      <div className="flex items-center gap-2 mt-4">
        <Button
          variant="ghost"
          size="sm"
          className={`text-gray-500 hover:text-gray-700 ${hasMarkedHelpful ? "text-emerald-600" : ""}`}
          onClick={handleMarkHelpful}
          disabled={hasMarkedHelpful}
        >
          <ThumbsUp className="h-4 w-4 mr-1" />
          Útil {helpfulCount > 0 && `(${helpfulCount})`}
        </Button>
      </div>
    </div>
  )
}
