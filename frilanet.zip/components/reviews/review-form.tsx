"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { useToast } from "@/components/ui/use-toast"
import { createReview } from "@/lib/reviews"
import { Star } from "lucide-react"

interface ReviewFormProps {
  serviceId: string
  clientId: string
  onSuccess?: () => void
}

export function ReviewForm({ serviceId, clientId, onSuccess }: ReviewFormProps) {
  const [rating, setRating] = useState(0)
  const [hoverRating, setHoverRating] = useState(0)
  const [title, setTitle] = useState("")
  const [comment, setComment] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (rating === 0 || !comment.trim()) {
      toast({
        title: "Campos incompletos",
        description: "Por favor, selecciona una calificación y escribe un comentario.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      const result = await createReview(serviceId, clientId, rating, comment.trim(), title.trim() || undefined)

      if (result.success) {
        toast({
          title: "¡Gracias por tu reseña!",
          description: "Tu reseña ha sido publicada correctamente.",
        })

        // Limpiar el formulario
        setRating(0)
        setTitle("")
        setComment("")

        // Llamar al callback de éxito si existe
        if (onSuccess) {
          onSuccess()
        }
      } else {
        toast({
          title: "Error",
          description: result.error || "No se pudo publicar tu reseña. Inténtalo de nuevo.",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Ocurrió un error al publicar tu reseña.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium mb-2">Calificación</label>
        <div className="flex gap-1">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              onClick={() => setRating(star)}
              onMouseEnter={() => setHoverRating(star)}
              onMouseLeave={() => setHoverRating(0)}
              className="focus:outline-none"
            >
              <Star
                className={`h-8 w-8 ${
                  star <= (hoverRating || rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                }`}
              />
            </button>
          ))}
        </div>
      </div>

      <div>
        <label htmlFor="review-title" className="block text-sm font-medium mb-2">
          Título (opcional)
        </label>
        <Input
          id="review-title"
          placeholder="Resume tu experiencia en una frase"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          maxLength={100}
        />
      </div>

      <div>
        <label htmlFor="review-comment" className="block text-sm font-medium mb-2">
          Comentario
        </label>
        <Textarea
          id="review-comment"
          placeholder="Comparte los detalles de tu experiencia con este servicio"
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          className="min-h-[150px]"
          required
        />
      </div>

      <Button
        type="submit"
        className="bg-emerald-600 hover:bg-emerald-700"
        disabled={isSubmitting || rating === 0 || !comment.trim()}
      >
        {isSubmitting ? "Publicando..." : "Publicar reseña"}
      </Button>
    </form>
  )
}
