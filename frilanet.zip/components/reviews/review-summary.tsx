import { Star } from "lucide-react"

interface ReviewSummaryProps {
  avgRating: number
  totalReviews: number
  ratingCounts?: Record<number, number>
}

export function ReviewSummary({ avgRating, totalReviews, ratingCounts = {} }: ReviewSummaryProps) {
  // Calcular porcentajes para cada nivel de calificación
  const getPercentage = (count: number) => {
    if (totalReviews === 0) return 0
    return Math.round((count / totalReviews) * 100)
  }

  // Preparar datos de distribución de calificaciones
  const ratings = [5, 4, 3, 2, 1].map((rating) => ({
    rating,
    count: ratingCounts[rating] || 0,
    percentage: getPercentage(ratingCounts[rating] || 0),
  }))

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <div className="text-4xl font-bold">{avgRating.toFixed(1)}</div>
        <div>
          <div className="flex mb-1">
            {[1, 2, 3, 4, 5].map((star) => (
              <Star
                key={star}
                className={`h-5 w-5 ${
                  star <= Math.round(avgRating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                }`}
              />
            ))}
          </div>
          <div className="text-sm text-gray-600">
            {totalReviews} {totalReviews === 1 ? "reseña" : "reseñas"}
          </div>
        </div>
      </div>

      {totalReviews > 0 && (
        <div className="space-y-2">
          {ratings.map(({ rating, count, percentage }) => (
            <div key={rating} className="flex items-center gap-2">
              <div className="w-12 text-sm">{rating} estrellas</div>
              <div className="flex-1 h-2 bg-gray-200 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-600 rounded-full" style={{ width: `${percentage}%` }}></div>
              </div>
              <div className="w-8 text-xs text-right text-gray-600">{percentage}%</div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
