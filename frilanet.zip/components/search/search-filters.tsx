"use client"

import type React from "react"

import { useState, useTransition } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Search, Filter } from "lucide-react"

interface SearchFiltersProps {
  currentQuery?: string
  currentCategories?: string[]
  currentLocation?: string
}

const categories = [
  "Diseño Gráfico",
  "Desarrollo Web",
  "Redacción",
  "Marketing Digital",
  "Traducción",
  "Audio y Video",
  "Asesoría Legal",
  "Finanzas",
]

export function SearchFilters({ currentQuery = "", currentCategories = [], currentLocation = "" }: SearchFiltersProps) {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [isPending, startTransition] = useTransition()

  const [query, setQuery] = useState(currentQuery)
  const [location, setLocation] = useState(currentLocation)
  const [selectedCategories, setSelectedCategories] = useState<string[]>(currentCategories)

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    applyFilters()
  }

  const handleCategoryChange = (category: string, checked: boolean) => {
    setSelectedCategories(
      checked ? [...selectedCategories, category] : selectedCategories.filter((c) => c !== category),
    )
  }

  const applyFilters = () => {
    startTransition(() => {
      const params = new URLSearchParams()

      if (query) params.set("q", query)
      if (location) params.set("location", location)
      if (selectedCategories.length > 0) {
        selectedCategories.forEach((category) => {
          params.append("category", category)
        })
      }

      router.push(`/explorar?${params.toString()}`)
    })
  }

  const clearFilters = () => {
    setQuery("")
    setLocation("")
    setSelectedCategories([])
    router.push("/explorar")
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Filter className="h-5 w-5" />
          Filtros
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <form onSubmit={handleSearch} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="search">Buscar</Label>
            <div className="flex">
              <Input
                id="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Buscar freelancers o servicios"
              />
              <Button type="submit" className="ml-2 bg-emerald-600 hover:bg-emerald-700">
                <Search className="h-4 w-4" />
                <span className="sr-only">Buscar</span>
              </Button>
            </div>
          </div>
        </form>

        <div className="space-y-2">
          <Label htmlFor="location">Ubicación</Label>
          <Input
            id="location"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="Cualquier ubicación"
          />
        </div>

        <div className="space-y-3">
          <Label>Categorías</Label>
          <div className="space-y-2">
            {categories.map((category) => (
              <div key={category} className="flex items-center space-x-2">
                <Checkbox
                  id={`category-${category}`}
                  checked={selectedCategories.includes(category)}
                  onCheckedChange={(checked) => handleCategoryChange(category, checked === true)}
                />
                <Label htmlFor={`category-${category}`} className="text-sm font-normal cursor-pointer">
                  {category}
                </Label>
              </div>
            ))}
          </div>
        </div>

        <div className="flex flex-col gap-2">
          <Button onClick={applyFilters} className="w-full bg-emerald-600 hover:bg-emerald-700" disabled={isPending}>
            Aplicar filtros
          </Button>
          <Button onClick={clearFilters} variant="outline" className="w-full" disabled={isPending}>
            Limpiar filtros
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
