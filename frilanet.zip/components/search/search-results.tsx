import Link from "next/link"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Clock, MapPin, Star, AlertCircle } from "lucide-react"
import { searchFreelancersAndServices } from "@/lib/search"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface SearchResultsProps {
  query?: string
  categories?: string[] | string
  location?: string
  page?: number
}

export async function SearchResults({ query = "", categories, location, page = 1 }: SearchResultsProps) {
  console.log("Searching with params:", { query, categories, location, page })

  try {
    const results = await searchFreelancersAndServices(query, categories, location, page)
    const hasResults = results.freelancers.length > 0 || results.services.length > 0

    if (!hasResults) {
      return (
        <div className="py-8 text-center">
          <h2 className="text-xl font-semibold mb-2">No se encontraron resultados</h2>
          <p className="text-gray-500">Intenta con otros términos de búsqueda o filtros</p>
        </div>
      )
    }

    return (
      <div className="space-y-8">
        {results.freelancers.length > 0 && (
          <div>
            <h2 className="text-xl font-semibold mb-4">Freelancers ({results.totalFreelancers})</h2>
            <div className="space-y-4">
              {results.freelancers.map((freelancer) => (
                <Card key={freelancer.id} className="overflow-hidden">
                  <CardContent className="p-0">
                    <div className="flex flex-col md:flex-row">
                      <div className="relative w-full md:w-1/4 h-40 md:h-auto">
                        <Image
                          src={freelancer.avatar_url || "/placeholder.svg?height=150&width=150"}
                          alt={freelancer.name || ""}
                          className="object-cover"
                          fill
                        />
                      </div>
                      <div className="p-6 flex-1 flex flex-col">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="font-semibold text-lg">
                              <Link
                                href={`/freelancers/${freelancer.username}`}
                                className="hover:text-blue-600 transition-colors"
                              >
                                {freelancer.name}
                              </Link>
                            </h3>
                            <p className="text-gray-600">{freelancer.title}</p>
                          </div>
                          <div className="flex items-center">
                            <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                            <span className="ml-1 font-medium">4.9</span>
                            <span className="text-gray-500 text-sm ml-1">(12)</span>
                          </div>
                        </div>
                        {freelancer.location && (
                          <div className="flex items-center text-sm text-gray-500 mb-3">
                            <MapPin className="h-4 w-4 mr-1" />
                            {freelancer.location}
                          </div>
                        )}
                        <p className="text-gray-700 mb-4 line-clamp-2">
                          {freelancer.about || "Este freelancer aún no ha añadido una descripción."}
                        </p>
                        <div className="flex flex-wrap gap-2 mb-4">
                          {freelancer.skills?.slice(0, 5).map((skill, index) => (
                            <Badge key={index} variant="secondary" className="bg-gray-100">
                              {skill}
                            </Badge>
                          ))}
                          {freelancer.skills && freelancer.skills.length > 5 && (
                            <Badge variant="secondary" className="bg-gray-100">
                              +{freelancer.skills.length - 5} más
                            </Badge>
                          )}
                        </div>
                        <div className="mt-auto">
                          <Button className="bg-blue-600 hover:bg-blue-700">
                            <Link
                              href={`/freelancers/${freelancer.username}`}
                              className="w-full h-full flex items-center justify-center"
                            >
                              Ver perfil
                            </Link>
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {results.services.length > 0 && (
          <div>
            <h2 className="text-xl font-semibold mb-4">Servicios ({results.totalServices})</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {results.services.map((service) => (
                <Card key={service.id} className={service.featured ? "border-blue-500" : ""}>
                  <div className="relative h-40 w-full">
                    <Image
                      src={service.image_url || "/placeholder.svg?height=200&width=300"}
                      alt={service.title}
                      className="object-cover rounded-t-lg"
                      fill
                    />
                    {service.featured && <Badge className="absolute top-2 right-2 bg-blue-600">Destacado</Badge>}
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-lg mb-2">{service.title}</h3>
                    <p className="text-gray-600 text-sm mb-4 line-clamp-2">{service.description}</p>
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-2 text-sm text-gray-600">
                        <Clock className="h-4 w-4" />
                        <span>Entrega en {service.delivery_time}</span>
                      </div>
                      <div className="font-bold text-lg">${service.price}</div>
                    </div>
                    <Button className="w-full mt-4 bg-blue-600 hover:bg-blue-700">
                      <Link
                        href={`/freelancers/${service.profile_id}/servicios/${service.id}`}
                        className="w-full h-full flex items-center justify-center"
                      >
                        Ver detalles
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Paginación */}
        {(results.totalFreelancers > 10 || results.totalServices > 10) && (
          <div className="flex justify-center mt-8">
            <div className="flex gap-2">
              {page > 1 && (
                <Button variant="outline">
                  <Link
                    href={`/explorar?q=${query}&page=${page - 1}${
                      categories
                        ? Array.isArray(categories)
                          ? categories.map((c) => `&category=${c}`).join("")
                          : `&category=${categories}`
                        : ""
                    }${location ? `&location=${location}` : ""}`}
                  >
                    Anterior
                  </Link>
                </Button>
              )}
              <Button variant="outline">
                <Link
                  href={`/explorar?q=${query}&page=${page + 1}${
                    categories
                      ? Array.isArray(categories)
                        ? categories.map((c) => `&category=${c}`).join("")
                        : `&category=${categories}`
                      : ""
                  }${location ? `&location=${location}` : ""}`}
                >
                  Siguiente
                </Link>
              </Button>
            </div>
          </div>
        )}
      </div>
    )
  } catch (error) {
    console.error("Error en la búsqueda:", error)
    return (
      <div className="py-8">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error en la búsqueda</AlertTitle>
          <AlertDescription>
            Ha ocurrido un problema al realizar la búsqueda. Por favor, inténtalo de nuevo más tarde o con términos de
            búsqueda diferentes.
          </AlertDescription>
        </Alert>
      </div>
    )
  }
}
