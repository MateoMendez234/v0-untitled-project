import mongoose, { Schema, type Document, type Types } from "mongoose"

// Interfaz para el documento de Conversación
export interface IConversation extends Document {
  userId: Types.ObjectId
  freelancerId: Types.ObjectId
  subject: string
  serviceId?: Types.ObjectId
  lastMessage?: string
  lastMessageAt?: Date
  createdAt: Date
  updatedAt: Date
}

// Esquema de Conversación
const ConversationSchema = new Schema<IConversation>(
  {
    userId: { type: Schema.Types.ObjectId, ref: "User", required: true },
    freelancerId: { type: Schema.Types.ObjectId, ref: "User", required: true },
    subject: { type: String, required: true },
    serviceId: { type: Schema.Types.ObjectId, ref: "Service" },
    lastMessage: { type: String },
    lastMessageAt: { type: Date },
  },
  { timestamps: true },
)

// Interfaz para el documento de Mensaje
export interface IMessage extends Document {
  conversationId: Types.ObjectId
  senderId: Types.ObjectId
  content: string
  isRead: boolean
  createdAt: Date
  updatedAt: Date
}

// Esquema de Mensaje
const MessageSchema = new Schema<IMessage>(
  {
    conversationId: { type: Schema.Types.ObjectId, ref: "Conversation", required: true },
    senderId: { type: Schema.Types.ObjectId, ref: "User", required: true },
    content: { type: String, required: true },
    isRead: { type: Boolean, default: false },
  },
  { timestamps: true },
)

// Crear índices para mejorar el rendimiento de las consultas
ConversationSchema.index({ userId: 1 })
ConversationSchema.index({ freelancerId: 1 })
MessageSchema.index({ conversationId: 1 })
MessageSchema.index({ senderId: 1 })

// Exportar modelos
export const Conversation =
  mongoose.models.Conversation || mongoose.model<IConversation>("Conversation", ConversationSchema)
export const Message = mongoose.models.Message || mongoose.model<IMessage>("Message", MessageSchema)
