import mongoose, { Schema, type Document, type Types } from "mongoose"

export interface IOrder extends Document {
  clientId: Types.ObjectId
  serviceId: Types.ObjectId
  packageId?: string
  amount: number
  status: "pending" | "paid" | "completed" | "cancelled"
}

const OrderSchema = new Schema<IOrder>(
  {
    clientId: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    serviceId: {
      type: Schema.Types.ObjectId,
      ref: "Service",
      required: true,
    },
    packageId: String,
    amount: {
      type: Number,
      required: true,
    },
    status: {
      type: String,
      enum: ["pending", "paid", "completed", "cancelled"],
      default: "pending",
    },
  },
  {
    timestamps: true,
  },
)

const Order = mongoose.models.Order || mongoose.model<IOrder>("Order", OrderSchema)

export default Order
