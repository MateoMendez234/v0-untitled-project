import mongoose, { Schema, type Document } from "mongoose"

export interface IPortfolioItem extends Document {
  profileId: mongoose.Types.ObjectId
  title: string
  description: string | null
  imageUrl: string | null
  category: string | null
  tags: string[]
  projectUrl: string | null
  createdAt: Date
  updatedAt: Date
}

const PortfolioItemSchema = new Schema<IPortfolioItem>(
  {
    profileId: { type: Schema.Types.ObjectId, ref: "Profile", required: true },
    title: { type: String, required: true },
    description: { type: String },
    imageUrl: { type: String },
    category: { type: String },
    tags: { type: [String], default: [] },
    projectUrl: { type: String },
  },
  { timestamps: true },
)

// Crear índices para búsquedas eficientes
PortfolioItemSchema.index({ profileId: 1 })
PortfolioItemSchema.index({ category: 1 })
PortfolioItemSchema.index({ tags: 1 })

export default mongoose.models.PortfolioItem || mongoose.model<IPortfolioItem>("PortfolioItem", PortfolioItemSchema)
