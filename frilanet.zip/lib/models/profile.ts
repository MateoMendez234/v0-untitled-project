import mongoose, { Schema, type Document } from "mongoose"

export interface IProfile extends Document {
  userId: mongoose.Types.ObjectId
  username: string | null
  name: string | null
  title: string | null
  avatarUrl: string | null
  coverImageUrl: string | null
  location: string | null
  about: string | null
  email: string | null
  phone: string | null
  website: string | null
  memberSince: Date
  lastActive: Date
  completionRate: number
  responseTime: string
  isFreelancer: boolean
  skills: string[]
  languages: string[]
  rating: number
  ratingCount: number
  createdAt: Date
  updatedAt: Date
}

const ProfileSchema = new Schema<IProfile>(
  {
    userId: { type: Schema.Types.ObjectId, ref: "User", required: true },
    username: { type: String, unique: true, sparse: true },
    name: { type: String },
    title: { type: String },
    avatarUrl: { type: String },
    coverImageUrl: { type: String },
    location: { type: String },
    about: { type: String },
    email: { type: String },
    phone: { type: String },
    website: { type: String },
    memberSince: { type: Date, default: Date.now },
    lastActive: { type: Date, default: Date.now },
    completionRate: { type: Number, default: 0 },
    responseTime: { type: String, default: "N/A" },
    isFreelancer: { type: Boolean, default: false },
    skills: { type: [String], default: [] },
    languages: { type: [String], default: [] },
    rating: { type: Number, default: 0 },
    ratingCount: { type: Number, default: 0 },
  },
  { timestamps: true },
)

// Crear índices para búsquedas eficientes
ProfileSchema.index({ username: 1 })
ProfileSchema.index({ userId: 1 })
ProfileSchema.index({ isFreelancer: 1 })
ProfileSchema.index({ skills: 1 })
ProfileSchema.index({ languages: 1 })

export default mongoose.models.Profile || mongoose.model<IProfile>("Profile", ProfileSchema)
