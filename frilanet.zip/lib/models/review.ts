import mongoose, { Schema, type Document, type Types } from "mongoose"

export interface IReview extends Document {
  serviceId: Types.ObjectId
  clientId: Types.ObjectId
  rating: number
  comment: string
  title?: string
  response?: string
  responseDate?: Date
  helpfulCount: number
  status: "pending" | "published" | "rejected"
}

const ReviewSchema = new Schema<IReview>(
  {
    serviceId: {
      type: Schema.Types.ObjectId,
      ref: "Service",
      required: true,
    },
    clientId: {
      type: Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    rating: {
      type: Number,
      required: true,
      min: 1,
      max: 5,
    },
    comment: {
      type: String,
      required: true,
    },
    title: String,
    response: String,
    responseDate: Date,
    helpfulCount: {
      type: Number,
      default: 0,
    },
    status: {
      type: String,
      enum: ["pending", "published", "rejected"],
      default: "published",
    },
  },
  {
    timestamps: true,
  },
)

const Review = mongoose.models.Review || mongoose.model<IReview>("Review", ReviewSchema)

export default Review
