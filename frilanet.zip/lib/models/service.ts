import mongoose, { Schema, type Document } from "mongoose"

export interface IService extends Document {
  profileId: mongoose.Types.ObjectId
  title: string
  description: string
  category: string | null
  basePrice: number
  deliveryTime: number
  revisions: number
  features: string[]
  imageUrl: string | null
  isActive: boolean
  createdAt: Date
  updatedAt: Date
}

const ServiceSchema = new Schema<IService>(
  {
    profileId: { type: Schema.Types.ObjectId, ref: "Profile", required: true },
    title: { type: String, required: true },
    description: { type: String, required: true },
    category: { type: String },
    basePrice: { type: Number, required: true },
    deliveryTime: { type: Number, required: true },
    revisions: { type: Number, default: 1 },
    features: { type: [String], default: [] },
    imageUrl: { type: String },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true },
)

// Crear índices para búsquedas eficientes
ServiceSchema.index({ profileId: 1 })
ServiceSchema.index({ category: 1 })
ServiceSchema.index({ isActive: 1 })
ServiceSchema.index({ title: "text", description: "text", category: "text" })

export default mongoose.models.Service || mongoose.model<IService>("Service", ServiceSchema)
