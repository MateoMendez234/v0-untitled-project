import mongoose, { Schema, type Document } from "mongoose"
import { hash } from "bcrypt"

export interface IUser extends Document {
  email: string
  password: string
  name: string
  isAdmin: boolean
  isFreelancer: boolean
  createdAt: Date
  updatedAt: Date
}

const UserSchema = new Schema<IUser>(
  {
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
    },
    password: {
      type: String,
      required: true,
    },
    name: {
      type: String,
      required: true,
    },
    isAdmin: {
      type: Boolean,
      default: false,
    },
    isFreelancer: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  },
)

// Hash password before saving
UserSchema.pre("save", async function (next) {
  if (!this.isModified("password")) {
    return next()
  }

  try {
    const hashedPassword = await hash(this.password, 10)
    this.password = hashedPassword
    next()
  } catch (error: any) {
    next(error)
  }
})

export default mongoose.models.User || mongoose.model<IUser>("User", UserSchema)
