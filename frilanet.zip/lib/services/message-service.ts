import { connectToDatabase } from "../mongodb"
import { Conversation, Message } from "../models/conversation"
import Profile from "../models/profile"
import { Types } from "mongoose"

export interface MessageWithSender {
  id: string
  conversationId: string
  senderId: string
  content: string
  createdAt: Date
  read: boolean
  senderName?: string
  senderAvatar?: string
}

export interface ConversationWithParticipants {
  id: string
  userId: string
  freelancerId: string
  createdAt: Date
  updatedAt: Date
  lastMessage?: string
  lastMessageAt?: Date
  unreadCount?: number
  freelancerName?: string
  freelancerAvatar?: string
  userName?: string
  userAvatar?: string
  subject?: string
  serviceId?: string
  otherParticipantName?: string
  otherParticipantAvatar?: string
}

export async function getConversations(userId: string): Promise<ConversationWithParticipants[]> {
  await connectToDatabase()

  const conversations = await Conversation.find({
    $or: [{ userId: new Types.ObjectId(userId) }, { freelancerId: new Types.ObjectId(userId) }],
  }).sort({ updatedAt: -1 })

  const conversationsWithDetails = await Promise.all(
    conversations.map(async (conversation) => {
      // Obtener información del freelancer
      const freelancerProfile = await Profile.findOne({ userId: conversation.freelancerId })

      // Obtener información del usuario
      const userProfile = await Profile.findOne({ userId: conversation.userId })

      // Contar mensajes no leídos
      const unreadCount = await Message.countDocuments({
        conversationId: conversation._id,
        read: false,
        senderId: { $ne: new Types.ObjectId(userId) },
      })

      const isFreelancer = conversation.freelancerId.toString() === userId

      return {
        id: conversation._id.toString(),
        userId: conversation.userId.toString(),
        freelancerId: conversation.freelancerId.toString(),
        createdAt: conversation.createdAt,
        updatedAt: conversation.updatedAt,
        lastMessage: conversation.lastMessage,
        lastMessageAt: conversation.lastMessageAt,
        unreadCount,
        freelancerName: freelancerProfile?.name || freelancerProfile?.username,
        freelancerAvatar: freelancerProfile?.avatarUrl,
        userName: userProfile?.name || userProfile?.username,
        userAvatar: userProfile?.avatarUrl,
        subject: conversation.subject,
        serviceId: conversation.serviceId?.toString(),
        otherParticipantName: isFreelancer
          ? userProfile?.name || userProfile?.username
          : freelancerProfile?.name || freelancerProfile?.username,
        otherParticipantAvatar: isFreelancer ? userProfile?.avatarUrl : freelancerProfile?.avatarUrl,
      }
    }),
  )

  return conversationsWithDetails
}

export async function getConversation(
  conversationId: string,
  userId: string,
): Promise<ConversationWithParticipants | null> {
  await connectToDatabase()

  const conversation = await Conversation.findById(conversationId)

  if (!conversation) {
    return null
  }

  // Verificar que el usuario es parte de la conversación
  if (conversation.userId.toString() !== userId && conversation.freelancerId.toString() !== userId) {
    return null
  }

  // Obtener información del freelancer
  const freelancerProfile = await Profile.findOne({ userId: conversation.freelancerId })

  // Obtener información del usuario
  const userProfile = await Profile.findOne({ userId: conversation.userId })

  // Contar mensajes no leídos
  const unreadCount = await Message.countDocuments({
    conversationId: conversation._id,
    read: false,
    senderId: { $ne: new Types.ObjectId(userId) },
  })

  const isFreelancer = conversation.freelancerId.toString() === userId

  return {
    id: conversation._id.toString(),
    userId: conversation.userId.toString(),
    freelancerId: conversation.freelancerId.toString(),
    createdAt: conversation.createdAt,
    updatedAt: conversation.updatedAt,
    lastMessage: conversation.lastMessage,
    lastMessageAt: conversation.lastMessageAt,
    unreadCount,
    freelancerName: freelancerProfile?.name || freelancerProfile?.username,
    freelancerAvatar: freelancerProfile?.avatarUrl,
    userName: userProfile?.name || userProfile?.username,
    userAvatar: userProfile?.avatarUrl,
    subject: conversation.subject,
    serviceId: conversation.serviceId?.toString(),
    otherParticipantName: isFreelancer
      ? userProfile?.name || userProfile?.username
      : freelancerProfile?.name || freelancerProfile?.username,
    otherParticipantAvatar: isFreelancer ? userProfile?.avatarUrl : freelancerProfile?.avatarUrl,
  }
}

export async function getMessages(conversationId: string): Promise<MessageWithSender[]> {
  await connectToDatabase()

  const messages = await Message.find({ conversationId: new Types.ObjectId(conversationId) }).sort({ createdAt: 1 })

  const messagesWithSender = await Promise.all(
    messages.map(async (message) => {
      // Obtener información del remitente
      const senderProfile = await Profile.findOne({ userId: message.senderId })

      return {
        id: message._id.toString(),
        conversationId: message.conversationId.toString(),
        senderId: message.senderId.toString(),
        content: message.content,
        createdAt: message.createdAt,
        read: message.read,
        senderName: senderProfile?.name || senderProfile?.username,
        senderAvatar: senderProfile?.avatarUrl,
      }
    }),
  )

  return messagesWithSender
}

export async function markMessagesAsRead(conversationId: string, userId: string): Promise<void> {
  await connectToDatabase()

  await Message.updateMany(
    {
      conversationId: new Types.ObjectId(conversationId),
      senderId: { $ne: new Types.ObjectId(userId) },
      read: false,
    },
    { read: true },
  )
}

export async function sendMessage(
  conversationId: string,
  senderId: string,
  content: string,
): Promise<MessageWithSender | null> {
  try {
    await connectToDatabase()

    // Crear el mensaje
    const message = new Message({
      conversationId: new Types.ObjectId(conversationId),
      senderId: new Types.ObjectId(senderId),
      content,
      read: false,
    })

    await message.save()

    // Actualizar la conversación
    await Conversation.findByIdAndUpdate(conversationId, {
      lastMessage: content,
      lastMessageAt: new Date(),
      updatedAt: new Date(),
    })

    // Obtener información del remitente
    const senderProfile = await Profile.findOne({ userId: new Types.ObjectId(senderId) })

    return {
      id: message._id.toString(),
      conversationId: message.conversationId.toString(),
      senderId: message.senderId.toString(),
      content: message.content,
      createdAt: message.createdAt,
      read: message.read,
      senderName: senderProfile?.name || senderProfile?.username,
      senderAvatar: senderProfile?.avatarUrl,
    }
  } catch (error) {
    console.error("Error sending message:", error)
    return null
  }
}

export async function createConversation(
  userId: string,
  freelancerId: string,
  subject?: string,
  serviceId?: string,
): Promise<ConversationWithParticipants | null> {
  try {
    await connectToDatabase()

    // Verificar si ya existe una conversación entre estos usuarios
    const existingConversation = await Conversation.findOne({
      userId: new Types.ObjectId(userId),
      freelancerId: new Types.ObjectId(freelancerId),
    })

    if (existingConversation) {
      // Actualizar el asunto y servicio si se proporcionan
      if (subject || serviceId) {
        const updateData: any = {}
        if (subject) updateData.subject = subject
        if (serviceId) updateData.serviceId = new Types.ObjectId(serviceId)

        await Conversation.findByIdAndUpdate(existingConversation._id, updateData)
      }

      // Obtener la conversación actualizada con detalles
      return getConversation(existingConversation._id.toString(), userId)
    }

    // Crear una nueva conversación
    const conversation = new Conversation({
      userId: new Types.ObjectId(userId),
      freelancerId: new Types.ObjectId(freelancerId),
      subject: subject || "Nueva conversación",
      serviceId: serviceId ? new Types.ObjectId(serviceId) : undefined,
    })

    await conversation.save()

    // Obtener la conversación con detalles
    return getConversation(conversation._id.toString(), userId)
  } catch (error) {
    console.error("Error creating conversation:", error)
    return null
  }
}

export async function getUnreadMessagesCount(userId: string): Promise<number> {
  await connectToDatabase()

  // Obtener todas las conversaciones del usuario
  const conversations = await Conversation.find({
    $or: [{ userId: new Types.ObjectId(userId) }, { freelancerId: new Types.ObjectId(userId) }],
  })

  if (conversations.length === 0) {
    return 0
  }

  // Contar mensajes no leídos en todas las conversaciones
  const unreadCount = await Message.countDocuments({
    conversationId: { $in: conversations.map((c) => c._id) },
    senderId: { $ne: new Types.ObjectId(userId) },
    read: false,
  })

  return unreadCount
}
