import { connectToDatabase } from "../mongodb"
import Order from "../models/order"
import Service from "../models/service"
import Profile from "../models/profile"
import { Types } from "mongoose"
import Stripe from "stripe"

export interface OrderWithDetails {
  id: string
  clientId: string
  serviceId: string
  packageId: string | null
  amount: number
  status: "pending" | "paid" | "completed" | "cancelled"
  createdAt: Date
  updatedAt: Date
  service: {
    title: string
    imageUrl: string | null
  }
  freelancer: {
    id: string
    name: string | null
    username: string | null
    avatarUrl: string | null
  }
  client: {
    name: string | null
    username: string | null
    avatarUrl: string | null
  }
}

// Inicializar Stripe
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", {
  apiVersion: "2023-10-16",
})

export async function createOrder(
  clientId: string,
  serviceId: string,
  packageId: string | null,
  amount: number,
): Promise<{ success: boolean; orderId?: string; error?: any }> {
  try {
    await connectToDatabase()

    const order = new Order({
      clientId: new Types.ObjectId(clientId),
      serviceId: new Types.ObjectId(serviceId),
      packageId,
      amount,
      status: "pending",
    })

    await order.save()

    return { success: true, orderId: order._id.toString() }
  } catch (error) {
    console.error("Error creating order:", error)
    return { success: false, error }
  }
}

export async function getOrderById(orderId: string): Promise<OrderWithDetails | null> {
  await connectToDatabase()

  const order = await Order.findById(orderId)

  if (!order) {
    return null
  }

  // Obtener detalles del servicio
  const service = await Service.findById(order.serviceId)

  if (!service) {
    return null
  }

  // Obtener detalles del freelancer
  const freelancerProfile = await Profile.findOne({ userId: service.profileId })

  // Obtener detalles del cliente
  const clientProfile = await Profile.findOne({ userId: order.clientId })

  return {
    id: order._id.toString(),
    clientId: order.clientId.toString(),
    serviceId: order.serviceId.toString(),
    packageId: order.packageId,
    amount: order.amount,
    status: order.status,
    createdAt: order.createdAt,
    updatedAt: order.updatedAt,
    service: {
      title: service.title,
      imageUrl: service.imageUrl,
    },
    freelancer: {
      id: freelancerProfile?._id.toString() || "",
      name: freelancerProfile?.name,
      username: freelancerProfile?.username,
      avatarUrl: freelancerProfile?.avatarUrl,
    },
    client: {
      name: clientProfile?.name,
      username: clientProfile?.username,
      avatarUrl: clientProfile?.avatarUrl,
    },
  }
}

export async function getOrdersByClient(clientId: string): Promise<OrderWithDetails[]> {
  await connectToDatabase()

  const orders = await Order.find({ clientId: new Types.ObjectId(clientId) }).sort({ createdAt: -1 })

  const ordersWithDetails = await Promise.all(
    orders.map(async (order) => {
      // Obtener detalles del servicio
      const service = await Service.findById(order.serviceId)

      if (!service) {
        return null
      }

      // Obtener detalles del freelancer
      const freelancerProfile = await Profile.findOne({ userId: service.profileId })

      // Obtener detalles del cliente
      const clientProfile = await Profile.findOne({ userId: order.clientId })

      return {
        id: order._id.toString(),
        clientId: order.clientId.toString(),
        serviceId: order.serviceId.toString(),
        packageId: order.packageId,
        amount: order.amount,
        status: order.status,
        createdAt: order.createdAt,
        updatedAt: order.updatedAt,
        service: {
          title: service.title,
          imageUrl: service.imageUrl,
        },
        freelancer: {
          id: freelancerProfile?._id.toString() || "",
          name: freelancerProfile?.name,
          username: freelancerProfile?.username,
          avatarUrl: freelancerProfile?.avatarUrl,
        },
        client: {
          name: clientProfile?.name,
          username: clientProfile?.username,
          avatarUrl: clientProfile?.avatarUrl,
        },
      }
    }),
  )

  return ordersWithDetails.filter(Boolean) as OrderWithDetails[]
}

export async function updateOrderStatus(
  orderId: string,
  status: "pending" | "paid" | "completed" | "cancelled",
): Promise<{ success: boolean; error?: any }> {
  try {
    await connectToDatabase()

    await Order.findByIdAndUpdate(orderId, {
      status,
      updatedAt: new Date(),
    })

    return { success: true }
  } catch (error) {
    console.error("Error updating order status:", error)
    return { success: false, error }
  }
}

export async function createStripeCheckoutSession(
  orderId: string,
  serviceTitle: string,
  amount: number,
  clientEmail: string,
): Promise<{ success: boolean; sessionId?: string; error?: any }> {
  try {
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: serviceTitle,
            },
            unit_amount: amount * 100, // Stripe usa céntimos
          },
          quantity: 1,
        },
      ],
      mode: "payment",
      success_url: `${process.env.NEXT_PUBLIC_APP_URL}/checkout/confirmacion/${orderId}?success=true`,
      cancel_url: `${process.env.NEXT_PUBLIC_APP_URL}/checkout/${orderId}?cancelled=true`,
      customer_email: clientEmail,
      metadata: {
        order_id: orderId,
      },
    })

    return { success: true, sessionId: session.id }
  } catch (error) {
    console.error("Error creating Stripe checkout session:", error)
    return { success: false, error }
  }
}

export async function handleStripeWebhook(
  signature: string,
  payload: Buffer,
): Promise<{ success: boolean; error?: any }> {
  try {
    const event = stripe.webhooks.constructEvent(payload, signature, process.env.STRIPE_WEBHOOK_SECRET || "")

    if (event.type === "checkout.session.completed") {
      const session = event.data.object as Stripe.Checkout.Session
      const orderId = session.metadata?.order_id

      if (orderId) {
        await updateOrderStatus(orderId, "paid")
      }
    }

    return { success: true }
  } catch (error) {
    console.error("Error handling Stripe webhook:", error)
    return { success: false, error }
  }
}
