import { connectToDatabase } from "../mongodb"
import PortfolioItem from "../models/portfolio"
import { Types } from "mongoose"

export interface PortfolioItemDetails {
  _id: string
  profileId: string
  title: string
  description: string | null
  imageUrl: string | null
  category: string | null
  tags: string[]
  projectUrl?: string
  createdAt: Date
  updatedAt: Date
}

export async function getPortfolioByProfileId(profileId: string): Promise<PortfolioItemDetails[]> {
  await connectToDatabase()

  const items = await PortfolioItem.find({ profileId: new Types.ObjectId(profileId) }).sort({ createdAt: -1 })

  return items.map((item) => ({
    _id: item._id.toString(),
    profileId: item.profileId.toString(),
    title: item.title,
    description: item.description,
    imageUrl: item.imageUrl,
    category: item.category,
    tags: item.tags || [],
    projectUrl: item.projectUrl,
    createdAt: item.createdAt,
    updatedAt: item.updatedAt,
  }))
}

export async function getPortfolioItemById(itemId: string): Promise<PortfolioItemDetails | null> {
  await connectToDatabase()

  const item = await PortfolioItem.findById(itemId)

  if (!item) {
    return null
  }

  return {
    _id: item._id.toString(),
    profileId: item.profileId.toString(),
    title: item.title,
    description: item.description,
    imageUrl: item.imageUrl,
    category: item.category,
    tags: item.tags || [],
    projectUrl: item.projectUrl,
    createdAt: item.createdAt,
    updatedAt: item.updatedAt,
  }
}

export async function createPortfolioItem(
  item: Omit<PortfolioItemDetails, "_id" | "createdAt" | "updatedAt">,
): Promise<{ success: boolean; id?: string; error?: any }> {
  try {
    await connectToDatabase()

    const portfolioItem = new PortfolioItem({
      profileId: new Types.ObjectId(item.profileId),
      title: item.title,
      description: item.description,
      imageUrl: item.imageUrl,
      category: item.category,
      tags: item.tags || [],
      projectUrl: item.projectUrl,
    })

    await portfolioItem.save()

    return { success: true, id: portfolioItem._id.toString() }
  } catch (error) {
    console.error("Error creating portfolio item:", error)
    return { success: false, error }
  }
}

export async function updatePortfolioItem(
  itemId: string,
  itemData: Partial<PortfolioItemDetails>,
): Promise<{ success: boolean; error?: any }> {
  try {
    await connectToDatabase()

    await PortfolioItem.findByIdAndUpdate(itemId, itemData)

    return { success: true }
  } catch (error) {
    console.error("Error updating portfolio item:", error)
    return { success: false, error }
  }
}

export async function deletePortfolioItem(itemId: string): Promise<{ success: boolean; error?: any }> {
  try {
    await connectToDatabase()

    await PortfolioItem.findByIdAndDelete(itemId)

    return { success: true }
  } catch (error) {
    console.error("Error deleting portfolio item:", error)
    return { success: false, error }
  }
}
