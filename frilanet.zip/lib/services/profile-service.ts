import { connectToDatabase } from "../mongodb"
import Profile from "../models/profile"
import User from "../models/user"
import { Types } from "mongoose"

export type ProfileWithDetails = {
  _id: string
  userId: string
  username: string | null
  name: string | null
  title: string | null
  avatarUrl: string | null
  coverImageUrl: string | null
  location: string | null
  about: string | null
  email: string | null
  phone: string | null
  website: string | null
  memberSince: Date
  lastActive: Date
  completionRate: number
  responseTime: string
  isFreelancer: boolean
  skills: string[]
  languages: string[]
  rating?: number
  ratingCount?: number
  createdAt: Date
  updatedAt: Date
}

export async function getProfileByUsername(username: string): Promise<ProfileWithDetails | null> {
  await connectToDatabase()

  const profile = await Profile.findOne({ username })

  if (!profile) {
    return null
  }

  return {
    _id: profile._id.toString(),
    userId: profile.userId.toString(),
    username: profile.username,
    name: profile.name,
    title: profile.title,
    avatarUrl: profile.avatarUrl,
    coverImageUrl: profile.coverImageUrl,
    location: profile.location,
    about: profile.about,
    email: profile.email,
    phone: profile.phone,
    website: profile.website,
    memberSince: profile.memberSince,
    lastActive: profile.lastActive,
    completionRate: profile.completionRate,
    responseTime: profile.responseTime,
    isFreelancer: profile.isFreelancer,
    skills: profile.skills || [],
    languages: profile.languages || [],
    rating: profile.rating,
    ratingCount: profile.ratingCount,
    createdAt: profile.createdAt,
    updatedAt: profile.updatedAt,
  }
}

export async function getProfileById(id: string): Promise<ProfileWithDetails | null> {
  await connectToDatabase()

  const profile = await Profile.findById(id)

  if (!profile) {
    return null
  }

  return {
    _id: profile._id.toString(),
    userId: profile.userId.toString(),
    username: profile.username,
    name: profile.name,
    title: profile.title,
    avatarUrl: profile.avatarUrl,
    coverImageUrl: profile.coverImageUrl,
    location: profile.location,
    about: profile.about,
    email: profile.email,
    phone: profile.phone,
    website: profile.website,
    memberSince: profile.memberSince,
    lastActive: profile.lastActive,
    completionRate: profile.completionRate,
    responseTime: profile.responseTime,
    isFreelancer: profile.isFreelancer,
    skills: profile.skills || [],
    languages: profile.languages || [],
    rating: profile.rating,
    ratingCount: profile.ratingCount,
    createdAt: profile.createdAt,
    updatedAt: profile.updatedAt,
  }
}

export async function getProfileByUserId(userId: string): Promise<ProfileWithDetails | null> {
  await connectToDatabase()

  const profile = await Profile.findOne({ userId: new Types.ObjectId(userId) })

  if (!profile) {
    return null
  }

  return {
    _id: profile._id.toString(),
    userId: profile.userId.toString(),
    username: profile.username,
    name: profile.name,
    title: profile.title,
    avatarUrl: profile.avatarUrl,
    coverImageUrl: profile.coverImageUrl,
    location: profile.location,
    about: profile.about,
    email: profile.email,
    phone: profile.phone,
    website: profile.website,
    memberSince: profile.memberSince,
    lastActive: profile.lastActive,
    completionRate: profile.completionRate,
    responseTime: profile.responseTime,
    isFreelancer: profile.isFreelancer,
    skills: profile.skills || [],
    languages: profile.languages || [],
    rating: profile.rating,
    ratingCount: profile.ratingCount,
    createdAt: profile.createdAt,
    updatedAt: profile.updatedAt,
  }
}

export async function getFreelancers(limit = 10, offset = 0): Promise<ProfileWithDetails[]> {
  await connectToDatabase()

  const profiles = await Profile.find({ isFreelancer: true }).sort({ createdAt: -1 }).skip(offset).limit(limit)

  return profiles.map((profile) => ({
    _id: profile._id.toString(),
    userId: profile.userId.toString(),
    username: profile.username,
    name: profile.name,
    title: profile.title,
    avatarUrl: profile.avatarUrl,
    coverImageUrl: profile.coverImageUrl,
    location: profile.location,
    about: profile.about,
    email: profile.email,
    phone: profile.phone,
    website: profile.website,
    memberSince: profile.memberSince,
    lastActive: profile.lastActive,
    completionRate: profile.completionRate,
    responseTime: profile.responseTime,
    isFreelancer: profile.isFreelancer,
    skills: profile.skills || [],
    languages: profile.languages || [],
    rating: profile.rating,
    ratingCount: profile.ratingCount,
    createdAt: profile.createdAt,
    updatedAt: profile.updatedAt,
  }))
}

export async function updateProfile(
  profileId: string,
  profileData: Partial<ProfileWithDetails>,
): Promise<{ success: boolean; error?: any }> {
  try {
    await connectToDatabase()

    await Profile.findByIdAndUpdate(profileId, {
      ...profileData,
      lastActive: new Date(),
    })

    return { success: true }
  } catch (error) {
    console.error("Error updating profile:", error)
    return { success: false, error }
  }
}

export async function createFreelancerProfile(
  userId: string,
  profileData: Partial<ProfileWithDetails>,
): Promise<{ success: boolean; profileId?: string; error?: any }> {
  try {
    await connectToDatabase()

    // Actualizar el usuario para marcarlo como freelancer
    await User.findByIdAndUpdate(userId, { isFreelancer: true })

    // Crear o actualizar el perfil
    const profile = await Profile.findOneAndUpdate(
      { userId: new Types.ObjectId(userId) },
      {
        ...profileData,
        userId: new Types.ObjectId(userId),
        isFreelancer: true,
        memberSince: new Date(),
        lastActive: new Date(),
      },
      { upsert: true, new: true },
    )

    return { success: true, profileId: profile._id.toString() }
  } catch (error) {
    console.error("Error creating freelancer profile:", error)
    return { success: false, error }
  }
}
