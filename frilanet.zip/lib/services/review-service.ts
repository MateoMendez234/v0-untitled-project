import { connectToDatabase } from "../mongodb"
import Review from "../models/review"
import Order from "../models/order"
import Profile from "../models/profile"
import { Types } from "mongoose"
import Service from "../models/service" // Import Service model

export interface ReviewWithClient {
  id: string
  serviceId: string
  clientId: string
  rating: number
  comment: string
  title?: string
  createdAt: Date
  updatedAt: Date
  response?: string
  responseDate?: Date
  helpfulCount: number
  status: "pending" | "published" | "rejected"
  client?: {
    name: string
    username: string
    avatarUrl: string
  }
}

export async function getServiceReviews(serviceId: string): Promise<ReviewWithClient[]> {
  await connectToDatabase()

  const reviews = await Review.find({
    serviceId: new Types.ObjectId(serviceId),
    status: "published",
  }).sort({ createdAt: -1 })

  const reviewsWithClient = await Promise.all(
    reviews.map(async (review) => {
      // Obtener información del cliente
      const clientProfile = await Profile.findOne({ userId: review.clientId })

      return {
        id: review._id.toString(),
        serviceId: review.serviceId.toString(),
        clientId: review.clientId.toString(),
        rating: review.rating,
        comment: review.comment,
        title: review.title,
        createdAt: review.createdAt,
        updatedAt: review.updatedAt,
        response: review.response,
        responseDate: review.responseDate,
        helpfulCount: review.helpfulCount,
        status: review.status,
        client: clientProfile
          ? {
              name: clientProfile.name || "",
              username: clientProfile.username || "",
              avatarUrl: clientProfile.avatarUrl || "",
            }
          : undefined,
      }
    }),
  )

  return reviewsWithClient
}

export async function createReview(
  serviceId: string,
  clientId: string,
  rating: number,
  comment: string,
  title?: string,
): Promise<{ success: boolean; error?: any }> {
  try {
    await connectToDatabase()

    // Verificar si el cliente ya ha dejado una reseña para este servicio
    const existingReview = await Review.findOne({
      serviceId: new Types.ObjectId(serviceId),
      clientId: new Types.ObjectId(clientId),
    })

    if (existingReview) {
      return {
        success: false,
        error: "Ya has dejado una reseña para este servicio",
      }
    }

    // Verificar si el cliente ha completado una orden para este servicio
    const completedOrder = await Order.findOne({
      serviceId: new Types.ObjectId(serviceId),
      clientId: new Types.ObjectId(clientId),
      status: "completed",
    })

    if (!completedOrder) {
      return {
        success: false,
        error: "Solo puedes dejar reseñas para servicios que hayas contratado y completado",
      }
    }

    // Crear la reseña
    const review = new Review({
      serviceId: new Types.ObjectId(serviceId),
      clientId: new Types.ObjectId(clientId),
      rating,
      comment,
      title,
      status: "published",
    })

    await review.save()

    return { success: true }
  } catch (error) {
    console.error("Error creating review:", error)
    return { success: false, error }
  }
}

export async function respondToReview(
  reviewId: string,
  freelancerId: string,
  response: string,
): Promise<{ success: boolean; error?: any }> {
  try {
    await connectToDatabase()

    // Obtener la reseña
    const review = await Review.findById(reviewId)

    if (!review) {
      return {
        success: false,
        error: "Reseña no encontrada",
      }
    }

    // Obtener el servicio
    const service = await Service.findById(review.serviceId)

    if (!service) {
      return {
        success: false,
        error: "Servicio no encontrado",
      }
    }

    // Verificar que el freelancer es el dueño del servicio
    const profile = await Profile.findOne({ userId: new Types.ObjectId(freelancerId) })

    if (!profile || profile._id.toString() !== service.profileId.toString()) {
      return {
        success: false,
        error: "No tienes permiso para responder a esta reseña",
      }
    }

    // Actualizar la reseña con la respuesta
    await Review.findByIdAndUpdate(reviewId, {
      response,
      responseDate: new Date(),
    })

    return { success: true }
  } catch (error) {
    console.error("Error responding to review:", error)
    return { success: false, error }
  }
}

export async function markReviewAsHelpful(reviewId: string): Promise<{ success: boolean; error?: any }> {
  try {
    await connectToDatabase()

    await Review.findByIdAndUpdate(reviewId, {
      $inc: { helpfulCount: 1 },
    })

    return { success: true }
  } catch (error) {
    console.error("Error marking review as helpful:", error)
    return { success: false, error }
  }
}
