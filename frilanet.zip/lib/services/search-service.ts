import { connectToDatabase } from "@/lib/mongodb"
import Profile from "@/lib/models/profile"
import Service from "@/lib/models/service"

export type SearchResults = {
  freelancers: any[]
  services: any[]
  totalFreelancers: number
  totalServices: number
}

export async function searchFreelancersAndServices(
  query: string,
  categories?: string[] | string,
  minPrice?: number,
  maxPrice?: number,
  page = 1,
  limit = 10,
): Promise<SearchResults> {
  try {
    await connectToDatabase()
    const offset = (page - 1) * limit

    // Normalizar categorías
    const normalizedCategories = Array.isArray(categories) ? categories : categories ? [categories] : []

    // Construir consulta para freelancers
    const freelancerQuery: any = { isFreelancer: true }

    if (query) {
      freelancerQuery.$or = [
        { name: { $regex: query, $options: "i" } },
        { title: { $regex: query, $options: "i" } },
        { about: { $regex: query, $options: "i" } },
        { skills: { $in: [new RegExp(query, "i")] } },
      ]
    }

    // Construir consulta para servicios
    const serviceQuery: any = {}

    if (query) {
      serviceQuery.$or = [
        { title: { $regex: query, $options: "i" } },
        { description: { $regex: query, $options: "i" } },
      ]
    }

    if (minPrice !== undefined) {
      serviceQuery.price = { $gte: minPrice }
    }

    if (maxPrice !== undefined) {
      serviceQuery.price = { ...serviceQuery.price, $lte: maxPrice }
    }

    if (normalizedCategories.length > 0) {
      serviceQuery.category = { $in: normalizedCategories }
    }

    // Ejecutar consultas
    const [freelancers, totalFreelancers, services, totalServices] = await Promise.all([
      Profile.find(freelancerQuery).skip(offset).limit(limit).sort({ createdAt: -1 }),
      Profile.countDocuments(freelancerQuery),
      Service.find(serviceQuery).skip(offset).limit(limit).sort({ createdAt: -1 }),
      Service.countDocuments(serviceQuery),
    ])

    return {
      freelancers: freelancers.map((f) => f.toObject()),
      services: services.map((s) => s.toObject()),
      totalFreelancers,
      totalServices,
    }
  } catch (error) {
    console.error("Error en searchFreelancersAndServices:", error)
    return {
      freelancers: [],
      services: [],
      totalFreelancers: 0,
      totalServices: 0,
    }
  }
}
