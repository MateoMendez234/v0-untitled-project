import { connectToDatabase } from "../mongodb"
import Service from "../models/service"
import { Types } from "mongoose"

export interface ServiceDetails {
  _id: string
  profileId: string
  title: string
  description: string
  category: string | null
  basePrice: number
  deliveryTime: number
  revisions: number
  features: string[]
  imageUrl: string | null
  isActive: boolean
  createdAt: Date
  updatedAt: Date
}

export async function getServicesByProfileId(profileId: string): Promise<ServiceDetails[]> {
  await connectToDatabase()

  const services = await Service.find({ profileId: new Types.ObjectId(profileId), isActive: true }).sort({
    createdAt: -1,
  })

  return services.map((service) => ({
    _id: service._id.toString(),
    profileId: service.profileId.toString(),
    title: service.title,
    description: service.description,
    category: service.category,
    basePrice: service.basePrice,
    deliveryTime: service.deliveryTime,
    revisions: service.revisions,
    features: service.features || [],
    imageUrl: service.imageUrl,
    isActive: service.isActive,
    createdAt: service.createdAt,
    updatedAt: service.updatedAt,
  }))
}

export async function getServiceById(serviceId: string): Promise<ServiceDetails | null> {
  await connectToDatabase()

  const service = await Service.findById(serviceId)

  if (!service) {
    return null
  }

  return {
    _id: service._id.toString(),
    profileId: service.profileId.toString(),
    title: service.title,
    description: service.description,
    category: service.category,
    basePrice: service.basePrice,
    deliveryTime: service.deliveryTime,
    revisions: service.revisions,
    features: service.features || [],
    imageUrl: service.imageUrl,
    isActive: service.isActive,
    createdAt: service.createdAt,
    updatedAt: service.updatedAt,
  }
}

export async function createService(
  service: Omit<ServiceDetails, "_id" | "createdAt" | "updatedAt">,
): Promise<{ success: boolean; id?: string; error?: any }> {
  try {
    await connectToDatabase()

    const newService = new Service({
      profileId: new Types.ObjectId(service.profileId),
      title: service.title,
      description: service.description,
      category: service.category,
      basePrice: service.basePrice,
      deliveryTime: service.deliveryTime,
      revisions: service.revisions,
      features: service.features || [],
      imageUrl: service.imageUrl,
      isActive: service.isActive,
    })

    await newService.save()

    return { success: true, id: newService._id.toString() }
  } catch (error) {
    console.error("Error creating service:", error)
    return { success: false, error }
  }
}

export async function updateService(
  serviceId: string,
  serviceData: Partial<ServiceDetails>,
): Promise<{ success: boolean; error?: any }> {
  try {
    await connectToDatabase()

    await Service.findByIdAndUpdate(serviceId, serviceData)

    return { success: true }
  } catch (error) {
    console.error("Error updating service:", error)
    return { success: false, error }
  }
}

export async function deleteService(serviceId: string): Promise<{ success: boolean; error?: any }> {
  try {
    await connectToDatabase()

    await Service.findByIdAndUpdate(serviceId, { isActive: false })

    return { success: true }
  } catch (error) {
    console.error("Error deleting service:", error)
    return { success: false, error }
  }
}

export async function getActiveServices(limit = 10, offset = 0): Promise<ServiceDetails[]> {
  await connectToDatabase()

  const services = await Service.find({ isActive: true }).sort({ createdAt: -1 }).skip(offset).limit(limit)

  return services.map((service) => ({
    _id: service._id.toString(),
    profileId: service.profileId.toString(),
    title: service.title,
    description: service.description,
    category: service.category,
    basePrice: service.basePrice,
    deliveryTime: service.deliveryTime,
    revisions: service.revisions,
    features: service.features || [],
    imageUrl: service.imageUrl,
    isActive: service.isActive,
    createdAt: service.createdAt,
    updatedAt: service.updatedAt,
  }))
}

export async function searchServices(query: string, limit = 10, offset = 0): Promise<ServiceDetails[]> {
  await connectToDatabase()

  const services = await Service.find({
    isActive: true,
    $or: [
      { title: { $regex: query, $options: "i" } },
      { description: { $regex: query, $options: "i" } },
      { category: { $regex: query, $options: "i" } },
    ],
  })
    .sort({ createdAt: -1 })
    .skip(offset)
    .limit(limit)

  return services.map((service) => ({
    _id: service._id.toString(),
    profileId: service.profileId.toString(),
    title: service.title,
    description: service.description,
    category: service.category,
    basePrice: service.basePrice,
    deliveryTime: service.deliveryTime,
    revisions: service.revisions,
    features: service.features || [],
    imageUrl: service.imageUrl,
    isActive: service.isActive,
    createdAt: service.createdAt,
    updatedAt: service.updatedAt,
  }))
}
