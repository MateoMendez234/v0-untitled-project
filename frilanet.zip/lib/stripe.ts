import Stripe from "stripe"
import { createServerSupabaseClient } from "./supabase/server"

// Inicializar Stripe con la clave secreta
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || "", {
  apiVersion: "2023-10-16",
})

export interface PaymentIntent {
  id: string
  client_secret: string
  amount: number
  currency: string
  status: string
}

// Crear un intent de pago con Stripe
export async function createPaymentIntent(
  amount: number,
  currency = "eur",
  metadata: Record<string, string> = {},
): Promise<PaymentIntent> {
  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount: Math.round(amount * 100), // Stripe trabaja en centavos
      currency,
      metadata,
      automatic_payment_methods: {
        enabled: true,
      },
    })

    return {
      id: paymentIntent.id,
      client_secret: paymentIntent.client_secret as string,
      amount: paymentIntent.amount / 100, // Convertir de centavos a unidades
      currency: paymentIntent.currency,
      status: paymentIntent.status,
    }
  } catch (error) {
    console.error("Error creating payment intent:", error)
    throw error
  }
}

// Confirmar un pago
export async function confirmPayment(paymentIntentId: string): Promise<boolean> {
  try {
    const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId)

    return paymentIntent.status === "succeeded"
  } catch (error) {
    console.error("Error confirming payment:", error)
    return false
  }
}

// Actualizar una orden después de un pago exitoso
export async function updateOrderAfterPayment(orderId: string, paymentIntentId: string): Promise<boolean> {
  const supabase = createServerSupabaseClient()

  try {
    // Verificar el estado del pago en Stripe
    const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId)

    if (paymentIntent.status !== "succeeded") {
      return false
    }

    // Actualizar la orden en la base de datos
    const { error } = await supabase
      .from("orders")
      .update({
        status: "paid",
        payment_id: paymentIntentId,
        updated_at: new Date().toISOString(),
      })
      .eq("id", orderId)

    if (error) {
      console.error("Error updating order after payment:", error)
      return false
    }

    return true
  } catch (error) {
    console.error("Error in updateOrderAfterPayment:", error)
    return false
  }
}

// Crear un webhook para recibir eventos de Stripe
export async function handleStripeWebhook(
  body: string,
  signature: string,
): Promise<{ success: boolean; event?: Stripe.Event }> {
  try {
    const event = stripe.webhooks.constructEvent(body, signature, process.env.STRIPE_WEBHOOK_SECRET || "")

    // Procesar el evento según su tipo
    switch (event.type) {
      case "payment_intent.succeeded":
        const paymentIntent = event.data.object as Stripe.PaymentIntent

        // Actualizar la orden si el metadata contiene el ID de la orden
        if (paymentIntent.metadata.orderId) {
          await updateOrderAfterPayment(paymentIntent.metadata.orderId, paymentIntent.id)
        }
        break

      case "payment_intent.payment_failed":
        // Manejar fallos de pago
        const failedPaymentIntent = event.data.object as Stripe.PaymentIntent

        if (failedPaymentIntent.metadata.orderId) {
          const supabase = createServerSupabaseClient()

          await supabase
            .from("orders")
            .update({
              status: "failed",
              updated_at: new Date().toISOString(),
            })
            .eq("id", failedPaymentIntent.metadata.orderId)
        }
        break
    }

    return { success: true, event }
  } catch (error) {
    console.error("Error handling Stripe webhook:", error)
    return { success: false }
  }
}
