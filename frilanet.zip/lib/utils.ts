import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Función simplificada para obtener la URL base sin depender de variables de entorno
export function getBaseUrl() {
  // Si estamos en el navegador, usamos la URL actual
  if (typeof window !== "undefined") {
    return window.location.origin
  }

  // En el servidor, usamos un valor predeterminado seguro
  return "http://localhost:3000"
}

// Función para construir URLs absolutas
export function absoluteUrl(path: string): string {
  return `${getBaseUrl()}${path.startsWith("/") ? path : `/${path}`}`
}
