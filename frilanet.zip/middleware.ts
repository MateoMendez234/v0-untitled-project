import { NextResponse } from "next/server"
import { getToken } from "next-auth/jwt"
import type { NextRequest } from "next/server"

export async function middleware(request: NextRequest) {
  const path = request.nextUrl.pathname

  // Rutas que requieren autenticación
  const protectedPaths = ["/dashboard", "/checkout", "/admin"]

  // Rutas que requieren ser administrador
  const adminPaths = ["/admin"]

  // Verificar si la ruta actual está protegida
  const isProtectedPath = protectedPaths.some((prefix) => path.startsWith(prefix))
  const isAdminPath = adminPaths.some((prefix) => path.startsWith(prefix))

  if (!isProtectedPath) {
    return NextResponse.next()
  }

  // Obtener el token de autenticación
  const token = await getToken({ req: request })

  // Si no hay token, redirigir al login
  if (!token) {
    const url = new URL("/auth/login", request.url)
    url.searchParams.set("callbackUrl", encodeURI(request.url))
    return NextResponse.redirect(url)
  }

  // Si es una ruta de admin y el usuario no es admin, redirigir al dashboard
  if (isAdminPath && !token.isAdmin) {
    return NextResponse.redirect(new URL("/dashboard", request.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/dashboard/:path*", "/checkout/:path*", "/admin/:path*"],
}
