import { createClient } from "@supabase/supabase-js"
import { connectToDatabase } from "../lib/mongodb"
import User from "../lib/models/user"
import Profile from "../lib/models/profile"
import Service from "../lib/models/service"
import PortfolioItem from "../lib/models/portfolio"
import { Conversation, Message } from "../lib/models/conversation"
import Review from "../lib/models/review"
import Order from "../lib/models/order"
import bcrypt from "bcryptjs"
import type { Types } from "mongoose"
import type { Database } from "../lib/database.types"
import fs from "fs"
import path from "path"

// Configuración de Supabase
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!
const supabase = createClient<Database>(supabaseUrl, supabaseKey)

// Función para hashear contraseñas
async function hashPassword(password: string): Promise<string> {
  const salt = await bcrypt.genSalt(10)
  return bcrypt.hash(password, salt)
}

// Estructura para el reporte de migración
interface MigrationReport {
  timestamp: string
  supabase: {
    users: number
    profiles: number
    services: number
    portfolio: number
    conversations: number
    messages: number
    reviews: number
    orders: number
  }
  mongodb: {
    users: number
    profiles: number
    services: number
    portfolio: number
    conversations: number
    messages: number
    reviews: number
    orders: number
  }
  success: boolean
  errors: string[]
}

// Función principal de migración
async function migrateData(): Promise<MigrationReport> {
  const report: MigrationReport = {
    timestamp: new Date().toISOString(),
    supabase: {
      users: 0,
      profiles: 0,
      services: 0,
      portfolio: 0,
      conversations: 0,
      messages: 0,
      reviews: 0,
      orders: 0,
    },
    mongodb: {
      users: 0,
      profiles: 0,
      services: 0,
      portfolio: 0,
      conversations: 0,
      messages: 0,
      reviews: 0,
      orders: 0,
    },
    success: false,
    errors: [],
  }

  try {
    console.log("Conectando a MongoDB...")
    await connectToDatabase()
    console.log("Conexión a MongoDB establecida")

    // Migrar usuarios
    console.log("Migrando usuarios...")
    const { data: supabaseUsers, error: usersError } = await supabase.auth.admin.listUsers()

    if (usersError) {
      const errorMsg = `Error obteniendo usuarios de Supabase: ${usersError.message}`
      report.errors.push(errorMsg)
      throw new Error(errorMsg)
    }

    report.supabase.users = supabaseUsers.users.length

    const userMap = new Map<string, Types.ObjectId>() // Mapeo de IDs de Supabase a MongoDB

    for (const supabaseUser of supabaseUsers.users) {
      try {
        // Verificar si el usuario ya existe en MongoDB
        const existingUser = await User.findOne({ email: supabaseUser.email })

        if (existingUser) {
          userMap.set(supabaseUser.id, existingUser._id)
          console.log(`Usuario ya existe: ${supabaseUser.email}`)
          continue
        }

        // Crear nuevo usuario en MongoDB
        const hashedPassword = await hashPassword(supabaseUser.id) // Usamos el ID como contraseña temporal

        const newUser = new User({
          email: supabaseUser.email,
          password: hashedPassword,
          name: supabaseUser.user_metadata?.name || supabaseUser.email.split("@")[0],
          isFreelancer: false, // Se actualizará después con los perfiles
          isAdmin: false, // Se actualizará después
          emailVerified: supabaseUser.email_confirmed_at ? new Date(supabaseUser.email_confirmed_at) : null,
        })

        await newUser.save()
        userMap.set(supabaseUser.id, newUser._id)
        console.log(`Usuario migrado: ${supabaseUser.email}`)
      } catch (error: any) {
        const errorMsg = `Error migrando usuario ${supabaseUser.email}: ${error.message}`
        report.errors.push(errorMsg)
        console.error(errorMsg)
      }
    }

    // Contar usuarios en MongoDB después de la migración
    report.mongodb.users = await User.countDocuments()

    // Migrar perfiles
    console.log("Migrando perfiles...")
    const { data: supabaseProfiles, error: profilesError } = await supabase.from("profiles").select("*")

    if (profilesError) {
      const errorMsg = `Error obteniendo perfiles de Supabase: ${profilesError.message}`
      report.errors.push(errorMsg)
      throw new Error(errorMsg)
    }

    report.supabase.profiles = supabaseProfiles.length

    const profileMap = new Map<string, Types.ObjectId>() // Mapeo de IDs de Supabase a MongoDB

    for (const supabaseProfile of supabaseProfiles) {
      try {
        const userId = userMap.get(supabaseProfile.id)

        if (!userId) {
          const errorMsg = `No se encontró usuario para el perfil: ${supabaseProfile.id}`
          report.errors.push(errorMsg)
          console.log(errorMsg)
          continue
        }

        // Verificar si el perfil ya existe
        const existingProfile = await Profile.findOne({ userId })
        if (existingProfile) {
          profileMap.set(supabaseProfile.id, existingProfile._id)
          console.log(`Perfil ya existe para: ${supabaseProfile.username || supabaseProfile.id}`)
          continue
        }

        // Obtener habilidades
        const { data: skills } = await supabase.from("skills").select("skill").eq("profile_id", supabaseProfile.id)

        // Obtener idiomas
        const { data: languages } = await supabase
          .from("languages")
          .select("language")
          .eq("profile_id", supabaseProfile.id)

        // Crear perfil en MongoDB
        const newProfile = new Profile({
          userId,
          username: supabaseProfile.username,
          name: supabaseProfile.name,
          title: supabaseProfile.title,
          avatarUrl: supabaseProfile.avatar_url,
          coverImageUrl: supabaseProfile.cover_image_url,
          location: supabaseProfile.location,
          about: supabaseProfile.about,
          email: supabaseProfile.email,
          phone: supabaseProfile.phone,
          website: supabaseProfile.website,
          memberSince: supabaseProfile.created_at ? new Date(supabaseProfile.created_at) : new Date(),
          lastActive: supabaseProfile.last_active ? new Date(supabaseProfile.last_active) : new Date(),
          completionRate: supabaseProfile.completion_rate || 100,
          responseTime: supabaseProfile.response_time || "< 1 hora",
          isFreelancer: supabaseProfile.is_freelancer || false,
          skills: skills?.map((s) => s.skill) || [],
          languages: languages?.map((l) => l.language) || [],
          rating: 0,
          ratingCount: 0,
        })

        await newProfile.save()
        profileMap.set(supabaseProfile.id, newProfile._id)

        // Actualizar el usuario para marcar como freelancer si es necesario
        if (supabaseProfile.is_freelancer) {
          await User.findByIdAndUpdate(userId, { isFreelancer: true })
        }

        console.log(`Perfil migrado: ${supabaseProfile.username || supabaseProfile.id}`)
      } catch (error: any) {
        const errorMsg = `Error migrando perfil ${supabaseProfile.id}: ${error.message}`
        report.errors.push(errorMsg)
        console.error(errorMsg)
      }
    }

    // Contar perfiles en MongoDB después de la migración
    report.mongodb.profiles = await Profile.countDocuments()

    // Migrar servicios
    console.log("Migrando servicios...")
    const { data: supabaseServices, error: servicesError } = await supabase.from("services").select("*")

    if (servicesError) {
      const errorMsg = `Error obteniendo servicios de Supabase: ${servicesError.message}`
      report.errors.push(errorMsg)
      throw new Error(errorMsg)
    }

    report.supabase.services = supabaseServices.length

    const serviceMap = new Map<string, Types.ObjectId>() // Mapeo de IDs de Supabase a MongoDB

    for (const supabaseService of supabaseServices) {
      try {
        const profileId = profileMap.get(supabaseService.profile_id)

        if (!profileId) {
          const errorMsg = `No se encontró perfil para el servicio: ${supabaseService.id}`
          report.errors.push(errorMsg)
          console.log(errorMsg)
          continue
        }

        // Verificar si el servicio ya existe
        const existingService = await Service.findOne({
          profileId,
          title: supabaseService.title,
        })

        if (existingService) {
          serviceMap.set(supabaseService.id, existingService._id)
          console.log(`Servicio ya existe: ${supabaseService.title}`)
          continue
        }

        // Crear servicio en MongoDB
        const newService = new Service({
          profileId,
          title: supabaseService.title,
          description: supabaseService.description || "Sin descripción",
          category: supabaseService.category || null,
          basePrice: supabaseService.price || 0,
          deliveryTime: Number.parseInt(supabaseService.delivery_time) || 1,
          revisions: Number.parseInt(supabaseService.revisions) || 1,
          features: [],
          imageUrl: supabaseService.image_url,
          isActive: true,
        })

        await newService.save()
        serviceMap.set(supabaseService.id, newService._id)
        console.log(`Servicio migrado: ${supabaseService.title}`)
      } catch (error: any) {
        const errorMsg = `Error migrando servicio ${supabaseService.id}: ${error.message}`
        report.errors.push(errorMsg)
        console.error(errorMsg)
      }
    }

    // Contar servicios en MongoDB después de la migración
    report.mongodb.services = await Service.countDocuments()

    // Migrar portfolio
    console.log("Migrando portfolio...")
    const { data: supabasePortfolio, error: portfolioError } = await supabase.from("portfolio").select("*")

    if (portfolioError) {
      const errorMsg = `Error obteniendo portfolio de Supabase: ${portfolioError.message}`
      report.errors.push(errorMsg)
      throw new Error(errorMsg)
    }

    report.supabase.portfolio = supabasePortfolio.length

    for (const supabaseItem of supabasePortfolio) {
      try {
        const profileId = profileMap.get(supabaseItem.profile_id)

        if (!profileId) {
          const errorMsg = `No se encontró perfil para el item de portfolio: ${supabaseItem.id}`
          report.errors.push(errorMsg)
          console.log(errorMsg)
          continue
        }

        // Verificar si el item ya existe
        const existingItem = await PortfolioItem.findOne({
          profileId,
          title: supabaseItem.title,
        })

        if (existingItem) {
          console.log(`Item de portfolio ya existe: ${supabaseItem.title}`)
          continue
        }

        // Crear item de portfolio en MongoDB
        const newItem = new PortfolioItem({
          profileId,
          title: supabaseItem.title,
          description: supabaseItem.description,
          imageUrl: supabaseItem.image_url,
          category: supabaseItem.category,
          tags: [],
          projectUrl: null,
        })

        await newItem.save()
        console.log(`Item de portfolio migrado: ${supabaseItem.title}`)
      } catch (error: any) {
        const errorMsg = `Error migrando item de portfolio ${supabaseItem.id}: ${error.message}`
        report.errors.push(errorMsg)
        console.error(errorMsg)
      }
    }

    // Contar items de portfolio en MongoDB después de la migración
    report.mongodb.portfolio = await PortfolioItem.countDocuments()

    // Migrar conversaciones y mensajes
    console.log("Migrando conversaciones...")
    const { data: supabaseConversations, error: conversationsError } = await supabase.from("conversations").select("*")

    if (conversationsError) {
      const errorMsg = `Error obteniendo conversaciones de Supabase: ${conversationsError.message}`
      report.errors.push(errorMsg)
      throw new Error(errorMsg)
    }

    report.supabase.conversations = supabaseConversations.length

    const conversationMap = new Map<string, Types.ObjectId>() // Mapeo de IDs de Supabase a MongoDB

    for (const supabaseConversation of supabaseConversations) {
      try {
        const userId = userMap.get(supabaseConversation.user_id)
        const freelancerId = userMap.get(supabaseConversation.freelancer_id)

        if (!userId || !freelancerId) {
          const errorMsg = `No se encontraron usuarios para la conversación: ${supabaseConversation.id}`
          report.errors.push(errorMsg)
          console.log(errorMsg)
          continue
        }

        // Verificar si la conversación ya existe
        const existingConversation = await Conversation.findOne({
          userId,
          freelancerId,
        })

        if (existingConversation) {
          conversationMap.set(supabaseConversation.id, existingConversation._id)
          console.log(`Conversación ya existe entre usuarios: ${userId} y ${freelancerId}`)
          continue
        }

        // Crear conversación en MongoDB
        const newConversation = new Conversation({
          userId,
          freelancerId,
          subject: supabaseConversation.subject || "Sin asunto",
          serviceId: supabaseConversation.service_id ? serviceMap.get(supabaseConversation.service_id) : undefined,
          lastMessage: supabaseConversation.last_message || "",
          lastMessageAt: supabaseConversation.last_message_at
            ? new Date(supabaseConversation.last_message_at)
            : new Date(),
        })

        await newConversation.save()
        conversationMap.set(supabaseConversation.id, newConversation._id)
        console.log(`Conversación migrada: ${supabaseConversation.id}`)
      } catch (error: any) {
        const errorMsg = `Error migrando conversación ${supabaseConversation.id}: ${error.message}`
        report.errors.push(errorMsg)
        console.error(errorMsg)
      }
    }

    // Contar conversaciones en MongoDB después de la migración
    report.mongodb.conversations = await Conversation.countDocuments()

    // Migrar mensajes
    console.log("Migrando mensajes...")
    const { data: supabaseMessages, error: messagesError } = await supabase.from("messages").select("*")

    if (messagesError) {
      const errorMsg = `Error obteniendo mensajes de Supabase: ${messagesError.message}`
      report.errors.push(errorMsg)
      throw new Error(errorMsg)
    }

    report.supabase.messages = supabaseMessages.length

    for (const supabaseMessage of supabaseMessages) {
      try {
        const conversationId = conversationMap.get(supabaseMessage.conversation_id)
        const senderId = userMap.get(supabaseMessage.sender_id)

        if (!conversationId || !senderId) {
          const errorMsg = `No se encontró conversación o remitente para el mensaje: ${supabaseMessage.id}`
          report.errors.push(errorMsg)
          console.log(errorMsg)
          continue
        }

        // Verificar si el mensaje ya existe (por contenido y fecha)
        const existingMessage = await Message.findOne({
          conversationId,
          senderId,
          content: supabaseMessage.content,
          createdAt: supabaseMessage.created_at ? new Date(supabaseMessage.created_at) : new Date(),
        })

        if (existingMessage) {
          console.log(`Mensaje ya existe: ${supabaseMessage.id}`)
          continue
        }

        // Crear mensaje en MongoDB
        const newMessage = new Message({
          conversationId,
          senderId,
          content: supabaseMessage.content || "",
          read: supabaseMessage.read || false,
          createdAt: supabaseMessage.created_at ? new Date(supabaseMessage.created_at) : new Date(),
        })

        await newMessage.save()
        console.log(`Mensaje migrado: ${supabaseMessage.id}`)
      } catch (error: any) {
        const errorMsg = `Error migrando mensaje ${supabaseMessage.id}: ${error.message}`
        report.errors.push(errorMsg)
        console.error(errorMsg)
      }
    }

    // Contar mensajes en MongoDB después de la migración
    report.mongodb.messages = await Message.countDocuments()

    // Migrar órdenes
    console.log("Migrando órdenes...")
    const { data: supabaseOrders, error: ordersError } = await supabase.from("orders").select("*")

    if (ordersError) {
      const errorMsg = `Error obteniendo órdenes de Supabase: ${ordersError.message}`
      report.errors.push(errorMsg)
      throw new Error(errorMsg)
    }

    report.supabase.orders = supabaseOrders.length

    for (const supabaseOrder of supabaseOrders) {
      try {
        const clientId = userMap.get(supabaseOrder.client_id)
        const serviceId = serviceMap.get(supabaseOrder.service_id)

        if (!clientId || !serviceId) {
          const errorMsg = `No se encontró cliente o servicio para la orden: ${supabaseOrder.id}`
          report.errors.push(errorMsg)
          console.log(errorMsg)
          continue
        }

        // Verificar si la orden ya existe
        const existingOrder = await Order.findOne({
          clientId,
          serviceId,
          createdAt: supabaseOrder.created_at ? new Date(supabaseOrder.created_at) : new Date(),
        })

        if (existingOrder) {
          console.log(`Orden ya existe: ${supabaseOrder.id}`)
          continue
        }

        // Crear orden en MongoDB
        const newOrder = new Order({
          clientId,
          serviceId,
          packageId: supabaseOrder.package_id || "basic",
          amount: supabaseOrder.amount || 0,
          status: supabaseOrder.status || "pending",
          createdAt: supabaseOrder.created_at ? new Date(supabaseOrder.created_at) : new Date(),
        })

        await newOrder.save()
        console.log(`Orden migrada: ${supabaseOrder.id}`)
      } catch (error: any) {
        const errorMsg = `Error migrando orden ${supabaseOrder.id}: ${error.message}`
        report.errors.push(errorMsg)
        console.error(errorMsg)
      }
    }

    // Contar órdenes en MongoDB después de la migración
    report.mongodb.orders = await Order.countDocuments()

    // Migrar reseñas
    console.log("Migrando reseñas...")
    const { data: supabaseReviews, error: reviewsError } = await supabase.from("reviews").select("*")

    if (reviewsError) {
      const errorMsg = `Error obteniendo reseñas de Supabase: ${reviewsError.message}`
      report.errors.push(errorMsg)
      throw new Error(errorMsg)
    }

    report.supabase.reviews = supabaseReviews.length

    for (const supabaseReview of supabaseReviews) {
      try {
        const serviceId = serviceMap.get(supabaseReview.service_id)
        const clientId = userMap.get(supabaseReview.client_id)

        if (!serviceId || !clientId) {
          const errorMsg = `No se encontró servicio o cliente para la reseña: ${supabaseReview.id}`
          report.errors.push(errorMsg)
          console.log(errorMsg)
          continue
        }

        // Verificar si la reseña ya existe
        const existingReview = await Review.findOne({
          serviceId,
          clientId,
        })

        if (existingReview) {
          console.log(`Reseña ya existe: ${supabaseReview.id}`)
          continue
        }

        // Crear reseña en MongoDB
        const newReview = new Review({
          serviceId,
          clientId,
          rating: supabaseReview.rating || 5,
          comment: supabaseReview.comment || "",
          title: supabaseReview.title || "",
          response: supabaseReview.response || null,
          responseDate: supabaseReview.response_date ? new Date(supabaseReview.response_date) : null,
          helpfulCount: supabaseReview.helpful_count || 0,
          status: supabaseReview.status || "published",
          createdAt: supabaseReview.created_at ? new Date(supabaseReview.created_at) : new Date(),
        })

        await newReview.save()
        console.log(`Reseña migrada: ${supabaseReview.id}`)
      } catch (error: any) {
        const errorMsg = `Error migrando reseña ${supabaseReview.id}: ${error.message}`
        report.errors.push(errorMsg)
        console.error(errorMsg)
      }
    }

    // Contar reseñas en MongoDB después de la migración
    report.mongodb.reviews = await Review.countDocuments()

    // Guardar reporte de migración
    report.success = true
    console.log("Migración completada con éxito")

    // Guardar el reporte en un archivo
    const reportDir = path.join(process.cwd(), "migration-reports")
    if (!fs.existsSync(reportDir)) {
      fs.mkdirSync(reportDir, { recursive: true })
    }

    const reportPath = path.join(reportDir, `migration-report-${new Date().toISOString().replace(/:/g, "-")}.json`)
    fs.writeFileSync(reportPath, JSON.stringify(report, null, 2))
    console.log(`Reporte de migración guardado en: ${reportPath}`)

    return report
  } catch (error: any) {
    console.error("Error durante la migración:", error)
    report.errors.push(`Error general: ${error.message}`)
    return report
  }
}

// Si este script se ejecuta directamente
if (require.main === module) {
  migrateData()
    .then((report) => {
      console.log("Reporte de migración:", JSON.stringify(report, null, 2))
      process.exit(0)
    })
    .catch((error) => {
      console.error("Error ejecutando la migración:", error)
      process.exit(1)
    })
}

// Exportar la función para uso en otros módulos
export { migrateData }
