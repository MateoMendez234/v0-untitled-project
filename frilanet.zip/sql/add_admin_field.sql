-- Añadir campo is_admin a la tabla profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_admin BOOLEAN DEFAULT false;

-- Crear índice para búsquedas rápidas de administradores
CREATE INDEX IF NOT EXISTS idx_profiles_is_admin ON public.profiles (is_admin);

-- Actualizar políticas RLS para permitir a los administradores acceder a todos los datos
CREATE POLICY IF NOT EXISTS "Permitir acceso completo a administradores" 
ON public.profiles 
FOR ALL 
USING (auth.uid() IN (SELECT id FROM public.profiles WHERE is_admin = true));

-- Hacer lo mismo para otras tablas importantes
CREATE POLICY IF NOT EXISTS "Permitir acceso completo a administradores" 
ON public.services 
FOR ALL 
USING (auth.uid() IN (SELECT id FROM public.profiles WHERE is_admin = true));

CREATE POLICY IF NOT EXISTS "Permitir acceso completo a administradores" 
ON public.orders 
FOR ALL 
USING (auth.uid() IN (SELECT id FROM public.profiles WHERE is_admin = true));

CREATE POLICY IF NOT EXISTS "Permitir acceso completo a administradores" 
ON public.reviews 
FOR ALL 
USING (auth.uid() IN (SELECT id FROM public.profiles WHERE is_admin = true));
