-- Función para crear un perfil de usuario desde el cliente
-- Esta función debe ejecutarse en la consola SQL de Supabase
CREATE OR REPLACE FUNCTION public.create_profile(
  user_id UUID,
  user_name TEXT,
  user_email TEXT,
  user_username TEXT,
  user_is_freelancer BOOLEAN
)
RETURNS VOID AS $$
BEGIN
  INSERT INTO public.profiles (
    id, 
    name, 
    email, 
    username, 
    is_freelancer, 
    created_at, 
    last_active
  ) VALUES (
    user_id, 
    user_name, 
    user_email, 
    user_username, 
    user_is_freelancer, 
    NOW(), 
    NOW()
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Otorgar permisos para ejecutar la función
GRANT EXECUTE ON FUNCTION public.create_profile TO anon;
GRANT EXECUTE ON FUNCTION public.create_profile TO authenticated;
GRANT EXECUTE ON FUNCTION public.create_profile TO service_role;
