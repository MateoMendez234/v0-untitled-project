-- Asegurarnos de que la tabla de reseñas existe con todos los campos necesarios
CREATE TABLE IF NOT EXISTS public.reviews (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  service_id UUID NOT NULL REFERENCES public.services(id) ON DELETE CASCADE,
  client_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  
  -- Campos adicionales para mejorar el sistema de reseñas
  title TEXT,
  response TEXT,
  response_date TIMESTAMP WITH TIME ZONE,
  helpful_count INTEGER DEFAULT 0,
  status TEXT DEFAULT 'published' CHECK (status IN ('pending', 'published', 'rejected'))
);

-- Índices para mejorar el rendimiento
CREATE INDEX IF NOT EXISTS reviews_service_id_idx ON public.reviews(service_id);
CREATE INDEX IF NOT EXISTS reviews_client_id_idx ON public.reviews(client_id);

-- Función para actualizar la calificación promedio de un servicio
CREATE OR REPLACE FUNCTION update_service_rating()
RETURNS TRIGGER AS $$
BEGIN
  -- Actualizar la calificación promedio en la tabla de servicios
  UPDATE public.services
  SET 
    avg_rating = (
      SELECT COALESCE(AVG(rating), 0)
      FROM public.reviews
      WHERE service_id = NEW.service_id AND status = 'published'
    ),
    total_reviews = (
      SELECT COUNT(*)
      FROM public.reviews
      WHERE service_id = NEW.service_id AND status = 'published'
    ),
    updated_at = NOW()
  WHERE id = NEW.service_id;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para actualizar la calificación cuando se añade, actualiza o elimina una reseña
DROP TRIGGER IF EXISTS update_service_rating_trigger ON public.reviews;
CREATE TRIGGER update_service_rating_trigger
AFTER INSERT OR UPDATE OR DELETE ON public.reviews
FOR EACH ROW EXECUTE PROCEDURE update_service_rating();

-- Añadir columnas a la tabla de servicios si no existen
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'services' AND column_name = 'avg_rating') THEN
    ALTER TABLE public.services ADD COLUMN avg_rating NUMERIC(3,2) DEFAULT 0;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'services' AND column_name = 'total_reviews') THEN
    ALTER TABLE public.services ADD COLUMN total_reviews INTEGER DEFAULT 0;
  END IF;
END $$;

-- Políticas de seguridad para las reseñas
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;

-- Política para ver reseñas (todos pueden ver reseñas publicadas)
DROP POLICY IF EXISTS reviews_select_policy ON public.reviews;
CREATE POLICY reviews_select_policy ON public.reviews
  FOR SELECT USING (status = 'published' OR auth.uid() = client_id);

-- Política para crear reseñas (solo clientes que han comprado el servicio)
DROP POLICY IF EXISTS reviews_insert_policy ON public.reviews;
CREATE POLICY reviews_insert_policy ON public.reviews
  FOR INSERT WITH CHECK (
    auth.uid() = client_id AND
    EXISTS (
      SELECT 1 FROM public.orders
      WHERE client_id = auth.uid()
      AND service_id = reviews.service_id
      AND status = 'completed'
    )
  );

-- Política para actualizar reseñas (solo el autor puede actualizar su reseña)
DROP POLICY IF EXISTS reviews_update_policy ON public.reviews;
CREATE POLICY reviews_update_policy ON public.reviews
  FOR UPDATE USING (auth.uid() = client_id);

-- Política para eliminar reseñas (solo el autor puede eliminar su reseña)
DROP POLICY IF EXISTS reviews_delete_policy ON public.reviews;
CREATE POLICY reviews_delete_policy ON public.reviews
  FOR DELETE USING (auth.uid() = client_id);
