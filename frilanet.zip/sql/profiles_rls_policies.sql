-- Habilitar RLS en la tabla profiles (si no está habilitado ya)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

-- Política para permitir a los usuarios leer todos los perfiles
CREATE POLICY "Permitir lectura de perfiles a todos" 
ON public.profiles FOR SELECT 
USING (true);

-- Política para permitir a los usuarios actualizar su propio perfil
CREATE POLICY "Permitir actualización de perfil propio" 
ON public.profiles FOR UPDATE 
USING (auth.uid() = id);

-- Política para permitir a los usuarios eliminar su propio perfil
CREATE POLICY "Permitir eliminación de perfil propio" 
ON public.profiles FOR DELETE 
USING (auth.uid() = id);

-- Política para permitir inserción de perfiles a través de la función RPC
-- Esta política no es necesaria ya que usamos SECURITY DEFINER en la función
